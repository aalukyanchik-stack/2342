import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bed, CookingPot, Bath, Sofa, DoorOpen, Sun, Briefcase, Trash2, ChevronRight, Edit3 } from 'lucide-react';
import type { Room } from '@/lib/api';

const ROOM_ICONS: Record<string, React.ElementType> = {
  living: Sofa,
  bedroom: Bed,
  kitchen: CookingPot,
  bathroom: Bath,
  hallway: DoorOpen,
  balcony: Sun,
  office: Briefcase,
};

const ROOM_TYPE_OPTIONS = [
  { value: 'living', label: 'Гостиная' },
  { value: 'bedroom', label: 'Спальня' },
  { value: 'kitchen', label: 'Кухня' },
  { value: 'bathroom', label: 'Ванная' },
  { value: 'hallway', label: 'Коридор' },
  { value: 'balcony', label: 'Балкон' },
  { value: 'office', label: 'Кабинет' },
];

interface RoomListProps {
  rooms: Room[];
  selectedRoomId: string | null;
  onSelectRoom: (id: string | null) => void;
  onUpdateRoom: (id: string, data: Partial<Room>) => void;
  onDeleteRoom: (id: string) => void;
  onAddRoom: () => void;
}

export default function RoomList({ rooms, selectedRoomId, onSelectRoom, onUpdateRoom, onDeleteRoom, onAddRoom }: RoomListProps) {
  const [editingId, setEditingId] = useState<string | null>(null);

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center justify-between mb-1">
        <h3 className="font-serif text-lg font-medium text-text">Комнаты</h3>
        <span className="text-xs text-muted">{rooms.length} комнат</span>
      </div>

      {rooms.map((room, index) => {
        const Icon = ROOM_ICONS[room.roomType] || Sofa;
        const isSelected = selectedRoomId === room.id;
        const isEditing = editingId === room.id;

        return (
          <motion.div
            key={room.id}
            className={`bg-white rounded-xl border transition-colors duration-200 overflow-hidden ${
              isSelected ? 'border-accent shadow-sm' : 'border-border'
            }`}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.25, delay: index * 0.05, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
          >
            {/* Card Header */}
            <button
              className="w-full flex items-center gap-3 p-4 text-left"
              onClick={() => {
                if (!isEditing) {
                  onSelectRoom(isSelected ? null : room.id);
                }
              }}
            >
              <div className="w-10 h-10 rounded-full bg-olive-100 flex items-center justify-center shrink-0">
                <Icon size={20} className="text-accent" />
              </div>
              <div className="flex-1 min-w-0">
                {isEditing ? (
                  <input
                    type="text"
                    value={room.name}
                    onChange={(e) => onUpdateRoom(room.id, { name: e.target.value })}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') setEditingId(null);
                    }}
                    onBlur={() => setEditingId(null)}
                    autoFocus
                    className="w-full text-sm font-medium text-text bg-transparent border-b border-accent outline-none"
                    onClick={(e) => e.stopPropagation()}
                  />
                ) : (
                  <p className="text-sm font-medium text-text truncate">{room.name}</p>
                )}
                <p className="text-[13px] text-muted">
                  {room.area} м² · {room.ceilingHeight} м · {room.windowsCount} окно
                </p>
              </div>
              <div className="flex items-center gap-1">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setEditingId(isEditing ? null : room.id);
                  }}
                  className="p-1.5 text-muted hover:text-text rounded-md hover:bg-olive-100 transition-colors"
                >
                  <Edit3 size={16} />
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeleteRoom(room.id);
                  }}
                  className="p-1.5 text-muted hover:text-error rounded-md hover:bg-red-50 transition-colors"
                >
                  <Trash2 size={16} />
                </button>
                <motion.div
                  animate={{ rotate: isSelected ? 90 : 0 }}
                  transition={{ duration: 0.2 }}
                  className="text-muted"
                >
                  <ChevronRight size={16} />
                </motion.div>
              </div>
            </button>

            {/* Expanded Editor */}
            <AnimatePresence>
              {isSelected && !isEditing && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3, ease: [0.4, 0, 0.2, 1] as [number, number, number, number] }}
                  className="overflow-hidden"
                >
                  <div className="px-4 pb-4 pt-0 border-t border-border">
                    <div className="grid grid-cols-2 gap-3 mt-3">
                      <div>
                        <label className="text-[11px] text-muted uppercase tracking-wider mb-1 block">Тип</label>
                        <select
                          value={room.roomType}
                          onChange={(e) => onUpdateRoom(room.id, { roomType: e.target.value })}
                          className="w-full text-sm bg-white border border-border rounded-lg px-3 py-2 outline-none focus:border-accent focus:ring-2 focus:ring-[rgba(139,157,131,0.15)]"
                        >
                          {ROOM_TYPE_OPTIONS.map((opt) => (
                            <option key={opt.value} value={opt.value}>{opt.label}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="text-[11px] text-muted uppercase tracking-wider mb-1 block">Площадь, м²</label>
                        <input
                          type="number"
                          value={room.area}
                          onChange={(e) => onUpdateRoom(room.id, { area: Number(e.target.value) || 0 })}
                          className="w-full text-sm bg-white border border-border rounded-lg px-3 py-2 outline-none focus:border-accent focus:ring-2 focus:ring-[rgba(139,157,131,0.15)]"
                        />
                      </div>
                      <div>
                        <label className="text-[11px] text-muted uppercase tracking-wider mb-1 block">Высота потолка, м</label>
                        <input
                          type="number"
                          step="0.1"
                          value={room.ceilingHeight}
                          onChange={(e) => onUpdateRoom(room.id, { ceilingHeight: Number(e.target.value) || 0 })}
                          className="w-full text-sm bg-white border border-border rounded-lg px-3 py-2 outline-none focus:border-accent focus:ring-2 focus:ring-[rgba(139,157,131,0.15)]"
                        />
                      </div>
                      <div>
                        <label className="text-[11px] text-muted uppercase tracking-wider mb-1 block">Окон</label>
                        <input
                          type="number"
                          value={room.windowsCount}
                          onChange={(e) => onUpdateRoom(room.id, { windowsCount: Number(e.target.value) || 0 })}
                          className="w-full text-sm bg-white border border-border rounded-lg px-3 py-2 outline-none focus:border-accent focus:ring-2 focus:ring-[rgba(139,157,131,0.15)]"
                        />
                      </div>
                    </div>

                    {/* Furniture layout text */}
                    <div className="mt-3">
                      <label className="text-[11px] text-muted uppercase tracking-wider mb-1 block">Расположение мебели</label>
                      <textarea
                        value={room.furnitureLayout || ''}
                        onChange={(e) => onUpdateRoom(room.id, { furnitureLayout: e.target.value })}
                        placeholder="Описание расположения мебели..."
                        rows={2}
                        className="w-full text-sm bg-white border border-border rounded-lg px-3 py-2 outline-none focus:border-accent focus:ring-2 focus:ring-[rgba(139,157,131,0.15)] resize-none"
                      />
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        );
      })}

      <button
        onClick={onAddRoom}
        className="flex items-center justify-center gap-2 w-full py-3 rounded-xl border border-dashed border-border text-muted hover:text-accent hover:border-accent hover:bg-olive-100/50 transition-colors text-sm font-medium"
      >
        + Добавить комнату
      </button>
    </div>
  );
}
