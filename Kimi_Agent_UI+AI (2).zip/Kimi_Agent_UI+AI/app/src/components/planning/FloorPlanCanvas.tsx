import type { Room } from '@/lib/api';
import { Bed, CookingPot, Bath, Sofa, DoorOpen, Sun, Briefcase, Check } from 'lucide-react';
import { motion } from 'framer-motion';

const ROOM_COLORS: Record<string, string> = {
  living: '#f0ebe3',
  bedroom: '#e6eef5',
  kitchen: '#f5efe6',
  bathroom: '#e6f0ee',
  hallway: '#f5f0e6',
  balcony: '#eef0e6',
  office: '#eeebe6',
  default: '#f7f5f2',
};

const ROOM_ICONS: Record<string, React.ElementType> = {
  living: Sofa,
  bedroom: Bed,
  kitchen: CookingPot,
  bathroom: Bath,
  hallway: DoorOpen,
  balcony: Sun,
  office: Briefcase,
};

interface FloorPlanCanvasProps {
  rooms: Room[];
  selectedRoomId: string | null;
  onSelectRoom: (id: string | null) => void;
}

// Predefined layout positions for demo rooms (percentage-based)
const LAYOUT_POSITIONS: Record<string, { left: number; top: number; width: number; height: number }> = {
  living: { left: 2, top: 2, width: 58, height: 48 },
  kitchen: { left: 62, top: 2, width: 36, height: 48 },
  bedroom: { left: 2, top: 52, width: 38, height: 46 },
  bathroom: { left: 42, top: 52, width: 22, height: 46 },
  hallway: { left: 66, top: 52, width: 32, height: 46 },
};

function getRoomPosition(room: Room, index: number) {
  const pos = LAYOUT_POSITIONS[room.roomType];
  if (pos) return pos;
  // Fallback grid placement for additional rooms
  const row = Math.floor(index / 2);
  const col = index % 2;
  return {
    left: col * 48 + 2,
    top: row * 30 + 2,
    width: 46,
    height: 28,
  };
}

export default function FloorPlanCanvas({ rooms, selectedRoomId, onSelectRoom }: FloorPlanCanvasProps) {
  if (rooms.length === 0) {
    return (
      <div className="w-full aspect-[4/3] max-h-[50vh] bg-white rounded-2xl border border-border flex flex-col items-center justify-center p-6">
        <svg width="80" height="80" viewBox="0 0 80 80" fill="none" stroke="#8b9d83" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="mb-4">
          <path d="M40 10L10 30v40h60V30L40 10z" />
          <path d="M40 10v60" strokeDasharray="4 4" />
          <path d="M30 50h20" />
          <path d="M40 45v10" />
        </svg>
        <p className="text-sm text-muted text-center max-w-[200px]">
          Добавьте комнаты для создания плана
        </p>
      </div>
    );
  }

  const totalArea = rooms.reduce((sum, r) => sum + r.area, 0);

  return (
    <div className="w-full">
      <div className="bg-white rounded-2xl border border-border p-4 relative overflow-hidden">
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs text-muted">1 клетка ≈ 1 м²</span>
          <span className="text-xs font-medium text-text bg-olive-100 px-2 py-0.5 rounded-md">
            Общая площадь: {totalArea} м²
          </span>
        </div>

        <div className="relative w-full aspect-[4/3] bg-[#faf9f7] rounded-xl overflow-hidden">
          {/* Subtle grid background */}
          <div
            className="absolute inset-0 opacity-30"
            style={{
              backgroundImage: 'linear-gradient(#e0dbd4 1px, transparent 1px), linear-gradient(90deg, #e0dbd4 1px, transparent 1px)',
              backgroundSize: '10% 12.5%',
            }}
          />

          {rooms.map((room, index) => {
            const pos = getRoomPosition(room, index);
            const isSelected = selectedRoomId === room.id;
            const bgColor = ROOM_COLORS[room.roomType] || ROOM_COLORS.default;
            const Icon = ROOM_ICONS[room.roomType] || Sofa;

            return (
              <motion.div
                key={room.id}
                className="absolute rounded-lg flex flex-col items-center justify-center cursor-pointer select-none"
                style={{
                  left: `${pos.left}%`,
                  top: `${pos.top}%`,
                  width: `${pos.width}%`,
                  height: `${pos.height}%`,
                  backgroundColor: bgColor,
                  border: isSelected ? '2px solid #8b9d83' : '1px solid #e0dbd4',
                }}
                initial={{ opacity: 0, scale: 0.92, x: -20 }}
                animate={{
                  opacity: 1,
                  scale: isSelected ? 1.02 : 1,
                  x: 0,
                  borderWidth: isSelected ? 2 : 1,
                }}
                transition={{ duration: 0.35, delay: index * 0.08, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
                onClick={() => onSelectRoom(isSelected ? null : room.id)}
                whileHover={{ scale: 1.01, borderColor: '#8b9d83' }}
              >
                {isSelected && (
                  <motion.div
                    className="absolute top-1.5 right-1.5 w-5 h-5 bg-accent rounded-full flex items-center justify-center"
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: 'spring', stiffness: 500, damping: 25 }}
                  >
                    <Check size={12} className="text-white" strokeWidth={3} />
                  </motion.div>
                )}
                <Icon size={20} className="text-[#9a9a9a] mb-1" />
                <span className="text-[11px] font-medium text-text text-center leading-tight px-1">
                  {room.name}
                </span>
                <span className="text-[10px] text-muted mt-0.5">{room.area} м²</span>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
