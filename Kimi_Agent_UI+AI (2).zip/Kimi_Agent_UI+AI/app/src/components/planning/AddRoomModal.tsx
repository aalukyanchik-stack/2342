import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';

const ROOM_TYPE_OPTIONS = [
  { value: 'living', label: 'Гостиная' },
  { value: 'bedroom', label: 'Спальня' },
  { value: 'kitchen', label: 'Кухня' },
  { value: 'bathroom', label: 'Ванная' },
  { value: 'hallway', label: 'Коридор' },
  { value: 'balcony', label: 'Балкон' },
  { value: 'office', label: 'Кабинет' },
];

interface AddRoomModalProps {
  open: boolean;
  onClose: () => void;
  onSave: (room: {
    name: string;
    roomType: string;
    area: number;
    ceilingHeight: number;
    windowsCount: number;
  }) => void;
}

export default function AddRoomModal({ open, onClose, onSave }: AddRoomModalProps) {
  const [name, setName] = useState('');
  const [roomType, setRoomType] = useState('living');
  const [area, setArea] = useState(12);
  const [ceilingHeight, setCeilingHeight] = useState(2.7);
  const [windowsCount, setWindowsCount] = useState(1);

  const handleSave = () => {
    if (!name.trim()) return;
    onSave({
      name: name.trim(),
      roomType,
      area,
      ceilingHeight,
      windowsCount,
    });
    // Reset
    setName('');
    setRoomType('living');
    setArea(12);
    setCeilingHeight(2.7);
    setWindowsCount(1);
    onClose();
  };

  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Overlay */}
          <motion.div
            className="fixed inset-0 z-[300] bg-[rgba(26,26,26,0.4)] backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />

          {/* Modal / Sheet */}
          <motion.div
            className="fixed z-[400] bg-white overflow-hidden shadow-xl md:rounded-2xl rounded-t-[24px]"
            style={{
              bottom: 0,
              left: 0,
              right: 0,
            }}
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
          >
            {/* Desktop: centered modal */}
            <div className="md:absolute md:top-1/2 md:left-1/2 md:-translate-x-1/2 md:-translate-y-1/2 md:bottom-auto md:right-auto md:w-full md:max-w-[480px] md:rounded-2xl">
              <div className="p-6">
                {/* Drag handle (mobile) */}
                <div className="md:hidden w-10 h-1 bg-border rounded-full mx-auto mb-4" />

                <div className="flex items-center justify-between mb-5">
                  <h3 className="font-serif text-xl font-medium text-text">Новая комната</h3>
                  <button
                    onClick={onClose}
                    className="p-1.5 text-muted hover:text-text rounded-lg hover:bg-olive-100 transition-colors"
                  >
                    <X size={20} />
                  </button>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="text-[11px] text-muted uppercase tracking-wider mb-1.5 block">Название</label>
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Например, Детская"
                      className="w-full text-sm bg-white border border-border rounded-xl px-4 py-3 outline-none focus:border-accent focus:ring-2 focus:ring-[rgba(139,157,131,0.15)]"
                      autoFocus
                    />
                  </div>

                  <div>
                    <label className="text-[11px] text-muted uppercase tracking-wider mb-1.5 block">Тип</label>
                    <select
                      value={roomType}
                      onChange={(e) => setRoomType(e.target.value)}
                      className="w-full text-sm bg-white border border-border rounded-xl px-4 py-3 outline-none focus:border-accent focus:ring-2 focus:ring-[rgba(139,157,131,0.15)]"
                    >
                      {ROOM_TYPE_OPTIONS.map((opt) => (
                        <option key={opt.value} value={opt.value}>{opt.label}</option>
                      ))}
                    </select>
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="text-[11px] text-muted uppercase tracking-wider mb-1.5 block">Площадь, м²</label>
                      <input
                        type="number"
                        value={area}
                        onChange={(e) => setArea(Number(e.target.value) || 0)}
                        className="w-full text-sm bg-white border border-border rounded-xl px-3 py-3 outline-none focus:border-accent focus:ring-2 focus:ring-[rgba(139,157,131,0.15)]"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] text-muted uppercase tracking-wider mb-1.5 block">Высота, м</label>
                      <input
                        type="number"
                        step="0.1"
                        value={ceilingHeight}
                        onChange={(e) => setCeilingHeight(Number(e.target.value) || 0)}
                        className="w-full text-sm bg-white border border-border rounded-xl px-3 py-3 outline-none focus:border-accent focus:ring-2 focus:ring-[rgba(139,157,131,0.15)]"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] text-muted uppercase tracking-wider mb-1.5 block">Окон</label>
                      <input
                        type="number"
                        value={windowsCount}
                        onChange={(e) => setWindowsCount(Number(e.target.value) || 0)}
                        className="w-full text-sm bg-white border border-border rounded-xl px-3 py-3 outline-none focus:border-accent focus:ring-2 focus:ring-[rgba(139,157,131,0.15)]"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex gap-3 mt-6">
                  <button
                    onClick={onClose}
                    className="flex-1 py-3 rounded-xl border border-border text-sm font-medium text-text hover:bg-olive-100 transition-colors"
                  >
                    Отмена
                  </button>
                  <button
                    onClick={handleSave}
                    disabled={!name.trim()}
                    className="flex-1 py-3 rounded-xl bg-accent text-white text-sm font-medium hover:bg-olive-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Сохранить
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
