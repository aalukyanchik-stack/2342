import { useNavigate } from 'react-router-dom';

interface EmptyStateProps {
  title?: string;
  description?: string;
  ctaLabel?: string;
  ctaHref?: string;
  onCtaClick?: () => void;
  icon?: React.ElementType;
}

export default function EmptyState({
  title = 'Ничего пока нет',
  description = 'Начните с создания первого проекта или просмотрите демо.',
  ctaLabel = 'Создать проект',
  ctaHref = '/login',
  onCtaClick,
}: EmptyStateProps) {
  const navigate = useNavigate();

  const handleClick = () => {
    if (onCtaClick) {
      onCtaClick();
    } else {
      navigate(ctaHref);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center py-16 px-4 text-center">
      <div className="mb-6 text-accent">
        <svg
          width="80"
          height="80"
          viewBox="0 0 80 80"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M40 10L10 30v40h60V30L40 10z" />
          <path d="M40 10v60" strokeDasharray="4 4" />
          <path d="M30 50h20" />
          <path d="M40 45v10" />
        </svg>
      </div>
      <h3 className="font-serif text-xl font-semibold text-text mb-2">{title}</h3>
      <p className="text-sm text-muted max-w-[260px] mb-6 leading-relaxed">
        {description}
      </p>
      <button
        onClick={handleClick}
        className="bg-accent text-white text-sm font-medium px-5 py-2.5 rounded-xl hover:bg-olive-600 transition-colors active:scale-[0.97]"
      >
        {ctaLabel}
      </button>
    </div>
  );
}
