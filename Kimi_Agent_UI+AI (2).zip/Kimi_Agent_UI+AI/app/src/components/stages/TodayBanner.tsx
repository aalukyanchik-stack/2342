import { motion } from 'framer-motion';
import { ArrowRight, Clock } from 'lucide-react';

interface TodayBannerProps {
  stageName: string;
  stageNumber: number;
  daysRemaining: number;
  onNavigate: () => void;
}

export default function TodayBanner({ stageName, stageNumber, daysRemaining, onNavigate }: TodayBannerProps) {
  return (
    <motion.div
      className="bg-olive-100 border border-accent rounded-xl p-4 mb-6"
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
    >
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <p className="text-[11px] font-medium uppercase tracking-wider text-[#5c6b55] mb-1">
            СЕЙЧАС В РАБОТЕ
          </p>
          <p className="text-base font-medium text-text">
            {stageName}
          </p>
          <p className="text-xs text-muted mt-0.5">
            Этап {stageNumber}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 text-sm text-[#5c6b55]">
            <Clock size={16} />
            <span>Осталось {daysRemaining} дн.</span>
          </div>
          <button
            onClick={onNavigate}
            className="flex items-center gap-1 bg-accent text-white text-sm font-medium px-3 py-2 rounded-lg hover:bg-olive-600 transition-colors"
          >
            Перейти
            <ArrowRight size={14} />
          </button>
        </div>
      </div>
    </motion.div>
  );
}
