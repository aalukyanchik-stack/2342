import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  PenTool,
  Hammer,
  Zap,
  Droplet,
  BrickWall,
  Paintbrush,
  Grid3x3,
  DoorOpen,
  Sofa,
  Sparkles,
  ChevronDown,
  Check,
  AlertCircle,
  Info,
} from 'lucide-react';

const STAGE_ICONS: Record<string, React.ElementType> = {
  'design': PenTool,
  'demolition': Hammer,
  'electrical': Zap,
  'plumbing': Droplet,
  'rough': BrickWall,
  'finish': Paintbrush,
  'floors': Grid3x3,
  'doors': DoorOpen,
  'furniture': Sofa,
  'cleanup': Sparkles,
};

export interface ChecklistItemData {
  id: string;
  text: string;
  completed: boolean;
  tip?: string;
  estimatedCost?: number;
}

export interface StageData {
  id: string;
  order: number;
  name: string;
  slug: string;
  duration: string;
  description: string;
  status: 'pending' | 'in_progress' | 'completed' | 'overdue';
  checklist: ChecklistItemData[];
}

interface TimelineStageProps {
  stage: StageData;
  isLast: boolean;
  onToggleItem: (stageId: string, itemId: string) => void;
  onMarkAll: (stageId: string) => void;
  onStartStage: (stageId: string) => void;
  onCompleteStage: (stageId: string) => void;
}

export default function TimelineStage({
  stage,
  isLast,
  onToggleItem,
  onMarkAll,
  onStartStage,
  onCompleteStage,
}: TimelineStageProps) {
  const [expanded, setExpanded] = useState(stage.status === 'in_progress');

  const completedCount = stage.checklist.filter((i) => i.completed).length;
  const totalCount = stage.checklist.length;

  const Icon = STAGE_ICONS[stage.slug] || PenTool;

  const dotColor =
    stage.status === 'completed'
      ? '#7a9e7a'
      : stage.status === 'in_progress'
      ? '#8b9d83'
      : stage.status === 'overdue'
      ? '#c47d7d'
      : '#e0dbd4';

  const statusLabel =
    stage.status === 'completed'
      ? 'Завершено'
      : stage.status === 'in_progress'
      ? 'В работе'
      : stage.status === 'overdue'
      ? 'Просрочено'
      : 'Ожидает';

  const statusBadgeClass =
    stage.status === 'completed'
      ? 'bg-[rgba(122,158,122,0.12)] text-[#5a7a5a]'
      : stage.status === 'in_progress'
      ? 'bg-[rgba(201,169,110,0.12)] text-[#8a7038]'
      : stage.status === 'overdue'
      ? 'bg-[rgba(196,125,125,0.12)] text-[#8a4a4a]'
      : 'bg-olive-100 text-[#5c6b55]';

  const handleToggle = useCallback(
    (itemId: string) => {
      onToggleItem(stage.id, itemId);
    },
    [onToggleItem, stage.id]
  );

  return (
    <div className="relative flex gap-4">
      {/* Timeline line + dot */}
      <div className="flex flex-col items-center shrink-0 w-7">
        <motion.div
          className="w-7 h-7 rounded-full flex items-center justify-center shrink-0 border-2 z-10"
          style={{ borderColor: dotColor, backgroundColor: stage.status === 'completed' ? '#7a9e7a' : stage.status === 'in_progress' ? '#8b9d83' : '#ffffff' }}
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: 'spring', stiffness: 400, damping: 20, delay: stage.order * 0.05 }}
        >
          {stage.status === 'completed' ? (
            <Check size={14} className="text-white" strokeWidth={3} />
          ) : stage.status === 'in_progress' ? (
            <div className="w-2 h-2 rounded-full bg-white" />
          ) : stage.status === 'overdue' ? (
            <AlertCircle size={14} className="text-white" />
          ) : null}
        </motion.div>
        {!isLast && (
          <div
            className="w-0.5 flex-1 mt-1"
            style={{
              background: stage.status === 'completed' ? '#7a9e7a' : '#e0dbd4',
              opacity: 0.5,
            }}
          />
        )}
      </div>

      {/* Card */}
      <motion.div
        className="flex-1 bg-white rounded-xl border border-border overflow-hidden mb-4"
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.3, delay: stage.order * 0.08, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
      >
        {/* Card Header */}
        <button
          onClick={() => setExpanded((e) => !e)}
          className="w-full flex items-center gap-3 p-4 text-left"
        >
          <div className="w-9 h-9 rounded-lg bg-olive-100 flex items-center justify-center shrink-0">
            <Icon size={18} className="text-accent" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-sm font-medium text-text">
                {stage.order}. {stage.name}
              </span>
              <span className={`text-[11px] font-medium uppercase tracking-wider px-2 py-0.5 rounded-md ${statusBadgeClass}`}>
                {statusLabel}
              </span>
            </div>
            <div className="flex items-center gap-3 mt-0.5">
              <span className="text-xs text-muted">{stage.duration}</span>
              {totalCount > 0 && (
                <span className="text-xs text-muted">
                  {completedCount}/{totalCount}
                </span>
              )}
            </div>
          </div>
          <motion.div
            animate={{ rotate: expanded ? 180 : 0 }}
            transition={{ duration: 0.2 }}
            className="text-muted shrink-0"
          >
            <ChevronDown size={18} />
          </motion.div>
        </button>

        {/* Expanded Content */}
        <AnimatePresence>
          {expanded && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.35, ease: [0.4, 0, 0.2, 1] as [number, number, number, number] }}
              className="overflow-hidden"
            >
              <div className="px-4 pb-4 pt-0 border-t border-border">
                {/* Description */}
                <p className="text-sm text-muted mt-3 mb-3">{stage.description}</p>

                {/* Mini progress bar */}
                {totalCount > 0 && (
                  <div className="w-full h-1 bg-border rounded-full overflow-hidden mb-3">
                    <motion.div
                      className="h-full bg-accent rounded-full"
                      initial={{ width: 0 }}
                      animate={{ width: `${(completedCount / totalCount) * 100}%` }}
                      transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
                    />
                  </div>
                )}

                {/* Checklist */}
                <div className="space-y-2">
                  {stage.checklist.map((item, itemIndex) => (
                    <motion.div
                      key={item.id}
                      className="flex items-start gap-3 group"
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: itemIndex * 0.03 }}
                    >
                      <button
                        onClick={() => handleToggle(item.id)}
                        className="mt-0.5 w-[22px] h-[22px] rounded border flex items-center justify-center shrink-0 transition-all duration-150"
                        style={{
                          borderColor: item.completed ? '#8b9d83' : '#e0dbd4',
                          backgroundColor: item.completed ? '#8b9d83' : '#ffffff',
                        }}
                      >
                        <AnimatePresence>
                          {item.completed && (
                            <motion.div
                              initial={{ scale: 0 }}
                              animate={{ scale: 1 }}
                              exit={{ scale: 0 }}
                              transition={{ type: 'spring', stiffness: 500, damping: 20 }}
                            >
                              <Check size={14} className="text-white" strokeWidth={3} />
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </button>
                      <div className="flex-1 min-w-0">
                        <span
                          className={`text-sm leading-relaxed ${
                            item.completed ? 'text-muted line-through' : 'text-text'
                          }`}
                        >
                          {item.text}
                        </span>
                        {item.tip && (
                          <div className="flex items-center gap-1 mt-1 group/tip relative">
                            <Info size={12} className="text-accent" />
                            <span className="text-xs text-muted">{item.tip}</span>
                          </div>
                        )}
                        {item.estimatedCost && (
                          <span className="text-[11px] text-muted mt-0.5 block">
                            ~{item.estimatedCost.toLocaleString()} ₽
                          </span>
                        )}
                      </div>
                    </motion.div>
                  ))}
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2 mt-4">
                  {stage.status === 'pending' && (
                    <button
                      onClick={() => onStartStage(stage.id)}
                      className="px-4 py-2 rounded-lg border border-accent text-sm font-medium text-text hover:bg-olive-100 transition-colors"
                    >
                      Начать этап
                    </button>
                  )}
                  {stage.status === 'in_progress' && (
                    <button
                      onClick={() => onCompleteStage(stage.id)}
                      className="px-4 py-2 rounded-lg bg-accent text-white text-sm font-medium hover:bg-olive-600 transition-colors"
                    >
                      Завершить этап
                    </button>
                  )}
                  {stage.status === 'completed' && (
                    <span className="flex items-center gap-1.5 text-sm text-success font-medium">
                      <Check size={16} />
                      Завершен
                    </span>
                  )}
                  {completedCount < totalCount && totalCount > 0 && (
                    <button
                      onClick={() => onMarkAll(stage.id)}
                      className="ml-auto text-xs text-accent hover:text-olive-600 font-medium transition-colors"
                    >
                      Отметить все
                    </button>
                  )}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}
