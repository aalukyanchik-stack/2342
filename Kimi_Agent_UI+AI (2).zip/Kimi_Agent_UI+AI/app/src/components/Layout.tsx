import { useState, useEffect } from 'react';
import { useLocation, useNavigate, Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  LayoutDashboard,
  Sparkles,
  Palette,
  LayoutGrid,
  Ruler,
  CheckSquare,
  Wallet,
  Users,
  Settings,
  Menu,
  X,
  ChevronRight,
  Home,
} from 'lucide-react';
import { useProject } from '@/context/ProjectContext';

/* ─── Types ─── */
interface NavItem {
  label: string;
  path: string;
  icon: React.ElementType;
}

/* ─── Navigation Config ─── */
const baseNavItems: NavItem[] = [
  { label: 'Дашборд', path: '/dashboard', icon: LayoutDashboard },
  { label: 'Мои проекты', path: '/dashboard', icon: Home },
  { label: 'Настройки', path: '/settings', icon: Settings },
];

const projectNavItems: NavItem[] = [
  { label: 'Дашборд', path: '/dashboard', icon: LayoutDashboard },
  { label: 'AI Анализ', path: '/ai-analysis', icon: Sparkles },
  { label: 'Стиль', path: '/design', icon: Palette },
  { label: 'Мудборд', path: '/moodboard/1', icon: LayoutGrid },
  { label: 'Планировка', path: '/planning', icon: Ruler },
  { label: 'Этапы', path: '/stages', icon: CheckSquare },
  { label: 'Бюджет', path: '/budget', icon: Wallet },
  { label: 'Мастера', path: '/contractors', icon: Users },
  { label: 'Настройки', path: '/settings', icon: Settings },
];

/* ─── Project Header ─── */
function ProjectHeader() {
  const { currentProject } = useProject();
  const navigate = useNavigate();

  if (!currentProject) {
    return (
      <div className="shrink-0 bg-white border-b border-[#e0dbd4] px-4 py-2.5 md:px-6">
        <div className="flex items-center justify-between max-w-[1200px]">
          <span className="text-sm text-[#6b6b6b]">Нет активного проекта</span>
          <button
            onClick={() => navigate('/register')}
            className="text-xs font-medium bg-[#8b9d83] text-white px-3 py-1.5 rounded-lg hover:bg-[#7a8e73] transition-colors"
          >
            Создать проект
          </button>
        </div>
      </div>
    );
  }

  const progress = currentProject.progress || 0;

  return (
    <div className="shrink-0 bg-white border-b border-[#e0dbd4] px-4 py-2 md:px-6">
      <div className="flex items-center gap-3 flex-wrap max-w-[1200px]">
        <Home className="w-4 h-4 text-[#8b9d83] shrink-0" />
        <span className="font-serif text-sm font-semibold text-[#1a1a1a] truncate max-w-[200px]">
          {currentProject.name}
        </span>
        <span className="text-xs text-[#9a9a9a] hidden sm:inline">|</span>
        <span className="text-xs text-[#6b6b6b]">{currentProject.area} м²</span>
        <span className="text-xs text-[#9a9a9a] hidden sm:inline">|</span>
        <span className="text-xs text-[#6b6b6b] hidden sm:inline truncate max-w-[120px]">
          {currentProject.styleName || currentProject.styleId}
        </span>
        <div className="flex-1 min-w-[80px] max-w-[160px]">
          <div className="h-1.5 bg-[#e8ede5] rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-[#8b9d83] rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.6, ease: 'easeOut' }}
            />
          </div>
        </div>
        <span className="text-xs font-medium text-[#8b9d83] tabular-nums">{progress}%</span>
      </div>
    </div>
  );
}

/* ─── Main Layout ─── */
interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const location = useLocation();
  const navigate = useNavigate();
  const { currentProject } = useProject();
  // Sidebar state for desktop sidebar (not used on mobile)
  const [, setSidebarOpen] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);

  // Determine which nav items to show
  const navItems = currentProject ? projectNavItems : baseNavItems;

  // Close sidebar on route change
  useEffect(() => {
    setSidebarOpen(false);
    setMoreOpen(false);
  }, [location.pathname]);

  const isActive = (path: string) => {
    if (path === '/moodboard/1') {
      return location.pathname.startsWith('/moodboard');
    }
    return location.pathname === path;
  };

  /* ─── Desktop ─── */
  return (
    <div className="flex h-[100dvh] bg-[#f7f5f2]">
      {/* ── Desktop Sidebar ── */}
      <aside className="hidden md:flex flex-col w-[240px] min-w-[240px] bg-white border-r border-[#e0dbd4] h-full">
        {/* Logo */}
        <div className="shrink-0 px-5 pt-5 pb-4">
          <Link to="/dashboard" className="flex items-center gap-2.5 group">
            <div className="w-8 h-8 rounded-lg bg-[#8b9d83] flex items-center justify-center">
              <Home className="w-4 h-4 text-white" />
            </div>
            <span className="font-serif text-[15px] font-semibold text-[#1a1a1a] tracking-tight">
              PROSTRANSTVO
            </span>
          </Link>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto px-3 py-2 space-y-0.5">
          {navItems.map((item) => {
            const active = isActive(item.path);
            const Icon = item.icon;
            return (
              <button
                key={item.label}
                onClick={() => navigate(item.path)}
                className={cn(
                  'w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 text-left',
                  active
                    ? 'bg-[rgba(139,157,131,0.08)] text-[#5c6b55] border-l-2 border-[#8b9d83]'
                    : 'text-[#6b6b6b] hover:bg-[rgba(139,157,131,0.04)] hover:text-[#1a1a1a]'
                )}
              >
                <Icon className={cn('w-[18px] h-[18px] shrink-0', active ? 'text-[#8b9d83]' : 'text-[#9a9a9a]')} />
                <span>{item.label}</span>
                {active && (
                  <motion.div
                    layoutId="activeIndicator"
                    className="ml-auto w-1.5 h-1.5 rounded-full bg-[#8b9d83]"
                    transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                  />
                )}
              </button>
            );
          })}
        </nav>

        {/* Bottom: Tariff Badge */}
        <div className="shrink-0 p-3 border-t border-[#e0dbd4]">
          <Link
            to="/settings"
            className="flex items-center gap-2 px-3 py-2 rounded-xl hover:bg-[#f7f5f2] transition-colors"
          >
            <div className="w-7 h-7 rounded-full bg-[#e8ede5] flex items-center justify-center text-xs font-medium text-[#5c6b55]">
              U
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium text-[#1a1a1a] truncate">Профиль</p>
              <p className="text-[10px] text-[#9a9a9a]">Настройки</p>
            </div>
          </Link>
        </div>
      </aside>

      {/* ── Main Content ── */}
      <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden">
        <ProjectHeader />
        <main className="flex-1 overflow-y-auto">
          {children}
        </main>

        {/* ── Mobile Bottom Nav ── */}
        <nav className="shrink-0 md:hidden bg-white border-t border-[#e0dbd4] z-50">
          <div className="flex items-center justify-around px-1 py-1">
            {navItems.slice(0, 4).map((item) => {
              const active = isActive(item.path);
              const Icon = item.icon;
              return (
                <button
                  key={item.label}
                  onClick={() => navigate(item.path)}
                  className={cn(
                    'flex flex-col items-center gap-0.5 py-1.5 px-2 rounded-xl transition-all duration-200 min-w-[56px]',
                    active ? 'text-[#8b9d83]' : 'text-[#9a9a9a]'
                  )}
                >
                  <Icon className="w-5 h-5" strokeWidth={active ? 2.5 : 1.5} />
                  <span className="text-[10px] font-medium leading-tight">{item.label}</span>
                </button>
              );
            })}
            {/* More button */}
            <button
              onClick={() => setMoreOpen(true)}
              className="flex flex-col items-center gap-0.5 py-1.5 px-2 rounded-xl text-[#9a9a9a] transition-all duration-200 min-w-[56px]"
            >
              <Menu className="w-5 h-5" strokeWidth={1.5} />
              <span className="text-[10px] font-medium leading-tight">Ещё</span>
            </button>
          </div>
        </nav>
      </div>

      {/* ── Mobile "More" Sheet ── */}
      <AnimatePresence>
        {moreOpen && (
          <>
            <motion.div
              className="fixed inset-0 bg-black/30 z-[60] md:hidden"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setMoreOpen(false)}
            />
            <motion.div
              className="fixed bottom-0 left-0 right-0 bg-white rounded-t-2xl z-[61] md:hidden max-h-[70vh] overflow-y-auto"
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            >
              <div className="flex items-center justify-between px-4 pt-4 pb-2">
                <span className="font-serif text-lg font-semibold text-[#1a1a1a]">Меню</span>
                <button
                  onClick={() => setMoreOpen(false)}
                  className="w-8 h-8 flex items-center justify-center rounded-full bg-[#f7f5f2]"
                >
                  <X size={18} className="text-[#6b6b6b]" />
                </button>
              </div>
              <div className="px-3 pb-6 space-y-0.5">
                {navItems.slice(4).map((item) => {
                  const active = isActive(item.path);
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.label}
                      onClick={() => { navigate(item.path); setMoreOpen(false); }}
                      className={cn(
                        'w-full flex items-center gap-3 px-3 py-3 rounded-xl text-sm font-medium transition-all duration-200 text-left',
                        active
                          ? 'bg-[rgba(139,157,131,0.08)] text-[#5c6b55]'
                          : 'text-[#6b6b6b] hover:bg-[rgba(139,157,131,0.04)]'
                      )}
                    >
                      <Icon className={cn('w-5 h-5', active ? 'text-[#8b9d83]' : 'text-[#9a9a9a]')} />
                      <span>{item.label}</span>
                      {active && <ChevronRight className="w-4 h-4 ml-auto text-[#8b9d83]" />}
                    </button>
                  );
                })}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ─── Utility ─── */
function cn(...classes: (string | boolean | undefined)[]) {
  return classes.filter(Boolean).join(' ');
}
