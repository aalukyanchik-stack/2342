import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const navLinks = [
  { label: 'Стили', href: '/#styles' },
  { label: 'Как это работает', href: '/#how-it-works' },
  { label: 'Тарифы', href: '/#pricing' },
  { label: 'Войти', href: '/login' },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const handleNav = (href: string) => {
    setMenuOpen(false);
    if (href.startsWith('/#')) {
      const id = href.replace('/#', '');
      const el = document.getElementById(id);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      } else {
        navigate('/');
        setTimeout(() => {
          const retry = document.getElementById(id);
          retry?.scrollIntoView({ behavior: 'smooth' });
        }, 300);
      }
    } else {
      navigate(href);
    }
  };

  return (
    <>
      <motion.header
        className={`fixed top-0 left-0 right-0 z-[100] h-14 md:h-16 flex items-center justify-between px-4 md:px-8 transition-all duration-300 ${
          scrolled
            ? 'bg-[#f7f5f2] shadow-[0_1px_3px_rgba(0,0,0,0.04)]'
            : 'bg-black/20 backdrop-blur-md border-b border-white/10'
        }`}
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
      >
        <button
          onClick={() => navigate('/')}
          className="flex items-baseline gap-2 focus:outline-none"
        >
          <span className={`font-serif text-[20px] font-semibold tracking-tight transition-colors duration-300 ${scrolled ? 'text-text' : 'text-white'}`}>
            PROSTRANSTVO
          </span>
          <span className="inline-block w-2 h-2 bg-accent" />
        </button>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-6">
          {navLinks.map((link) => (
            <button
              key={link.label}
              onClick={() => handleNav(link.href)}
              className={`text-sm font-medium transition-colors duration-200 ${scrolled ? 'text-text hover:text-accent' : 'text-white/90 hover:text-white'}`}
            >
              {link.label}
            </button>
          ))}
          <button
            onClick={() => navigate('/login')}
            className="bg-accent text-white text-sm font-medium px-4 py-2 rounded-xl hover:bg-olive-600 transition-colors duration-200 active:scale-[0.97]"
          >
            Начать ремонт
          </button>
        </nav>

        {/* Mobile hamburger */}
        <button
          className={`md:hidden p-2 transition-colors duration-300 ${scrolled ? 'text-text' : 'text-white'}`}
          onClick={() => setMenuOpen(true)}
          aria-label="Открыть меню"
        >
          <Menu size={24} />
        </button>
      </motion.header>

      {/* Mobile full-screen menu */}
      <AnimatePresence>
        {menuOpen && (
          <motion.div
            className="fixed inset-0 z-[200] bg-[#f7f5f2] flex flex-col"
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
          >
            <div className="flex items-center justify-between h-14 px-4">
              <span className="font-serif text-[20px] font-semibold text-text">
                PROSTRANSTVO
              </span>
              <button
                onClick={() => setMenuOpen(false)}
                className="p-2 text-text"
                aria-label="Закрыть меню"
              >
                <X size={24} />
              </button>
            </div>
            <nav className="flex flex-col items-center justify-center flex-1 gap-8">
              {navLinks.map((link, i) => (
                <motion.button
                  key={link.label}
                  initial={{ opacity: 0, x: 40 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.08 * i, duration: 0.35, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
                  onClick={() => handleNav(link.href)}
                  className="text-2xl font-serif font-medium text-text hover:text-accent transition-colors"
                >
                  {link.label}
                </motion.button>
              ))}
              <motion.button
                initial={{ opacity: 0, x: 40 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.08 * navLinks.length, duration: 0.35, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
                onClick={() => { setMenuOpen(false); navigate('/login'); }}
                className="bg-accent text-white text-lg font-medium px-8 py-3 rounded-xl mt-4"
              >
                Начать ремонт
              </motion.button>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
