export function SkeletonCard() {
  return (
    <div className="bg-white border border-border rounded-2xl overflow-hidden">
      <div className="skeleton-shimmer h-[200px] md:h-[260px]" />
      <div className="p-5 space-y-3">
        <div className="skeleton-shimmer h-5 w-3/5 rounded-md" />
        <div className="skeleton-shimmer h-4 w-4/5 rounded-md" />
        <div className="skeleton-shimmer h-4 w-2/5 rounded-md" />
        <div className="flex gap-2 pt-2">
          <div className="skeleton-shimmer h-6 w-16 rounded-full" />
          <div className="skeleton-shimmer h-6 w-20 rounded-full" />
        </div>
      </div>
    </div>
  );
}

export function SkeletonList({ count = 5 }: { count?: number }) {
  return (
    <div className="space-y-3">
      {Array.from({ length: count }).map((_, i) => (
        <div
          key={i}
          className="bg-white border border-border rounded-xl p-4 flex items-center gap-4"
        >
          <div className="skeleton-shimmer w-12 h-12 rounded-lg flex-shrink-0" />
          <div className="flex-1 space-y-2">
            <div className="skeleton-shimmer h-4 w-1/3 rounded-md" />
            <div className="skeleton-shimmer h-3 w-1/2 rounded-md" />
          </div>
          <div className="skeleton-shimmer h-8 w-20 rounded-lg flex-shrink-0" />
        </div>
      ))}
    </div>
  );
}

export function SkeletonText({ lines = 3 }: { lines?: number }) {
  return (
    <div className="space-y-2">
      {Array.from({ length: lines }).map((_, i) => (
        <div
          key={i}
          className="skeleton-shimmer h-4 rounded-md"
          style={{ width: `${60 + Math.random() * 40}%` }}
        />
      ))}
    </div>
  );
}
