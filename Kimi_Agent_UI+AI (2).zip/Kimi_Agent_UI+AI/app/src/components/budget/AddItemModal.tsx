import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Trash2 } from 'lucide-react';
import type { BudgetItem } from '@/lib/api';

const CATEGORIES = [
  'Демонтаж', 'Электрика', 'Сантехника', 'Черновая отделка',
  'Чистовая отделка', 'Полы', 'Двери/окна', 'Мебель',
];

interface AddItemModalProps {
  open: boolean;
  onClose: () => void;
  onSave: (item: Omit<BudgetItem, 'id' | 'projectId'>) => void;
  defaultType: 'work' | 'material';
}

export default function AddItemModal({ open, onClose, onSave, defaultType }: AddItemModalProps) {
  const [category, setCategory] = useState(CATEGORIES[0]);
  const [name, setName] = useState('');
  const [plan, setPlan] = useState('');
  const [fact, setFact] = useState('');

  if (!open) return null;

  const handleSave = () => {
    if (!name.trim() || !plan.trim()) return;
    onSave({
      category,
      name: name.trim(),
      plannedCost: Number(plan) || 0,
      actualCost: Number(fact) || 0,
      type: defaultType,
    });
    setName('');
    setPlan('');
    setFact('');
    onClose();
  };

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            className="fixed inset-0 z-[300] bg-[rgba(26,26,26,0.4)] backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />
          <motion.div
            className="fixed bottom-0 left-0 right-0 z-[400] md:absolute md:top-1/2 md:left-1/2 md:bottom-auto md:-translate-x-1/2 md:-translate-y-1/2 md:w-[480px] bg-white rounded-t-[24px] md:rounded-2xl p-6 pb-10"
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-serif text-lg font-semibold">Добавить статью</h3>
              <button onClick={onClose} className="p-1">
                <Trash2 size={18} className="text-muted" />
              </button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-text mb-1">Категория</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-[#8b9d83] focus:shadow-[0_0_0_3px_rgba(139,157,131,0.15)]"
                >
                  {CATEGORIES.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-text mb-1">Название</label>
                <input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Например, Демонтаж стен"
                  className="w-full border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-[#8b9d83] focus:shadow-[0_0_0_3px_rgba(139,157,131,0.15)]"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-text mb-1">План, ₽</label>
                  <input
                    type="number"
                    value={plan}
                    onChange={(e) => setPlan(e.target.value)}
                    placeholder="0"
                    className="w-full border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-[#8b9d83] focus:shadow-[0_0_0_3px_rgba(139,157,131,0.15)]"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-text mb-1">Факт, ₽</label>
                  <input
                    type="number"
                    value={fact}
                    onChange={(e) => setFact(e.target.value)}
                    placeholder="0"
                    className="w-full border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-[#8b9d83] focus:shadow-[0_0_0_3px_rgba(139,157,131,0.15)]"
                  />
                </div>
              </div>
              <button
                onClick={handleSave}
                className="w-full bg-[#8b9d83] text-white text-sm font-medium px-5 py-3 rounded-xl hover:bg-[#6b7a64] transition-colors active:scale-[0.97] mt-2"
              >
                Сохранить
              </button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
