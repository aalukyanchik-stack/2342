import { useMemo } from 'react';
import {
  PieChart, Pie, Cell, Tooltip, ResponsiveContainer,
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Legend,
} from 'recharts';
import type { BudgetItem } from '@/lib/api';

const COLORS = ['#8b9d83', '#a8b8a0', '#c5d1be', '#e8ede5'];

function formatCurrency(n: number): string {
  return n.toLocaleString('ru-RU') + ' ₽';
}

interface BudgetChartsProps {
  items: BudgetItem[];
}

export default function BudgetCharts({ items }: BudgetChartsProps) {
  const pieData = useMemo(() => {
    const map: Record<string, number> = {};
    for (const item of items) {
      map[item.category] = (map[item.category] || 0) + item.plannedCost;
    }
    return Object.entries(map).map(([name, value]) => ({ name, value }));
  }, [items]);

  const barData = useMemo(() => {
    const map: Record<string, { plan: number; fact: number }> = {};
    for (const item of items) {
      if (!map[item.category]) map[item.category] = { plan: 0, fact: 0 };
      map[item.category].plan += item.plannedCost;
      map[item.category].fact += item.actualCost;
    }
    return Object.entries(map).map(([name, v]) => ({ name, plan: v.plan, fact: v.fact }));
  }, [items]);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6 mb-6">
      <div className="bg-white border border-border rounded-xl p-4">
        <h4 className="text-sm font-medium text-text mb-3">Распределение по категориям</h4>
        <ResponsiveContainer width="100%" height={220}>
          <PieChart>
            <Pie
              data={pieData}
              dataKey="value"
              nameKey="name"
              cx="50%"
              cy="50%"
              outerRadius={70}
              innerRadius={35}
              animationBegin={0}
              animationDuration={1000}
              animationEasing="ease-out"
            >
              {pieData.map((_, i) => (
                <Cell key={i} fill={COLORS[i % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip formatter={(v: number) => formatCurrency(v)} />
          </PieChart>
        </ResponsiveContainer>
        <div className="flex flex-wrap gap-2 mt-2">
          {pieData.map((entry, i) => (
            <span key={entry.name} className="inline-flex items-center gap-1 text-xs text-muted">
              <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
              {entry.name}
            </span>
          ))}
        </div>
      </div>
      <div className="bg-white border border-border rounded-xl p-4">
        <h4 className="text-sm font-medium text-text mb-3">План vs Факт по категориям</h4>
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={barData} barGap={4}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e0dbd4" />
            <XAxis dataKey="name" tick={{ fontSize: 11 }} angle={-30} textAnchor="end" height={60} />
            <YAxis tick={{ fontSize: 11 }} tickFormatter={(v: number) => `${(v / 1000).toFixed(0)}K`} />
            <Tooltip formatter={(v: number) => formatCurrency(v)} />
            <Legend wrapperStyle={{ fontSize: 12 }} />
            <Bar dataKey="plan" name="План" fill="#c5d1be" radius={[4, 4, 0, 0]} animationDuration={800} />
            <Bar dataKey="fact" name="Факт" fill="#8b9d83" radius={[4, 4, 0, 0]} animationDuration={800} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
