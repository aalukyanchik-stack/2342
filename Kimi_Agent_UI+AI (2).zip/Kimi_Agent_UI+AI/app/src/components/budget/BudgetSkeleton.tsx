export default function BudgetSkeleton() {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-3 gap-3">
        {[1, 2, 3].map(i => (
          <div key={i} className="bg-white border border-border rounded-xl p-4 space-y-2">
            <div className="skeleton-shimmer h-3 w-20 rounded-md" />
            <div className="skeleton-shimmer h-6 w-24 rounded-md" />
          </div>
        ))}
      </div>
      <div className="space-y-2">
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="bg-white border border-border rounded-xl p-3 flex items-center gap-4">
            <div className="skeleton-shimmer h-4 w-24 rounded-md" />
            <div className="flex-1 skeleton-shimmer h-4 rounded-md" />
            <div className="skeleton-shimmer h-4 w-16 rounded-md" />
          </div>
        ))}
      </div>
    </div>
  );
}
