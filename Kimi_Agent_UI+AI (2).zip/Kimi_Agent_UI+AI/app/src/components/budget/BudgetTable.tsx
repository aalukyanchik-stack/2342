import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, ChevronRight, Pencil, Trash2 } from 'lucide-react';
import type { BudgetItem } from '@/lib/api';

function formatCurrency(n: number): string {
  return n.toLocaleString('ru-RU') + ' ₽';
}

/* ─── Desktop Row ─── */
function BudgetRow({ item, index, onUpdate, onDelete }: {
  item: BudgetItem; index: number;
  onUpdate: (id: string, d: Partial<BudgetItem>) => void;
  onDelete: (id: string) => void;
}) {
  const [editing, setEditing] = useState(false);
  const [planVal, setPlanVal] = useState(String(item.plannedCost));
  const [factVal, setFactVal] = useState(String(item.actualCost));
  const deviation = item.actualCost - item.plannedCost;
  const pct = item.plannedCost > 0 ? Math.round((deviation / item.plannedCost) * 100) : 0;
  const status = deviation > item.plannedCost * 0.1 ? 'over' : deviation < -item.plannedCost * 0.05 ? 'under' : 'ontrack';

  const saveEdit = () => {
    onUpdate(item.id, { plannedCost: Number(planVal) || 0, actualCost: Number(factVal) || 0 });
    setEditing(false);
  };

  return (
    <motion.tr
      initial={{ opacity: 0, y: -8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2, delay: index * 0.04, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
      className="hover:bg-[rgba(139,157,131,0.04)] border-b border-border"
      style={{
        borderLeft: deviation > 0 ? '3px solid #c47d7d' : deviation < 0 ? '3px solid #7a9e7a' : '3px solid transparent',
      }}
    >
      <td className="px-3 py-3 text-sm text-text whitespace-nowrap">{item.category}</td>
      <td className="px-3 py-3 text-sm font-medium text-text">{item.name}</td>
      {editing ? (
        <>
          <td className="px-3 py-3">
            <input type="number" value={planVal} onChange={e => setPlanVal(e.target.value)}
              className="w-24 border border-border rounded-lg px-2 py-1 text-sm" />
          </td>
          <td className="px-3 py-3">
            <input type="number" value={factVal} onChange={e => setFactVal(e.target.value)}
              className="w-24 border border-border rounded-lg px-2 py-1 text-sm" />
          </td>
          <td className="px-3 py-3" colSpan={3}>
            <button onClick={saveEdit} className="text-xs bg-[#8b9d83] text-white px-2 py-1 rounded-md mr-2">OK</button>
            <button onClick={() => setEditing(false)} className="text-xs text-muted">Отмена</button>
          </td>
        </>
      ) : (
        <>
          <td className="px-3 py-3 text-sm text-text whitespace-nowrap">{formatCurrency(item.plannedCost)}</td>
          <td className="px-3 py-3 text-sm text-text whitespace-nowrap">{formatCurrency(item.actualCost)}</td>
          <td className={`px-3 py-3 text-sm font-medium whitespace-nowrap ${deviation > 0 ? 'text-[#c47d7d]' : deviation < 0 ? 'text-[#7a9e7a]' : 'text-muted'}`}>
            {deviation > 0 ? '+' : ''}{formatCurrency(deviation)}
          </td>
          <td className="px-3 py-3 text-sm whitespace-nowrap">
            <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-xs font-medium ${
              status === 'over' ? 'bg-[rgba(196,125,125,0.12)] text-[#8a4a4a]' :
              status === 'under' ? 'bg-[rgba(122,158,122,0.12)] text-[#5a7a5a]' :
              'bg-[rgba(201,169,110,0.12)] text-[#8a7038]'
            }`}>
              <span className={`w-1.5 h-1.5 rounded-full ${status === 'over' ? 'bg-[#c47d7d]' : status === 'under' ? 'bg-[#7a9e7a]' : 'bg-[#c9a96e]'}`} />
              {pct > 0 ? '+' : ''}{pct}%
            </span>
          </td>
          <td className="px-3 py-3 text-sm">
            <div className="flex items-center gap-2">
              <button onClick={() => setEditing(true)} className="p-1 text-muted hover:text-text transition-colors"><Pencil size={14} /></button>
              <button onClick={() => onDelete(item.id)} className="p-1 text-muted hover:text-[#c47d7d] transition-colors"><Trash2 size={14} /></button>
            </div>
          </td>
        </>
      )}
    </motion.tr>
  );
}

/* ─── Mobile Card ─── */
function BudgetCard({ item, index, onUpdate, onDelete }: {
  item: BudgetItem; index: number;
  onUpdate: (id: string, d: Partial<BudgetItem>) => void;
  onDelete: (id: string) => void;
}) {
  const [editing, setEditing] = useState(false);
  const [planVal, setPlanVal] = useState(String(item.plannedCost));
  const [factVal, setFactVal] = useState(String(item.actualCost));
  const deviation = item.actualCost - item.plannedCost;
  const pct = item.plannedCost > 0 ? Math.round((deviation / item.plannedCost) * 100) : 0;

  const saveEdit = () => {
    onUpdate(item.id, { plannedCost: Number(planVal) || 0, actualCost: Number(factVal) || 0 });
    setEditing(false);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2, delay: index * 0.04, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
      className="bg-white border border-border rounded-xl p-4 mb-3"
      style={{ borderLeftWidth: '3px', borderLeftColor: deviation > 0 ? '#c47d7d' : deviation < 0 ? '#7a9e7a' : '#e0dbd4' }}
    >
      <div className="flex items-start justify-between mb-2">
        <div>
          <span className="text-xs font-medium text-[#5c6b55] bg-[#e8ede5] px-2 py-0.5 rounded-md">{item.category}</span>
          <h4 className="text-sm font-medium text-text mt-1">{item.name}</h4>
        </div>
        <div className="flex items-center gap-1">
          <button onClick={() => setEditing(!editing)} className="p-1 text-muted hover:text-text"><Pencil size={14} /></button>
          <button onClick={() => onDelete(item.id)} className="p-1 text-muted hover:text-[#c47d7d]"><Trash2 size={14} /></button>
        </div>
      </div>
      {editing ? (
        <div className="grid grid-cols-2 gap-2 mt-2">
          <input type="number" value={planVal} onChange={e => setPlanVal(e.target.value)} placeholder="План"
            className="border border-border rounded-lg px-2 py-1.5 text-sm" />
          <input type="number" value={factVal} onChange={e => setFactVal(e.target.value)} placeholder="Факт"
            className="border border-border rounded-lg px-2 py-1.5 text-sm" />
          <button onClick={saveEdit} className="col-span-2 bg-[#8b9d83] text-white text-xs font-medium py-1.5 rounded-lg">Сохранить</button>
        </div>
      ) : (
        <div className="flex items-center gap-4 text-sm mt-1">
          <span className="text-muted">План: <span className="text-text font-medium">{formatCurrency(item.plannedCost)}</span></span>
          <span className="text-muted">Факт: <span className="text-text font-medium">{formatCurrency(item.actualCost)}</span></span>
        </div>
      )}
      <div className="flex items-center gap-2 mt-2">
        <span className={`text-xs font-medium ${deviation > 0 ? 'text-[#c47d7d]' : deviation < 0 ? 'text-[#7a9e7a]' : 'text-muted'}`}>
          Отклонение: {deviation > 0 ? '+' : ''}{formatCurrency(deviation)} ({pct > 0 ? '+' : ''}{pct}%)
        </span>
      </div>
    </motion.div>
  );
}

/* ─── Table with Category Groups ─── */
export default function BudgetTable({ items, onUpdate, onDelete }: {
  items: BudgetItem[];
  onUpdate: (id: string, d: Partial<BudgetItem>) => void;
  onDelete: (id: string) => void;
}) {
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});
  const grouped = useMemo(() => {
    const map: Record<string, BudgetItem[]> = {};
    for (const item of items) {
      if (!map[item.category]) map[item.category] = [];
      map[item.category].push(item);
    }
    return map;
  }, [items]);

  const toggleCat = (cat: string) => setCollapsed(prev => ({ ...prev, [cat]: !prev[cat] }));

  return (
    <div>
      {/* Desktop Table */}
      <div className="hidden md:block overflow-x-auto rounded-xl border border-border">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-[#e8ede5] text-[#5c6b55] text-[13px] font-medium uppercase tracking-wide">
              <th className="px-3 py-3">Категория</th>
              <th className="px-3 py-3">Статья</th>
              <th className="px-3 py-3">План</th>
              <th className="px-3 py-3">Факт</th>
              <th className="px-3 py-3">Отклонение</th>
              <th className="px-3 py-3">%</th>
              <th className="px-3 py-3"></th>
            </tr>
          </thead>
          <tbody>
            {Object.entries(grouped).map(([cat, catItems]) => (
              <>
                <tr key={cat} className="bg-[#f7f5f2]">
                  <td colSpan={7} className="px-3 py-2">
                    <button onClick={() => toggleCat(cat)} className="flex items-center gap-1 text-sm font-semibold text-[#5c6b55]">
                      {collapsed[cat] ? <ChevronRight size={16} /> : <ChevronDown size={16} />}
                      {cat} <span className="text-xs font-normal text-muted">({catItems.length})</span>
                    </button>
                  </td>
                </tr>
                <AnimatePresence>
                  {!collapsed[cat] && catItems.map((item, i) => (
                    <BudgetRow key={item.id} item={item} index={i} onUpdate={onUpdate} onDelete={onDelete} />
                  ))}
                </AnimatePresence>
              </>
            ))}
          </tbody>
        </table>
      </div>

      {/* Mobile Cards */}
      <div className="md:hidden">
        {Object.entries(grouped).map(([cat, catItems]) => (
          <div key={cat} className="mb-4">
            <button onClick={() => toggleCat(cat)} className="flex items-center gap-1 text-sm font-semibold text-[#5c6b55] mb-2">
              {collapsed[cat] ? <ChevronRight size={16} /> : <ChevronDown size={16} />}
              {cat}
            </button>
            <AnimatePresence>
              {!collapsed[cat] && catItems.map((item, i) => (
                <BudgetCard key={item.id} item={item} index={i} onUpdate={onUpdate} onDelete={onDelete} />
              ))}
            </AnimatePresence>
          </div>
        ))}
      </div>
    </div>
  );
}
