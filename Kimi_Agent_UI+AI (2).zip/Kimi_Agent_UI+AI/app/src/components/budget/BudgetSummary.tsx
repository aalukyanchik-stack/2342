import { useState, useEffect } from 'react';
import type { BudgetItem } from '@/lib/api';

function formatCurrency(n: number): string {
  return n.toLocaleString('ru-RU') + ' ₽';
}

function useCountUp(target: number, duration = 800) {
  const [value, setValue] = useState(0);
  useEffect(() => {
    let raf: number;
    const start = performance.now();
    const animate = (now: number) => {
      const p = Math.min((now - start) / duration, 1);
      setValue(Math.round(target * p));
      if (p < 1) raf = requestAnimationFrame(animate);
    };
    raf = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(raf);
  }, [target, duration]);
  return value;
}

interface BudgetSummaryProps {
  items: BudgetItem[];
}

export default function BudgetSummary({ items }: BudgetSummaryProps) {
  const totalPlan = items.reduce((s, i) => s + i.plannedCost, 0);
  const totalFact = items.reduce((s, i) => s + i.actualCost, 0);
  const deviation = totalFact - totalPlan;
  const devPct = totalPlan > 0 ? Math.round((deviation / totalPlan) * 100) : 0;

  const animPlan = useCountUp(totalPlan);
  const animFact = useCountUp(totalFact);
  const animDev = useCountUp(deviation);

  return (
    <div className="grid grid-cols-3 gap-3 mb-5">
      <div className="bg-white border border-border rounded-xl p-3 text-center">
        <div className="text-xs text-muted mb-1">Всего план</div>
        <div className="text-base font-semibold text-[#1a1a1a]">{formatCurrency(animPlan)}</div>
      </div>
      <div className="bg-white border border-border rounded-xl p-3 text-center">
        <div className="text-xs text-muted mb-1">Всего факт</div>
        <div className="text-base font-semibold text-[#8b9d83]">{formatCurrency(animFact)}</div>
      </div>
      <div className={`rounded-xl p-3 text-center border ${deviation > 0 ? 'border-[#c47d7d] bg-[rgba(196,125,125,0.06)]' : 'border-[#7a9e7a] bg-[rgba(122,158,122,0.06)]'}`}>
        <div className="text-xs text-muted mb-1">Отклонение</div>
        <div className={`text-base font-semibold ${deviation > 0 ? 'text-[#c47d7d]' : 'text-[#7a9e7a]'}`}>
          {deviation > 0 ? '+' : ''}{formatCurrency(animDev)} ({devPct > 0 ? '+' : ''}{devPct}%)
        </div>
      </div>
    </div>
  );
}
