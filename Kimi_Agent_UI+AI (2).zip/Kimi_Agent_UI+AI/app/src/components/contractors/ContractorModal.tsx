import { motion, AnimatePresence } from 'framer-motion';
import { X, Star, MapPin, Phone, Mail, MessageCircle, CheckCircle, Clock, Briefcase } from 'lucide-react';
import type { Contractor } from '@/lib/api';

interface ContractorModalProps {
  contractor: (Contractor & { about?: string; services?: { name: string; price: string }[]; telegram?: string; yearsExp?: number; projectsCount?: number }) | null;
  open: boolean;
  onClose: () => void;
  onHire: () => void;
  onSave: () => void;
  saved: boolean;
}

export default function ContractorModal({ contractor, open, onClose, onHire, onSave, saved }: ContractorModalProps) {
  if (!contractor) return null;

  const priceLabel = contractor.priceRange === '$' ? 'от 2,000 ₽/час' : contractor.priceRange === '$$' ? 'от 4,000 ₽/час' : 'от 6,000 ₽/час';

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            className="fixed inset-0 z-[300] bg-[rgba(26,26,26,0.4)] backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />
          <motion.div
            className="fixed bottom-0 left-0 right-0 z-[400] md:absolute md:top-1/2 md:left-1/2 md:bottom-auto md:-translate-x-1/2 md:-translate-y-1/2 md:w-[480px] bg-white rounded-t-[24px] md:rounded-2xl max-h-[85vh] overflow-y-auto"
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
          >
            <div className="p-6">
              {/* Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-16 h-16 rounded-full bg-[#e8ede5] flex items-center justify-center text-lg font-semibold text-[#5c6b55]">
                    {contractor.name.split(' ').map(p => p[0]).slice(0, 2).join('').toUpperCase()}
                  </div>
                  <div>
                    <h3 className="font-serif text-xl font-medium text-[#1a1a1a]">{contractor.name}</h3>
                    <span className="text-sm text-[#8b9d83] font-medium">{contractor.specialization}</span>
                  </div>
                </div>
                <button onClick={onClose} className="p-1 text-muted hover:text-text transition-colors">
                  <X size={20} />
                </button>
              </div>

              {/* Rating */}
              <div className="flex items-center gap-3 mb-4">
                <div className="flex items-center gap-1">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star
                      key={i}
                      size={18}
                      className={i < Math.floor(contractor.rating) ? 'text-[#8b9d83] fill-[#8b9d83]' : 'text-[#e0dbd4] fill-[#e0dbd4]'}
                    />
                  ))}
                </div>
                <span className="text-sm font-medium text-[#1a1a1a]">{contractor.rating.toFixed(1)} из 5</span>
                <span className="text-xs text-muted">({contractor.reviews} отзывов)</span>
              </div>

              {/* Stats */}
              <div className="flex items-center gap-4 text-xs text-muted mb-4">
                <span className="inline-flex items-center gap-1">
                  <Briefcase size={12} />
                  {contractor.projectsCount ?? Math.floor(contractor.reviews * 0.6)} проектов
                </span>
                <span className="inline-flex items-center gap-1">
                  <Clock size={12} />
                  {contractor.yearsExp ?? 3 + (contractor.rating > 4.5 ? 4 : 1)} лет опыта
                </span>
                <span className="inline-flex items-center gap-1">
                  <MapPin size={12} />
                  {contractor.region}
                </span>
              </div>

              {/* About */}
              <div className="mb-4">
                <h4 className="text-sm font-semibold text-text mb-2">О специалисте</h4>
                <p className="text-sm text-muted leading-relaxed">
                  {contractor.about ?? `Профессионал по ${contractor.specialization.toLowerCase()}. Качественная работа, гарантия, выезд на объект.`}
                </p>
              </div>

              {/* Services */}
              <div className="mb-4">
                <h4 className="text-sm font-semibold text-text mb-2">Услуги и цены</h4>
                <div className="space-y-2">
                  {(contractor.services ?? [
                    { name: 'Консультация', price: 'бесплатно' },
                    { name: 'Выезд на объект', price: '1,500 ₽' },
                    { name: 'Основная работа', price: priceLabel },
                  ]).map((s, i) => (
                    <div key={i} className="flex items-center justify-between text-sm">
                      <span className="text-text">{s.name}</span>
                      <span className="font-medium text-[#1a1a1a]">{s.price}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Contacts */}
              <div className="mb-5">
                <h4 className="text-sm font-semibold text-text mb-2">Контакты</h4>
                <div className="space-y-2 text-sm">
                  {contractor.phone && (
                    <a href={`tel:${contractor.phone}`} className="flex items-center gap-2 text-[#8b9d83] hover:underline">
                      <Phone size={14} /> {contractor.phone}
                    </a>
                  )}
                  {contractor.email && (
                    <a href={`mailto:${contractor.email}`} className="flex items-center gap-2 text-muted hover:text-text">
                      <Mail size={14} /> {contractor.email}
                    </a>
                  )}
                  {contractor.telegram && (
                    <a href={`https://t.me/${contractor.telegram}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-muted hover:text-text">
                      <MessageCircle size={14} /> @{contractor.telegram}
                    </a>
                  )}
                </div>
              </div>

              {/* CTAs */}
              <div className="space-y-2">
                <button
                  onClick={() => { onHire(); onClose(); }}
                  className="w-full bg-[#8b9d83] text-white text-sm font-medium px-5 py-3 rounded-xl hover:bg-[#6b7a64] transition-colors active:scale-[0.97] inline-flex items-center justify-center gap-2"
                >
                  <Phone size={16} /> Нанять
                </button>
                <button
                  onClick={() => onSave()}
                  className="w-full border border-[#8b9d83] text-[#1a1a1a] text-sm font-medium px-5 py-3 rounded-xl hover:bg-[#e8ede5] transition-colors inline-flex items-center justify-center gap-2"
                >
                  {saved ? <CheckCircle size={16} className="text-[#8b9d83]" /> : <CheckCircle size={16} />}
                  {saved ? 'Сохранён в проект' : 'Сохранить в проект'}
                </button>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
