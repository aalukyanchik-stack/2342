import { motion } from 'framer-motion';
import { Star, MapPin, Phone, ChevronRight, Briefcase, Clock } from 'lucide-react';
import type { Contractor } from '@/lib/api';

interface ContractorCardProps {
  contractor: Contractor & { about?: string; services?: { name: string; price: string }[]; telegram?: string; yearsExp?: number; projectsCount?: number };
  index: number;
  onOpen: () => void;
  onCall: () => void;
  onSave: () => void;
  saved: boolean;
}

function getInitials(name: string): string {
  return name.split(' ').map(p => p[0]).slice(0, 2).join('').toUpperCase();
}

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          size={14}
          className={i < Math.floor(rating) ? 'text-[#8b9d83] fill-[#8b9d83]' : 'text-[#e0dbd4] fill-[#e0dbd4]'}
        />
      ))}
    </div>
  );
}

export default function ContractorCard({ contractor, index, onOpen, onCall, saved }: ContractorCardProps) {
  const priceLabel = contractor.priceRange === '$' ? 'от 2,000 ₽/час' : contractor.priceRange === '$$' ? 'от 4,000 ₽/час' : 'от 6,000 ₽/час';

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{
        duration: 0.25,
        delay: index * 0.06,
        ease: [0.16, 1, 0.3, 1] as [number, number, number, number],
      }}
      whileHover={{ y: -2, boxShadow: '0 4px 12px rgba(0,0,0,0.08)' }}
      className="bg-white border border-[#e0dbd4] rounded-xl p-5 transition-all duration-250"
    >
      {/* Top row: avatar + info + save */}
      <div className="flex items-start gap-3">
        <div className="w-12 h-12 rounded-full bg-[#e8ede5] flex items-center justify-center flex-shrink-0 text-sm font-semibold text-[#5c6b55]">
          {getInitials(contractor.name)}
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="text-[16px] font-semibold text-[#1a1a1a] truncate">{contractor.name}</h3>
          <div className="flex items-center gap-2 mt-1">
            <span className="text-xs font-medium bg-[#e8ede5] text-[#5c6b55] px-2 py-0.5 rounded-md">{contractor.specialization}</span>
          </div>
          <div className="flex items-center gap-2 mt-1.5">
            <StarRating rating={contractor.rating} />
            <span className="text-xs font-medium text-[#1a1a1a]">{contractor.rating.toFixed(1)}</span>
            <span className="text-xs text-muted">{contractor.reviews} отзывов</span>
          </div>
        </div>
      </div>

      {/* Stats row */}
      <div className="flex items-center gap-4 mt-3 text-xs text-muted">
        <span className="inline-flex items-center gap-1">
          <Briefcase size={12} />
          {contractor.projectsCount ?? Math.floor(contractor.reviews * 0.6)} проектов
        </span>
        <span className="inline-flex items-center gap-1">
          <Clock size={12} />
          {contractor.yearsExp ?? 3 + (contractor.rating > 4.5 ? 4 : 1)} лет опыта
        </span>
        <span className="text-[#8b9d83] font-medium">{contractor.priceRange}</span>
      </div>

      {/* Description */}
      <p className="text-sm text-muted mt-2 line-clamp-2 leading-relaxed">
        {contractor.about ?? `Профессионал по ${contractor.specialization.toLowerCase()}. Качественная работа, гарантия, выезд на объект.`}
      </p>

      {/* Tags */}
      <div className="flex flex-wrap gap-2 mt-3">
        {['Гарантия', 'Выезд', 'Срочно'].slice(0, 2 + (contractor.rating > 4.7 ? 1 : 0)).map(tag => (
          <span key={tag} className="text-xs bg-[#e8ede5] text-[#5c6b55] px-2 py-0.5 rounded-md">{tag}</span>
        ))}
      </div>

      {/* Region */}
      <div className="flex items-center gap-1 mt-2 text-xs text-muted">
        <MapPin size={12} />
        {contractor.region}
        <span className="ml-2 text-[#8b9d83] font-medium">{priceLabel}</span>
      </div>

      {/* Actions */}
      <div className="flex items-center gap-2 mt-4">
        <button
          onClick={onCall}
          className="bg-[#8b9d83] text-white text-xs font-medium px-3 py-2 rounded-lg hover:bg-[#6b7a64] transition-colors active:scale-[0.97] inline-flex items-center gap-1"
        >
          <Phone size={12} /> Позвонить
        </button>
        <button
          onClick={onOpen}
          className="border border-[#8b9d83] text-[#1a1a1a] text-xs font-medium px-3 py-2 rounded-lg hover:bg-[#e8ede5] transition-colors inline-flex items-center gap-1"
        >
          Подробнее <ChevronRight size={12} />
        </button>
        {saved && (
          <span className="text-xs text-[#8b9d83] font-medium ml-auto">Сохранён</span>
        )}
      </div>
    </motion.div>
  );
}
