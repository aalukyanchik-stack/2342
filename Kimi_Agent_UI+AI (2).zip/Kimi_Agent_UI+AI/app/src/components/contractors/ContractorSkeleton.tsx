export default function ContractorSkeleton({ count = 6 }: { count?: number }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="bg-white border border-border rounded-xl p-5 space-y-3">
          <div className="flex items-start gap-3">
            <div className="skeleton-shimmer w-12 h-12 rounded-full flex-shrink-0" />
            <div className="flex-1 space-y-2">
              <div className="skeleton-shimmer h-4 w-1/3 rounded-md" />
              <div className="skeleton-shimmer h-3 w-16 rounded-full" />
              <div className="skeleton-shimmer h-3 w-24 rounded-md" />
            </div>
          </div>
          <div className="flex gap-2 pt-1">
            <div className="skeleton-shimmer h-3 w-20 rounded-md" />
            <div className="skeleton-shimmer h-3 w-16 rounded-md" />
          </div>
          <div className="skeleton-shimmer h-8 w-full rounded-lg mt-2" />
        </div>
      ))}
    </div>
  );
}
