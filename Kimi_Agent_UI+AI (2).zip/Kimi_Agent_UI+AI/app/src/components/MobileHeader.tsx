import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Menu } from 'lucide-react';

interface MobileHeaderProps {
  title: string;
  backButton?: boolean;
  transparent?: boolean;
  rightAction?: React.ReactNode;
  onMenuClick?: () => void;
}

export default function MobileHeader({
  title,
  backButton = true,
  transparent = false,
  rightAction,
  onMenuClick,
}: MobileHeaderProps) {
  const navigate = useNavigate();

  return (
    <header
      className={`md:hidden fixed top-0 left-0 right-0 z-[100] h-14 flex items-center justify-between px-4 transition-colors duration-300 ${
        transparent ? 'bg-transparent' : 'bg-background'
      }`}
      style={{
        boxShadow: transparent ? 'none' : '0 1px 3px rgb(0 0 0 / 0.04)',
      }}
    >
      <div className="w-10">
        {backButton ? (
          <button
            onClick={() => navigate(-1)}
            className="p-2 -ml-2 text-text active:scale-[0.92] transition-transform"
            aria-label="Назад"
          >
            <ArrowLeft size={22} />
          </button>
        ) : onMenuClick ? (
          <button
            onClick={onMenuClick}
            className="p-2 -ml-2 text-text active:scale-[0.92] transition-transform"
            aria-label="Меню"
          >
            <Menu size={22} />
          </button>
        ) : (
          <div />
        )}
      </div>

      <h1 className="font-serif text-lg font-semibold text-text truncate">
        {title}
      </h1>

      <div className="w-10 flex justify-end">
        {rightAction || <div />}
      </div>
    </header>
  );
}
