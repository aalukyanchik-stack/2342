import { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Bell,
  Plus,
  ChevronRight,
  Home,
  CheckSquare,
  AlertCircle,
  RefreshCw,
  Sparkles,
  LogOut,
  X,
  Pencil,
  MapPin,
  SquareStack,
  Wallet,
  Palette,
  ImageIcon,
  ArrowRight,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useProject } from '@/context/ProjectContext';
import { useToast } from '@/components/Toast';
import EmptyState from '@/components/EmptyState';
import { projects, styles, stages, type Project, type Style, type Stage, type ProjectStage } from '@/lib/api';

// ── Types ──────────────────────────────────────────────
interface ActivityItem {
  id: string;
  icon: React.ElementType;
  text: string;
  time: string;
}

interface DashboardData {
  projects: Project[];
  allStyles: Style[];
  allStages: Stage[];
  progressMap: Record<string, ProjectStage[]>;
}

interface ProjectFormData {
  name: string;
  city: string;
  area: string;
  rooms: number;
  budget: string;
  style: string;
  photos: string[];
  created: boolean;
}

interface FormErrors {
  name?: string;
  city?: string;
  area?: string;
  rooms?: string;
  budget?: string;
  style?: string;
}

// ── Constants ──────────────────────────────────────────
const BUDGET_OPTIONS = [
  { label: 'до $10к', value: 'under_10k' },
  { label: '$10–20к', value: '10k_20k' },
  { label: '$20–30к', value: '20k_30k' },
  { label: '$30–50к', value: '30k_50k' },
  { label: '$50к+', value: 'over_50k' },
];

const ROOM_OPTIONS = [1, 2, 3, 4];

const STYLE_OPTIONS = [
  'Скандинавский',
  'Лофт',
  'Минимализм',
  'Неоклассика',
  'Современная классика',
  'Японский',
  'Ар-деко',
];

const LS_KEY = 'ps_project_survey';

// ── Helpers ────────────────────────────────────────────
const cardVariants = {
  hidden: { opacity: 0, y: 24 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.06, duration: 0.35, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] },
  }),
};

const formatDateRussian = (date: Date) => {
  const months = [
    'января', 'февраля', 'марта', 'апреля', 'мая', 'июня',
    'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря',
  ];
  const days = ['воскресенье', 'понедельник', 'вторник', 'среда', 'четверг', 'пятница', 'суббота'];
  return `${days[date.getDay()]}, ${date.getDate()} ${months[date.getMonth()]} ${date.getFullYear()}`;
};

const getGreeting = () => {
  const hour = new Date().getHours();
  if (hour < 6) return 'Доброй ночи';
  if (hour < 12) return 'Доброе утро';
  if (hour < 18) return 'Добрый день';
  return 'Добрый вечер';
};

const getStyleName = (styleId: string, allStyles: Style[]) => {
  return allStyles.find((s) => s.id === styleId)?.name ?? 'Не указан';
};

const getStageName = (stageId: string, allStages: Stage[]) => {
  return allStages.find((s) => s.id === stageId)?.name ?? '';
};

// Parse budget option to numeric budget value
const budgetToValue = (budget: string): number => {
  switch (budget) {
    case 'under_10k': return 10000;
    case '10k_20k': return 15000;
    case '20k_30k': return 25000;
    case '30k_50k': return 40000;
    case 'over_50k': return 70000;
    default: return 0;
  }
};

const styleToSlug = (styleName: string): string => {
  const map: Record<string, string> = {
    'Скандинавский': 'scandinavian',
    'Лофт': 'loft',
    'Минимализм': 'minimalism',
    'Неоклассика': 'neoclassic',
    'Современная классика': 'modern-classic',
    'Японский': 'japanese',
    'Ар-деко': 'artdeco',
  };
  return map[styleName] || 'scandinavian';
};

const budgetToLabel = (value: string): string => {
  return BUDGET_OPTIONS.find((b) => b.value === value)?.label || value;
};

// ── Animated Progress Bar ───────────────────────────────
function AnimatedProgressBar({ value, delay = 0.3 }: { value: number; delay?: number }) {
  const [width, setWidth] = useState(0);
  useEffect(() => {
    const t = setTimeout(() => setWidth(value), delay * 1000);
    return () => clearTimeout(t);
  }, [value, delay]);

  return (
    <div className="w-full h-2 bg-[#e0dbd4] rounded-full overflow-hidden">
      <motion.div
        className="h-full bg-[#8b9d83] rounded-full"
        initial={{ width: 0 }}
        animate={{ width: `${width}%` }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] as [number, number, number, number], delay }}
      />
    </div>
  );
}

// ── Project Card ──────────────────────────────────────
function ProjectCard({
  project,
  styleName,
  stageName,
  index,
  onClick,
  isActive,
}: {
  project: Project;
  styleName: string;
  stageName: string;
  index: number;
  onClick: () => void;
  isActive?: boolean;
}) {
  const statusLabel =
    project.status === 'active'
      ? 'В работе'
      : project.status === 'completed'
        ? 'Завершен'
        : project.status === 'draft'
          ? 'Планирование'
          : 'В архиве';

  const statusColor =
    project.status === 'active'
      ? 'bg-[rgba(122,158,122,0.12)] text-[#5a7a5a]'
      : project.status === 'completed'
        ? 'bg-[#e8ede5] text-[#5c6b55]'
        : 'bg-[rgba(201,169,110,0.12)] text-[#8a7038]';

  return (
    <motion.div
      custom={index}
      initial="hidden"
      animate="visible"
      variants={cardVariants}
      onClick={onClick}
      className={`bg-white border rounded-xl p-4 cursor-pointer hover:shadow-md hover:-translate-y-0.5 transition-all duration-250 active:scale-[0.98] ${isActive ? 'border-[#8b9d83] ring-1 ring-[#8b9d83]' : 'border-[#e0dbd4]'}`}
    >
      <div className="flex gap-4">
        <div className="w-20 h-20 md:w-[120px] md:h-20 rounded-lg bg-[#ebe7e0] flex-shrink-0 overflow-hidden">
          <img
            src={`/style-${project.styleId === '1' ? 'scandi' : project.styleId === '2' ? 'loft' : 'minimal'}.jpg`}
            alt={project.name}
            className="w-full h-full object-cover"
            loading="lazy"
          />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between mb-1">
            <h4 className="text-base font-medium text-[#1a1a1a] truncate">
              {project.name}
            </h4>
            <ChevronRight size={18} className="text-[#9a9a9a] flex-shrink-0 mt-0.5" />
          </div>
          <p className="text-xs text-[#6b6b6b] mb-2">
            {project.area} м² · {styleName}
          </p>
          <div className="flex items-center gap-2 mb-2">
            <div className="flex-1">
              <AnimatedProgressBar value={project.progress} delay={0.3 + index * 0.1} />
            </div>
            <span className="text-xs text-[#6b6b6b] font-medium">{project.progress}%</span>
          </div>
          <p className="text-xs text-[#6b6b6b]">
            {stageName ? `Этап: ${stageName}` : 'Подготовка'}
          </p>
        </div>
      </div>
      <div className="flex items-center gap-2 mt-3 pt-3 border-t border-[#e0dbd4]">
        <span className={`text-[11px] font-medium uppercase tracking-[0.04em] px-2.5 py-1 rounded-lg ${statusColor}`}>
          {statusLabel}
        </span>
      </div>
    </motion.div>
  );
}

// ── Activity Item ─────────────────────────────────────
function ActivityItem({ item, index }: { item: ActivityItem; index: number }) {
  const Icon = item.icon;
  return (
    <motion.div
      custom={index}
      initial="hidden"
      animate="visible"
      variants={cardVariants}
      className="flex items-center gap-3 py-2.5"
    >
      <div className="w-8 h-8 rounded-full bg-[#e8ede5] flex items-center justify-center flex-shrink-0">
        <Icon size={14} className="text-[#8b9d83]" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm text-[#1a1a1a]">{item.text}</p>
      </div>
      <span className="text-xs text-[#9a9a9a] flex-shrink-0">{item.time}</span>
    </motion.div>
  );
}

// ── Survey Form Section ───────────────────────────────
function SurveyForm({
  formData,
  setFormData,
  errors,
  onSubmit,
  loading,
}: {
  formData: ProjectFormData;
  setFormData: React.Dispatch<React.SetStateAction<ProjectFormData>>;
  errors: FormErrors;
  onSubmit: (e: React.FormEvent) => void;
  loading: boolean;
}) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const updateField = <K extends keyof ProjectFormData>(key: K, value: ProjectFormData[K]) => {
    setFormData((prev) => ({ ...prev, [key]: value }));
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const base64 = ev.target?.result as string;
      setFormData((prev) => ({ ...prev, photos: [...prev.photos, base64] }));
    };
    reader.readAsDataURL(file);
    // Reset input so same file can be selected again
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const removePhoto = (index: number) => {
    setFormData((prev) => ({ ...prev, photos: prev.photos.filter((_, i) => i !== index) }));
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
      className="max-w-[640px] mx-auto"
    >
      <div className="bg-white rounded-2xl border border-[#e0dbd4] shadow-sm p-6 md:p-8">
        <div className="mb-8">
          <h2 className="font-serif text-2xl font-semibold text-[#1a1a1a] mb-2">
            Добро пожаловать!
          </h2>
          <p className="text-[#6b6b6b]">Расскажите о вашем проекте</p>
        </div>

        <form onSubmit={onSubmit} className="space-y-5">
          {/* 1. Project name */}
          <div>
            <label className="block text-sm font-medium text-[#1a1a1a] mb-1.5">
              1. Название проекта <span className="text-[#c47d7d]">*</span>
            </label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => updateField('name', e.target.value)}
              placeholder="Например, Квартира на Арбате"
              className={`w-full rounded-xl border ${errors.name ? 'border-[#c47d7d]' : 'border-[#e0dbd4]'} px-4 py-3 text-sm text-[#1a1a1a] placeholder:text-[#9a9a9a] focus:outline-none focus:ring-2 focus:ring-[#8b9d83]/30 focus:border-[#8b9d83] transition-all bg-[#faf9f7]`}
            />
            {errors.name && <p className="text-xs text-[#c47d7d] mt-1">{errors.name}</p>}
          </div>

          {/* 2. City */}
          <div>
            <label className="block text-sm font-medium text-[#1a1a1a] mb-1.5">
              2. Город <span className="text-[#c47d7d]">*</span>
            </label>
            <input
              type="text"
              value={formData.city}
              onChange={(e) => updateField('city', e.target.value)}
              placeholder="Москва, Санкт-Петербург..."
              className={`w-full rounded-xl border ${errors.city ? 'border-[#c47d7d]' : 'border-[#e0dbd4]'} px-4 py-3 text-sm text-[#1a1a1a] placeholder:text-[#9a9a9a] focus:outline-none focus:ring-2 focus:ring-[#8b9d83]/30 focus:border-[#8b9d83] transition-all bg-[#faf9f7]`}
            />
            {errors.city && <p className="text-xs text-[#c47d7d] mt-1">{errors.city}</p>}
          </div>

          {/* 3. Area */}
          <div>
            <label className="block text-sm font-medium text-[#1a1a1a] mb-1.5">
              3. Общая площадь (м²) <span className="text-[#c47d7d]">*</span>
            </label>
            <input
              type="number"
              value={formData.area}
              onChange={(e) => updateField('area', e.target.value)}
              placeholder="45"
              min={1}
              className={`w-full rounded-xl border ${errors.area ? 'border-[#c47d7d]' : 'border-[#e0dbd4]'} px-4 py-3 text-sm text-[#1a1a1a] placeholder:text-[#9a9a9a] focus:outline-none focus:ring-2 focus:ring-[#8b9d83]/30 focus:border-[#8b9d83] transition-all bg-[#faf9f7]`}
            />
            {errors.area && <p className="text-xs text-[#c47d7d] mt-1">{errors.area}</p>}
          </div>

          {/* 4. Rooms */}
          <div>
            <label className="block text-sm font-medium text-[#1a1a1a] mb-2">
              4. Количество комнат <span className="text-[#c47d7d]">*</span>
            </label>
            <div className="flex flex-wrap gap-2">
              {ROOM_OPTIONS.map((num) => (
                <label
                  key={num}
                  className={`cursor-pointer select-none px-4 py-2.5 rounded-xl border text-sm font-medium transition-all ${
                    formData.rooms === num
                      ? 'bg-[#8b9d83] text-white border-[#8b9d83]'
                      : 'bg-white text-[#1a1a1a] border-[#e0dbd4] hover:border-[#8b9d83] hover:bg-[#f4f7f3]'
                  }`}
                >
                  <input
                    type="radio"
                    name="rooms"
                    className="sr-only"
                    checked={formData.rooms === num}
                    onChange={() => updateField('rooms', num)}
                  />
                  {num === 4 ? '4+' : num}
                </label>
              ))}
            </div>
            {errors.rooms && <p className="text-xs text-[#c47d7d] mt-1">{errors.rooms}</p>}
          </div>

          {/* 5. Budget */}
          <div>
            <label className="block text-sm font-medium text-[#1a1a1a] mb-2">
              5. Планируемый бюджет <span className="text-[#c47d7d]">*</span>
            </label>
            <div className="flex flex-wrap gap-2">
              {BUDGET_OPTIONS.map((opt) => (
                <label
                  key={opt.value}
                  className={`cursor-pointer select-none px-4 py-2.5 rounded-xl border text-sm font-medium transition-all ${
                    formData.budget === opt.value
                      ? 'bg-[#8b9d83] text-white border-[#8b9d83]'
                      : 'bg-white text-[#1a1a1a] border-[#e0dbd4] hover:border-[#8b9d83] hover:bg-[#f4f7f3]'
                  }`}
                >
                  <input
                    type="radio"
                    name="budget"
                    className="sr-only"
                    checked={formData.budget === opt.value}
                    onChange={() => updateField('budget', opt.value)}
                  />
                  {opt.label}
                </label>
              ))}
            </div>
            {errors.budget && <p className="text-xs text-[#c47d7d] mt-1">{errors.budget}</p>}
          </div>

          {/* 6. Style */}
          <div>
            <label className="block text-sm font-medium text-[#1a1a1a] mb-1.5">
              6. Предпочтительный стиль <span className="text-[#c47d7d]">*</span>
            </label>
            <div className="relative">
              <select
                value={formData.style}
                onChange={(e) => updateField('style', e.target.value)}
                className={`w-full rounded-xl border ${errors.style ? 'border-[#c47d7d]' : 'border-[#e0dbd4]'} px-4 py-3 text-sm text-[#1a1a1a] focus:outline-none focus:ring-2 focus:ring-[#8b9d83]/30 focus:border-[#8b9d83] transition-all bg-[#faf9f7] appearance-none cursor-pointer`}
              >
                <option value="" disabled>Выберите стиль</option>
                {STYLE_OPTIONS.map((s) => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
              <ChevronRight size={16} className="absolute right-4 top-1/2 -translate-y-1/2 text-[#9a9a9a] rotate-90 pointer-events-none" />
            </div>
            {errors.style && <p className="text-xs text-[#c47d7d] mt-1">{errors.style}</p>}
          </div>

          {/* 7. Photo upload */}
          <div>
            <label className="block text-sm font-medium text-[#1a1a1a] mb-2">
              7. Загрузите фото текущего состояния
            </label>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handlePhotoUpload}
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="inline-flex items-center gap-2 border border-dashed border-[#e0dbd4] rounded-xl px-5 py-3 text-sm text-[#6b6b6b] hover:border-[#8b9d83] hover:text-[#8b9d83] hover:bg-[#f4f7f3] transition-all"
            >
              <Plus size={18} />
              Добавить фото
            </button>

            {/* Photo preview grid */}
            {formData.photos.length > 0 && (
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-3 mt-4">
                {formData.photos.map((photo, i) => (
                  <div key={i} className="relative group aspect-square rounded-xl overflow-hidden border border-[#e0dbd4] bg-[#faf9f7]">
                    <img src={photo} alt={`Фото ${i + 1}`} className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={() => removePhoto(i)}
                      className="absolute top-1 right-1 w-6 h-6 bg-[#1a1a1a]/60 hover:bg-[#c47d7d] text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X size={12} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Submit */}
          <div className="pt-4">
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-[#8b9d83] text-white text-sm font-medium px-6 py-3.5 rounded-xl hover:bg-[#6b7a64] transition-colors active:scale-[0.98] disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {loading ? (
                <RefreshCw size={18} className="animate-spin" />
              ) : (
                <>
                  Создать проект
                  <ArrowRight size={18} />
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </motion.div>
  );
}

// ── Filled Dashboard View ───────────────────────────────
function FilledDashboard({
  formData,
  onEdit,
  data,
  currentProject,
  setCurrentProjectId,
  navigate,
  activityItems,
  activityOpen,
  setActivityOpen,
}: {
  formData: ProjectFormData;
  onEdit: () => void;
  data: DashboardData;
  currentProject: Project | null;
  setCurrentProjectId: (id: string | null) => void;
  navigate: ReturnType<typeof useNavigate>;
  activityItems: ActivityItem[];
  activityOpen: boolean;
  setActivityOpen: (v: boolean) => void;
}) {
  const areaNum = Number(formData.area) || 0;
  const budgetLabel = budgetToLabel(formData.budget);

  return (
    <div className="space-y-6">
      {/* Project Overview Card */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
        className="bg-white rounded-2xl border border-[#e0dbd4] shadow-sm p-6 md:p-8"
      >
        <div className="flex items-start justify-between mb-6">
          <div>
            <span className="text-[11px] font-medium uppercase tracking-[0.08em] text-[#8b9d83]">
              ПРОЕКТ
            </span>
            <h2 className="font-serif text-2xl font-semibold text-[#1a1a1a] mt-1">
              {formData.name}
            </h2>
            <p className="text-sm text-[#6b6b6b] mt-1 flex items-center gap-1">
              <MapPin size={14} />
              {formData.city}
            </p>
          </div>
          <button
            onClick={onEdit}
            className="flex items-center gap-1.5 text-sm font-medium text-[#8b9d83] hover:text-[#6b7a64] transition-colors border border-[#e0dbd4] rounded-xl px-3 py-2 hover:bg-[#f4f7f3]"
          >
            <Pencil size={14} />
            Редактировать
          </button>
        </div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-[#faf9f7] rounded-xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <SquareStack size={16} className="text-[#8b9d83]" />
              <span className="text-xs text-[#9a9a9a] uppercase tracking-wider font-medium">Площадь</span>
            </div>
            <p className="text-lg font-semibold text-[#1a1a1a]">{areaNum} м²</p>
          </div>
          <div className="bg-[#faf9f7] rounded-xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <Home size={16} className="text-[#8b9d83]" />
              <span className="text-xs text-[#9a9a9a] uppercase tracking-wider font-medium">Комнат</span>
            </div>
            <p className="text-lg font-semibold text-[#1a1a1a]">{formData.rooms === 4 ? '4+' : formData.rooms}</p>
          </div>
          <div className="bg-[#faf9f7] rounded-xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <Wallet size={16} className="text-[#8b9d83]" />
              <span className="text-xs text-[#9a9a9a] uppercase tracking-wider font-medium">Бюджет</span>
            </div>
            <p className="text-lg font-semibold text-[#1a1a1a]">{budgetLabel}</p>
          </div>
          <div className="bg-[#faf9f7] rounded-xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <Palette size={16} className="text-[#8b9d83]" />
              <span className="text-xs text-[#9a9a9a] uppercase tracking-wider font-medium">Стиль</span>
            </div>
            <p className="text-lg font-semibold text-[#1a1a1a]">{formData.style}</p>
          </div>
        </div>

        {/* Progress */}
        <div className="mt-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-[#1a1a1a]">Прогресс проекта</span>
            <span className="text-sm text-[#6b6b6b]">0%</span>
          </div>
          <AnimatedProgressBar value={0} delay={0.2} />
          <p className="text-xs text-[#9a9a9a] mt-2">Начните планирование, чтобы отслеживать прогресс</p>
        </div>
      </motion.div>

      {/* Photo Gallery */}
      {formData.photos.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
          className="bg-white rounded-2xl border border-[#e0dbd4] shadow-sm p-6 md:p-8"
        >
          <div className="flex items-center gap-2 mb-4">
            <ImageIcon size={18} className="text-[#8b9d83]" />
            <h3 className="font-serif text-lg font-semibold text-[#1a1a1a]">
              Фото текущего состояния
            </h3>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {formData.photos.map((photo, i) => (
              <div key={i} className="aspect-square rounded-xl overflow-hidden border border-[#e0dbd4] bg-[#faf9f7]">
                <img src={photo} alt={`Фото ${i + 1}`} className="w-full h-full object-cover" />
              </div>
            ))}
          </div>
        </motion.div>
      )}

      {/* Active Projects from API */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
      >
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-serif text-lg font-semibold text-[#1a1a1a]">
            Ваши проекты
          </h2>
          <button
            onClick={() => navigate('/register')}
            className="flex items-center gap-1.5 text-sm font-medium text-[#8b9d83] hover:text-[#6b7a64] transition-colors"
          >
            <Plus size={16} />
            Новый проект
          </button>
        </div>

        {data.projects.length === 0 ? (
          <EmptyState
            title="Начните ваш первый ремонт"
            description="Создайте проект — и AI поможет с планом"
            ctaLabel="Создать проект"
            ctaHref="/register"
          />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <AnimatePresence>
              {data.projects.map((project, i) => (
                <ProjectCard
                  key={project.id}
                  project={project}
                  styleName={getStyleName(project.styleId, data.allStyles)}
                  stageName={getStageName(project.currentStageId, data.allStages)}
                  index={i}
                  isActive={currentProject?.id === project.id}
                  onClick={() => { setCurrentProjectId(project.id); navigate(`/planning`); }}
                />
              ))}
            </AnimatePresence>
          </div>
        )}
      </motion.div>

      {/* Recent Activity */}
      {activityItems.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.3, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
          className="bg-white border border-[#e0dbd4] rounded-xl p-4 md:p-5"
        >
          <button
            onClick={() => setActivityOpen(!activityOpen)}
            className="flex items-center justify-between w-full mb-2"
          >
            <h3 className="font-serif text-base font-semibold text-[#1a1a1a]">
              Недавняя активность
            </h3>
            <motion.div
              animate={{ rotate: activityOpen ? 0 : -90 }}
              transition={{ duration: 0.2 }}
            >
              <ChevronRight size={18} className="text-[#9a9a9a]" />
            </motion.div>
          </button>
          <AnimatePresence>
            {activityOpen && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.25 }}
                className="overflow-hidden"
              >
                <div className="divide-y divide-[#e0dbd4]">
                  {activityItems.map((item, i) => (
                    <ActivityItem key={item.id} item={item} index={i} />
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      )}
    </div>
  );
}

// ── Main Dashboard Page ───────────────────────────────
export default function Dashboard() {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const { currentProject, setCurrentProjectId } = useProject();
  const { showToast } = useToast();
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<DashboardData>({ projects: [], allStyles: [], allStages: [], progressMap: {} });
  const [activityOpen, setActivityOpen] = useState(true);

  // Load persisted form data
  const [formData, setFormData] = useState<ProjectFormData>(() => {
    try {
      const saved = localStorage.getItem(LS_KEY);
      if (saved) return JSON.parse(saved);
    } catch { /* ignore */ }
    return {
      name: '',
      city: '',
      area: '',
      rooms: 0,
      budget: '',
      style: '',
      photos: [],
      created: false,
    };
  });

  const [errors, setErrors] = useState<FormErrors>({});
  const [isEditing, setIsEditing] = useState(false);

  // Persist form data on change
  useEffect(() => {
    localStorage.setItem(LS_KEY, JSON.stringify(formData));
  }, [formData]);

  const fetchDashboard = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [projList, styleList, stageList] = await Promise.all([
        projects.list(),
        styles.list(),
        stages.list(),
      ]);

      const progressMap: Record<string, ProjectStage[]> = {};
      await Promise.all(
        projList.map(async (p) => {
          progressMap[p.id] = await stages.getProgress(p.id);
        })
      );

      setData({ projects: projList, allStyles: styleList, allStages: stageList, progressMap });
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Не удалось загрузить проекты');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchDashboard();
  }, [fetchDashboard]);

  // Filter out demo project from user's list
  const userProjects = useMemo(() => {
    return data.projects.filter((p) => p.id !== 'demo-lavada');
  }, [data.projects]);

  const activeProject = useMemo(() => {
    return userProjects.find((p) => p.status === 'active');
  }, [userProjects]);

  const activityItems: ActivityItem[] = useMemo(() => {
    const items: ActivityItem[] = [];
    if (formData.created) {
      items.push({
        id: 'survey',
        icon: Sparkles,
        text: `Создан проект «${formData.name}»`,
        time: 'Только что',
      });
    }
    if (userProjects.length > 0) {
      items.push({
        id: '1',
        icon: Home,
        text: `Добавлен проект «${userProjects[0].name}»`,
        time: '2 часа назад',
      });
    }
    if (activeProject) {
      items.push({
        id: '2',
        icon: CheckSquare,
        text: `Этап «${getStageName(activeProject.currentStageId, data.allStages)}» начат`,
        time: 'Вчера',
      });
    }
    items.push(
      { id: '3', icon: Sparkles, text: 'Составлен план ремонта', time: '3 дня назад' },
      { id: '4', icon: Plus, text: 'Обновлен дизайн-проект', time: '5 дней назад' }
    );
    return items.slice(0, 5);
  }, [userProjects, activeProject, data.allStages, formData]);

  const validateForm = (): boolean => {
    const newErrors: FormErrors = {};
    if (!formData.name.trim() || formData.name.trim().length < 2) {
      newErrors.name = 'Название обязательно, минимум 2 символа';
    }
    if (!formData.city.trim()) {
      newErrors.city = 'Укажите город';
    }
    const areaNum = Number(formData.area);
    if (!formData.area || isNaN(areaNum) || areaNum <= 0) {
      newErrors.area = 'Укажите площадь больше 0';
    }
    if (!formData.rooms) {
      newErrors.rooms = 'Выберите количество комнат';
    }
    if (!formData.budget) {
      newErrors.budget = 'Выберите бюджет';
    }
    if (!formData.style) {
      newErrors.style = 'Выберите стиль';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    setSubmitting(true);
    try {
      // Create project in mock API
      const areaNum = Number(formData.area);
      const budgetVal = budgetToValue(formData.budget);
      const styleSlug = styleToSlug(formData.style);

      await projects.create({
        name: formData.name,
        area: areaNum,
        budget: budgetVal,
        styleId: styleSlug,
      });

      setFormData((prev) => ({ ...prev, created: true }));
      setIsEditing(false);
      showToast('Проект создан!', 'success');

      // Refresh project list
      await fetchDashboard();
    } catch (err) {
      showToast(err instanceof Error ? err.message : 'Ошибка создания проекта', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const handleEdit = () => {
    setIsEditing(true);
  };

  const handleLogout = useCallback(() => {
    logout();
    showToast('Вы вышли из аккаунта', 'info');
  }, [logout, showToast]);


  if (loading) {
    return (
      <div className="min-h-[100dvh] bg-[#f7f5f2] px-4 md:px-8 py-4 pb-24 md:pb-8">
        <div className="max-w-[960px] mx-auto">
          {/* Header skeleton */}
          <div className="flex items-center justify-between mb-6">
            <div className="space-y-2">
              <div className="skeleton-shimmer h-7 w-48 rounded-md" />
              <div className="skeleton-shimmer h-4 w-32 rounded-md" />
            </div>
            <div className="skeleton-shimmer w-10 h-10 rounded-full" />
          </div>
          {/* Form skeleton */}
          <div className="max-w-[640px] mx-auto space-y-4">
            <div className="skeleton-shimmer h-12 rounded-xl" />
            <div className="skeleton-shimmer h-12 rounded-xl" />
            <div className="skeleton-shimmer h-12 rounded-xl" />
            <div className="skeleton-shimmer h-24 rounded-xl" />
            <div className="skeleton-shimmer h-24 rounded-xl" />
          </div>
        </div>
      </div>
    );
  }

  // Error state
  if (error) {
    return (
      <div className="min-h-[100dvh] bg-[#f7f5f2] flex items-center justify-center px-4">
        <div className="text-center">
          <AlertCircle size={48} className="text-[#c47d7d] mx-auto mb-4" />
          <h3 className="font-serif text-xl font-semibold text-[#1a1a1a] mb-2">
            Не удалось загрузить проекты
          </h3>
          <p className="text-sm text-[#6b6b6b] mb-6">{error}</p>
          <button
            onClick={fetchDashboard}
            className="inline-flex items-center gap-2 border border-[#e0dbd4] text-[#1a1a1a] text-sm font-medium px-5 py-2.5 rounded-xl hover:bg-[#e8ede5] transition-colors"
          >
            <RefreshCw size={16} />
            Обновить
          </button>
        </div>
      </div>
    );
  }

  // Determine which view to show
  const showSurvey = !formData.created || isEditing;

  return (
    <div className="min-h-[100dvh] bg-[#f7f5f2] px-4 md:px-8 py-4 pb-24 md:pb-8">
      <div className="max-w-[960px] mx-auto">
        {/* ── Header ── */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
          className="flex items-start justify-between mb-6"
        >
          <div>
            <h1 className="font-serif text-2xl font-semibold text-[#1a1a1a] mb-1">
              {getGreeting()}, {user?.name || 'друг'}!
            </h1>
            <p className="text-sm text-[#9a9a9a]">{formatDateRussian(new Date())}</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => navigate('/settings')}
              className="relative p-2.5 rounded-xl hover:bg-[rgba(139,157,131,0.08)] transition-colors"
            >
              <Bell size={22} className="text-[#1a1a1a]" />
              {activityItems.length > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-[#c47d7d] rounded-full" />
              )}
            </button>
            <button
              onClick={handleLogout}
              className="p-2.5 rounded-xl hover:bg-[rgba(139,157,131,0.08)] transition-colors text-[#1a1a1a]"
              title="Выйти"
            >
              <LogOut size={22} />
            </button>
          </div>
        </motion.div>

        <AnimatePresence mode="wait">
          {showSurvey ? (
            <motion.div
              key="survey"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              <SurveyForm
                formData={formData}
                setFormData={setFormData}
                errors={errors}
                onSubmit={handleSubmit}
                loading={submitting}
              />
            </motion.div>
          ) : (
            <motion.div
              key="dashboard"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              <FilledDashboard
                formData={formData}
                onEdit={handleEdit}
                data={data}
                currentProject={currentProject}
                setCurrentProjectId={setCurrentProjectId}
                navigate={navigate}
                activityItems={activityItems}
                activityOpen={activityOpen}
                setActivityOpen={setActivityOpen}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
