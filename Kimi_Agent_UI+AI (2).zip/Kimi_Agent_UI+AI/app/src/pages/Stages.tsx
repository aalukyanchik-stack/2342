import { useState, useEffect, useCallback, useRef, type KeyboardEvent } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  PenTool,
  Hammer,
  Zap,
  Droplet,
  BrickWall,
  Paintbrush,
  Grid3x3,
  DoorOpen,
  Sofa,
  Sparkles,
  Check,
  Plus,
  Trash2,
  ArrowUp,
  ArrowDown,
  X,
  Calculator,
} from 'lucide-react';
import TodayBanner from '@/components/stages/TodayBanner';
import EmptyState from '@/components/EmptyState';
import { useToast } from '@/components/Toast';

/* ------------------------------------------------------------------ */
/*  Types                                                               */
/* ------------------------------------------------------------------ */

interface Stage {
  id: number;
  name: string;
  duration: string;
  works: string[];
  materials: string[];
  cost: number;
  completed: boolean;
}

/* ------------------------------------------------------------------ */
/*  Defaults                                                            */
/* ------------------------------------------------------------------ */

const DEFAULT_STAGES: Stage[] = [
  {
    id: 1,
    name: 'Дизайн-проект',
    duration: '7–14 дней',
    works: ['Разработка концепции интерьера', 'Планировка помещений', 'Подбор материалов и мебели', '3D-визуализация'],
    materials: ['Каталоги отделочных материалов', 'Образцы покрытий'],
    cost: 50000,
    completed: false,
  },
  {
    id: 2,
    name: 'Демонтаж',
    duration: '2–5 дней',
    works: ['Снос стен и перегородок', 'Демонтаж старых покрытий', 'Вывоз строительного мусора', 'Подготовка поверхностей'],
    materials: ['Мешки для мусора', 'Защитная плёнка'],
    cost: 15000,
    completed: false,
  },
  {
    id: 3,
    name: 'Электрика',
    duration: '5–10 дней',
    works: ['Составление схемы электропроводки', 'Прокладка кабелей', 'Установка щитка', 'Монтаж розеток и выключателей', 'Проверка заземления'],
    materials: ['Кабель ВВГнг 100м', 'Розетки Legrand', 'Автоматы', 'Щиток'],
    cost: 55000,
    completed: false,
  },
  {
    id: 4,
    name: 'Сантехника',
    duration: '3–7 дней',
    works: ['Замена стояков', 'Прокладка труб горячей и холодной воды', 'Монтаж канализации', 'Установка смесителей и сантехники', 'Проверка герметичности'],
    materials: ['Трубы PPR', 'Фитинги', 'Смесители', 'Унитаз', 'Ванна'],
    cost: 65000,
    completed: false,
  },
  {
    id: 5,
    name: 'Черновая отделка',
    duration: '7–14 дней',
    works: ['Штукатурка стен', 'Стяжка полов', 'Гидроизоляция в мокрых зонах', 'Монтаж гипсокартонных потолков', 'Закрытие штроб'],
    materials: ['Штукатурка', 'Гипсокартон', 'Гидроизоляция', 'Армирующая сетка'],
    cost: 80000,
    completed: false,
  },
  {
    id: 6,
    name: 'Чистовая отделка',
    duration: '10–20 дней',
    works: ['Покраска стен и потолков', 'Поклейка обоев', 'Укладка плитки', 'Установка плинтусов', 'Монтаж светильников'],
    materials: ['Краска', 'Обои', 'Плитка', 'Плинтус', 'Грунтовка'],
    cost: 95000,
    completed: false,
  },
  {
    id: 7,
    name: 'Полы',
    duration: '3–7 дней',
    works: ['Подготовка основания', 'Укладка подложки', 'Укладка ламината/паркета', 'Установка порожков', 'Проверка стыков'],
    materials: ['Ламинат', 'Подложка', 'Порожки', 'Клей'],
    cost: 70000,
    completed: false,
  },
  {
    id: 8,
    name: 'Установка дверей и окон',
    duration: '2–5 дней',
    works: ['Замер проёмов', 'Установка входной двери', 'Установка межкомнатных дверей', 'Монтаж подоконников', 'Фурнитура'],
    materials: ['Двери', 'Подоконники', 'Фурнитура', 'Пена монтажная'],
    cost: 60000,
    completed: false,
  },
  {
    id: 9,
    name: 'Мебель и техника',
    duration: '3–7 дней',
    works: ['Привоз и проверка мебели', 'Сборка корпусной мебели', 'Подключение бытовой техники', 'Монтаж штор и карнизов', 'Расстановка декора'],
    materials: ['Мебель', 'Крепёж', 'Шторы', 'Карнизы'],
    cost: 120000,
    completed: false,
  },
  {
    id: 10,
    name: 'Финальная уборка',
    duration: '1–2 дня',
    works: ['Удаление строительной пыли', 'Мытьё окон', 'Протирка всех поверхностей', 'Вывоз мусора и упаковки', 'Финальная приёмка'],
    materials: ['Моющие средства', 'Ведро', 'Тряпки', 'Мусорные мешки'],
    cost: 8000,
    completed: false,
  },
];

const STAGE_ICONS: React.ElementType[] = [
  PenTool, Hammer, Zap, Droplet, BrickWall,
  Paintbrush, Grid3x3, DoorOpen, Sofa, Sparkles,
];

/* ------------------------------------------------------------------ */
/*  Storage helpers                                                     */
/* ------------------------------------------------------------------ */

function getStore<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function setStore<T>(key: string, value: T) {
  localStorage.setItem(key, JSON.stringify(value));
}

/* ------------------------------------------------------------------ */
/*  Component                                                           */
/* ------------------------------------------------------------------ */

export default function Stages() {
  const [stages, setStages] = useState<Stage[]>(() =>
    getStore<Stage[]>('ps_stages', DEFAULT_STAGES)
  );
  const [loading, setLoading] = useState(true);
  const [celebratingStageId, setCelebratingStageId] = useState<number | null>(null);
  const [allComplete, setAllComplete] = useState(false);
  const [deleteConfirmId, setDeleteConfirmId] = useState<number | null>(null);

  // Inline editing state
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editField, setEditField] = useState<string>('');
  const [editValue, setEditValue] = useState('');
  const [editIndex, setEditIndex] = useState<number | null>(null); // for array fields

  const { showToast } = useToast();
  const timelineRef = useRef<HTMLDivElement>(null);

  // Fake loading to match UX
  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 300);
    return () => clearTimeout(t);
  }, []);

  // Auto-save
  useEffect(() => {
    setStore('ps_stages', stages);
    const allDone = stages.length > 0 && stages.every((s) => s.completed);
    setAllComplete(allDone);
  }, [stages]);

  /* ---------------- Totals ---------------- */
  const totalCost = stages.reduce((sum, s) => sum + (s.cost || 0), 0);
  const completedCount = stages.filter((s) => s.completed).length;
  const progressPercent = stages.length > 0
    ? Math.round((completedCount / stages.length) * 100)
    : 0;

  const currentStage = stages.find((s) => !s.completed);
  const daysRemaining = currentStage ? 7 : 0;

  /* ---------------- Inline edit helpers ---------------- */
  const startEdit = useCallback((stageId: number, field: string, value: string, index?: number) => {
    setEditingId(stageId);
    setEditField(field);
    setEditValue(value);
    setEditIndex(index ?? null);
  }, []);

  const saveEdit = useCallback(() => {
    setStages((prev) =>
      prev.map((s) => {
        if (s.id !== editingId) return s;
        if (editField === 'name') return { ...s, name: editValue };
        if (editField === 'duration') return { ...s, duration: editValue };
        if (editField === 'cost') return { ...s, cost: parseFloat(editValue) || 0 };
        if (editField === 'works' && editIndex !== null) {
          const updated = [...s.works];
          updated[editIndex] = editValue;
          return { ...s, works: updated };
        }
        if (editField === 'materials' && editIndex !== null) {
          const updated = [...s.materials];
          updated[editIndex] = editValue;
          return { ...s, materials: updated };
        }
        return s;
      })
    );
    setEditingId(null);
    setEditField('');
    setEditValue('');
    setEditIndex(null);
  }, [editingId, editField, editValue, editIndex]);

  const cancelEdit = useCallback(() => {
    setEditingId(null);
    setEditField('');
    setEditValue('');
    setEditIndex(null);
  }, []);

  const handleKeyDown = useCallback(
    (e: KeyboardEvent<HTMLInputElement>) => {
      if (e.key === 'Enter') saveEdit();
      if (e.key === 'Escape') cancelEdit();
    },
    [saveEdit, cancelEdit]
  );

  /* ---------------- Array field helpers ---------------- */
  const addArrayItem = useCallback((stageId: number, field: 'works' | 'materials') => {
    setStages((prev) =>
      prev.map((s) =>
        s.id === stageId
          ? { ...s, [field]: [...s[field], ''] }
          : s
      )
    );
    // Auto-focus the new empty item
    const stage = stages.find((s) => s.id === stageId);
    const newIndex = stage ? stage[field].length : 0;
    setTimeout(() => startEdit(stageId, field, '', newIndex), 0);
  }, [stages, startEdit]);

  const removeArrayItem = useCallback(
    (stageId: number, field: 'works' | 'materials', index: number) => {
      setStages((prev) =>
        prev.map((s) => {
          if (s.id !== stageId) return s;
          const updated = [...s[field]];
          updated.splice(index, 1);
          return { ...s, [field]: updated };
        })
      );
    },
    []
  );

  /* ---------------- Reorder ---------------- */
  const moveStage = useCallback((index: number, direction: 'up' | 'down') => {
    setStages((prev) => {
      const newArr = [...prev];
      const targetIndex = direction === 'up' ? index - 1 : index + 1;
      if (targetIndex < 0 || targetIndex >= newArr.length) return prev;
      [newArr[index], newArr[targetIndex]] = [newArr[targetIndex], newArr[index]];
      return newArr;
    });
  }, []);

  /* ---------------- Add / Delete ---------------- */
  const addStage = useCallback(() => {
    setStages((prev) => {
      const newId = prev.length > 0 ? Math.max(...prev.map((s) => s.id)) + 1 : 1;
      return [
        ...prev,
        {
          id: newId,
          name: 'Новый этап',
          duration: '1 день',
          works: [],
          materials: [],
          cost: 0,
          completed: false,
        },
      ];
    });
    showToast('Этап добавлен');
  }, [showToast]);

  const confirmDelete = useCallback((stageId: number) => {
    setDeleteConfirmId(stageId);
  }, []);

  const doDelete = useCallback(() => {
    if (deleteConfirmId === null) return;
    setStages((prev) => prev.filter((s) => s.id !== deleteConfirmId));
    setDeleteConfirmId(null);
    showToast('Этап удалён');
  }, [deleteConfirmId, showToast]);

  /* ---------------- Toggle complete ---------------- */
  const toggleComplete = useCallback((stageId: number) => {
    setStages((prev) =>
      prev.map((s) => {
        if (s.id !== stageId) return s;
        const completed = !s.completed;
        if (completed) {
          setCelebratingStageId(stageId);
          setTimeout(() => setCelebratingStageId(null), 2000);
          showToast('Этап завершён! 🎉');
        }
        return { ...s, completed };
      })
    );
  }, [showToast]);

  /* ---------------- Scroll to current ---------------- */
  const scrollToCurrent = useCallback(() => {
    if (currentStage && timelineRef.current) {
      const el = document.getElementById(`stage-card-${currentStage.id}`);
      el?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }, [currentStage]);

  /* ---------------- Loading ---------------- */
  if (loading) {
    return (
      <div className="min-h-[100dvh] bg-background px-4 md:px-8 py-6 md:pt-10">
        <div className="max-w-[900px] mx-auto">
          <div className="h-8 w-48 bg-olive-200 rounded animate-pulse mb-2" />
          <div className="h-4 w-72 bg-olive-200 rounded animate-pulse mb-6" />
          <div className="h-3 w-full bg-olive-200 rounded-full animate-pulse mb-8" />
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="flex gap-4 mb-4">
              <div className="w-7 h-7 bg-olive-200 rounded-full shrink-0" />
              <div className="flex-1 h-20 bg-olive-200 rounded-xl animate-pulse" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (stages.length === 0) {
    return (
      <div className="min-h-[100dvh] bg-background flex items-center justify-center px-4">
        <EmptyState
          title="Нет этапов"
          description="Добавьте первый этап ремонта"
          ctaLabel="Добавить этап"
          ctaHref="#"
          onCtaClick={addStage}
        />
      </div>
    );
  }

  return (
    <motion.div
      className="min-h-[100dvh] bg-background px-4 md:px-8 py-6 md:pt-10 pb-24 md:pb-10"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
    >
      <div className="max-w-[900px] mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="font-serif text-2xl md:text-[28px] font-semibold text-text mb-1">
            Этапы ремонта
          </h1>
          <p className="text-sm text-muted mb-4">
            {stages.length} этапов · Общая стоимость{' '}
            <span className="font-medium text-text">{totalCost.toLocaleString()} ₽</span>
          </p>

          {/* Overall Progress */}
          <div className="flex items-center gap-4">
            <div className="flex-1 h-3 bg-border rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-accent rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${progressPercent}%` }}
                transition={{ duration: 0.8, delay: 0.2, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
              />
            </div>
            <span className="text-sm font-medium text-text whitespace-nowrap">
              {progressPercent}% завершено
            </span>
          </div>
          {currentStage && (
            <p className="text-xs text-muted mt-2">
              Осталось ~{Math.max(0, stages.filter((s) => !s.completed).length * 7)} дней
            </p>
          )}
        </div>

        {/* Today Banner */}
        <AnimatePresence>
          {currentStage && (
            <TodayBanner
              stageName={currentStage.name}
              stageNumber={stages.findIndex((s) => s.id === currentStage.id) + 1}
              daysRemaining={daysRemaining}
              onNavigate={scrollToCurrent}
            />
          )}
        </AnimatePresence>

        {/* Timeline */}
        <div ref={timelineRef} className="space-y-0">
          {stages.map((stage, index) => {
            const Icon = STAGE_ICONS[index] || PenTool;
            const dotColor = stage.completed ? '#7a9e7a' : '#8b9d83';
            const isLast = index === stages.length - 1;

            return (
              <div key={stage.id} id={`stage-card-${stage.id}`} className="relative flex gap-4">
                {/* Timeline line + dot */}
                <div className="flex flex-col items-center shrink-0 w-7">
                  <motion.div
                    className="w-7 h-7 rounded-full flex items-center justify-center shrink-0 border-2 z-10"
                    style={{
                      borderColor: dotColor,
                      backgroundColor: stage.completed ? '#7a9e7a' : '#ffffff',
                    }}
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: 'spring', stiffness: 400, damping: 20, delay: index * 0.05 }}
                  >
                    {stage.completed ? (
                      <Check size={14} className="text-white" strokeWidth={3} />
                    ) : (
                      <div className="w-2 h-2 rounded-full bg-accent" />
                    )}
                  </motion.div>
                  {!isLast && (
                    <div
                      className="w-0.5 flex-1 mt-1"
                      style={{
                        background: stage.completed ? '#7a9e7a' : '#e0dbd4',
                        opacity: 0.5,
                      }}
                    />
                  )}
                </div>

                {/* Editable Card */}
                <motion.div
                  className={`flex-1 bg-white rounded-2xl border border-[#e0dbd4] shadow-sm p-4 mb-4 ${
                    stage.completed ? 'border-l-4 border-l-[#7a9e7a]' : ''
                  }`}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.08, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
                >
                  {/* Card header: name + actions */}
                  <div className="flex items-start gap-3 mb-3">
                    <div className="w-9 h-9 rounded-lg bg-olive-100 flex items-center justify-center shrink-0">
                      <Icon size={18} className="text-accent" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        {/* Editable name */}
                        {editingId === stage.id && editField === 'name' ? (
                          <input
                            autoFocus
                            className="text-sm font-medium text-text bg-olive-100 rounded px-2 py-0.5 outline-none border border-accent w-full max-w-[280px]"
                            value={editValue}
                            onChange={(e) => setEditValue(e.target.value)}
                            onBlur={saveEdit}
                            onKeyDown={handleKeyDown}
                          />
                        ) : (
                          <button
                            onClick={() => startEdit(stage.id, 'name', stage.name)}
                            className="text-sm font-medium text-text hover:text-accent transition-colors text-left"
                          >
                            {index + 1}. {stage.name}
                          </button>
                        )}
                        <span
                          className={`text-[11px] font-medium uppercase tracking-wider px-2 py-0.5 rounded-md ${
                            stage.completed
                              ? 'bg-[rgba(122,158,122,0.12)] text-[#5a7a5a]'
                              : 'bg-[rgba(201,169,110,0.12)] text-[#8a7038]'
                          }`}
                        >
                          {stage.completed ? 'Завершено' : 'В работе'}
                        </span>
                      </div>
                      {/* Editable duration */}
                      {editingId === stage.id && editField === 'duration' ? (
                        <input
                          autoFocus
                          className="text-xs text-muted bg-olive-100 rounded px-2 py-0.5 outline-none border border-accent mt-1 w-32"
                          value={editValue}
                          onChange={(e) => setEditValue(e.target.value)}
                          onBlur={saveEdit}
                          onKeyDown={handleKeyDown}
                        />
                      ) : (
                        <button
                          onClick={() => startEdit(stage.id, 'duration', stage.duration)}
                          className="text-xs text-muted hover:text-accent transition-colors mt-0.5 block text-left"
                        >
                          {stage.duration}
                        </button>
                      )}
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        onClick={() => moveStage(index, 'up')}
                        disabled={index === 0}
                        className="p-1.5 rounded-lg hover:bg-olive-100 text-muted hover:text-accent transition-colors disabled:opacity-30"
                        title="Переместить вверх"
                      >
                        <ArrowUp size={14} />
                      </button>
                      <button
                        onClick={() => moveStage(index, 'down')}
                        disabled={index === stages.length - 1}
                        className="p-1.5 rounded-lg hover:bg-olive-100 text-muted hover:text-accent transition-colors disabled:opacity-30"
                        title="Переместить вниз"
                      >
                        <ArrowDown size={14} />
                      </button>
                      <button
                        onClick={() => confirmDelete(stage.id)}
                        className="p-1.5 rounded-lg hover:bg-red-50 text-muted hover:text-red-500 transition-colors"
                        title="Удалить этап"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>

                  {/* Works section */}
                  <div className="mb-3">
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-[11px] font-semibold uppercase tracking-wider text-[#5c6b55]">
                        Работы
                      </span>
                      <button
                        onClick={() => addArrayItem(stage.id, 'works')}
                        className="flex items-center gap-1 text-[11px] text-accent hover:text-olive-600 font-medium transition-colors"
                      >
                        <Plus size={12} />
                        Добавить
                      </button>
                    </div>
                    {stage.works.length === 0 ? (
                      <p className="text-xs text-muted italic">(пусто)</p>
                    ) : (
                      <ul className="space-y-1">
                        {stage.works.map((work, wi) => (
                          <li key={wi} className="flex items-center gap-2 group">
                            <span className="text-accent text-xs mt-0.5">•</span>
                            {editingId === stage.id && editField === 'works' && editIndex === wi ? (
                              <input
                                autoFocus
                                className="flex-1 text-sm text-text bg-olive-100 rounded px-2 py-0.5 outline-none border border-accent"
                                value={editValue}
                                onChange={(e) => setEditValue(e.target.value)}
                                onBlur={saveEdit}
                                onKeyDown={handleKeyDown}
                              />
                            ) : (
                              <button
                                onClick={() => startEdit(stage.id, 'works', work, wi)}
                                className="flex-1 text-left text-sm text-text hover:text-accent transition-colors"
                              >
                                {work}
                              </button>
                            )}
                            <button
                              onClick={() => removeArrayItem(stage.id, 'works', wi)}
                              className="opacity-0 group-hover:opacity-100 p-0.5 rounded hover:bg-red-50 text-muted hover:text-red-500 transition-all"
                            >
                              <X size={12} />
                            </button>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>

                  {/* Materials section */}
                  <div className="mb-3">
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-[11px] font-semibold uppercase tracking-wider text-[#5c6b55]">
                        Материалы
                      </span>
                      <button
                        onClick={() => addArrayItem(stage.id, 'materials')}
                        className="flex items-center gap-1 text-[11px] text-accent hover:text-olive-600 font-medium transition-colors"
                      >
                        <Plus size={12} />
                        Добавить
                      </button>
                    </div>
                    {stage.materials.length === 0 ? (
                      <p className="text-xs text-muted italic">(пусто)</p>
                    ) : (
                      <ul className="space-y-1">
                        {stage.materials.map((mat, mi) => (
                          <li key={mi} className="flex items-center gap-2 group">
                            <span className="text-accent text-xs mt-0.5">•</span>
                            {editingId === stage.id && editField === 'materials' && editIndex === mi ? (
                              <input
                                autoFocus
                                className="flex-1 text-sm text-text bg-olive-100 rounded px-2 py-0.5 outline-none border border-accent"
                                value={editValue}
                                onChange={(e) => setEditValue(e.target.value)}
                                onBlur={saveEdit}
                                onKeyDown={handleKeyDown}
                              />
                            ) : (
                              <button
                                onClick={() => startEdit(stage.id, 'materials', mat, mi)}
                                className="flex-1 text-left text-sm text-text hover:text-accent transition-colors"
                              >
                                {mat}
                              </button>
                            )}
                            <button
                              onClick={() => removeArrayItem(stage.id, 'materials', mi)}
                              className="opacity-0 group-hover:opacity-100 p-0.5 rounded hover:bg-red-50 text-muted hover:text-red-500 transition-all"
                            >
                              <X size={12} />
                            </button>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>

                  {/* Cost */}
                  <div className="flex items-center gap-2 mb-3">
                    <Calculator size={14} className="text-muted" />
                    <span className="text-xs text-muted">Стоимость:</span>
                    {editingId === stage.id && editField === 'cost' ? (
                      <input
                        autoFocus
                        type="number"
                        min={0}
                        step={100}
                        className="text-sm font-medium text-text bg-olive-100 rounded px-2 py-0.5 outline-none border border-accent w-28"
                        value={editValue}
                        onChange={(e) => setEditValue(e.target.value)}
                        onBlur={saveEdit}
                        onKeyDown={handleKeyDown}
                      />
                    ) : (
                      <button
                        onClick={() => startEdit(stage.id, 'cost', String(stage.cost))}
                        className="text-sm font-medium text-text hover:text-accent transition-colors"
                      >
                        {stage.cost.toLocaleString()} ₽
                      </button>
                    )}
                  </div>

                  {/* Complete toggle */}
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => toggleComplete(stage.id)}
                      className={`flex items-center gap-2 px-3 py-2 rounded-xl text-sm font-medium transition-colors ${
                        stage.completed
                          ? 'bg-[rgba(122,158,122,0.12)] text-[#5a7a5a]'
                          : 'border border-accent text-text hover:bg-olive-100'
                      }`}
                    >
                      <Check size={16} />
                      {stage.completed ? 'Завершён' : 'Отметить завершённым'}
                    </button>
                  </div>

                  {/* Celebration overlay */}
                  <AnimatePresence>
                    {celebratingStageId === stage.id && (
                      <motion.div
                        className="pointer-events-none fixed inset-0 z-[500] flex items-center justify-center"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                      >
                        <ConfettiBurst />
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              </div>
            );
          })}
        </div>

        {/* Add stage button */}
        <div className="mt-4 flex justify-center">
          <button
            onClick={addStage}
            className="flex items-center gap-2 px-5 py-3 rounded-xl bg-accent text-white text-sm font-medium hover:bg-olive-600 transition-colors shadow-sm"
          >
            <Plus size={16} />
            Добавить этап
          </button>
        </div>
      </div>

      {/* Delete confirmation modal */}
      <AnimatePresence>
        {deleteConfirmId !== null && (
          <>
            <motion.div
              className="fixed inset-0 z-[300] bg-[rgba(26,26,26,0.5)] backdrop-blur-sm"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setDeleteConfirmId(null)}
            />
            <motion.div
              className="fixed inset-0 z-[400] flex items-center justify-center p-4"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
            >
              <div className="bg-white rounded-2xl p-6 max-w-[360px] w-full text-center shadow-xl">
                <div className="w-12 h-12 rounded-full bg-red-50 flex items-center justify-center mx-auto mb-4">
                  <Trash2 size={20} className="text-red-500" />
                </div>
                <h2 className="font-serif text-xl font-semibold text-text mb-2">
                  Удалить этап?
                </h2>
                <p className="text-sm text-muted mb-6">
                  Это действие нельзя отменить. Все данные этапа будут удалены.
                </p>
                <div className="flex gap-3 justify-center">
                  <button
                    onClick={() => setDeleteConfirmId(null)}
                    className="px-4 py-2.5 rounded-xl border border-border text-sm font-medium text-text hover:bg-olive-100 transition-colors"
                  >
                    Отмена
                  </button>
                  <button
                    onClick={doDelete}
                    className="px-4 py-2.5 rounded-xl bg-red-500 text-white text-sm font-medium hover:bg-red-600 transition-colors"
                  >
                    Удалить
                  </button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* All Complete Modal */}
      <AnimatePresence>
        {allComplete && (
          <>
            <motion.div
              className="fixed inset-0 z-[300] bg-[rgba(26,26,26,0.5)] backdrop-blur-sm"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            />
            <motion.div
              className="fixed inset-0 z-[400] flex items-center justify-center p-4"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
            >
              <div className="bg-white rounded-2xl p-8 max-w-[420px] w-full text-center shadow-xl">
                <div className="mb-4 flex justify-center">
                  <ConfettiBurst inline />
                </div>
                <h2 className="font-serif text-2xl font-semibold text-text mb-2">
                  Ремонт завершен!
                </h2>
                <p className="text-base text-muted mb-6">
                  Все {stages.length} этапов выполнены. Общая стоимость:{' '}
                  <span className="font-medium text-text">{totalCost.toLocaleString()} ₽</span>
                </p>
                <div className="flex gap-3 justify-center">
                  <button
                    onClick={() => setAllComplete(false)}
                    className="px-5 py-2.5 rounded-xl bg-accent text-white text-sm font-medium hover:bg-olive-600 transition-colors"
                  >
                    Вернуться к таймлайну
                  </button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

/* ------------------------------------------------------------------ */
/*  Confetti                                                            */
/* ------------------------------------------------------------------ */

function ConfettiBurst({ inline = false }: { inline?: boolean }) {
  const particles = Array.from({ length: 8 }).map((_, i) => ({
    id: i,
    color: ['#8b9d83', '#7a9e7a', '#c9a96e', '#e0dbd4', '#5c6b55'][i % 5],
    x: (Math.random() - 0.5) * 200,
    y: -Math.random() * 150 - 50,
    rotate: Math.random() * 360,
    scale: 0.5 + Math.random() * 0.8,
  }));

  return (
    <div className={`${inline ? 'relative w-20 h-20' : 'absolute inset-0 pointer-events-none'}`}>
      {particles.map((p) => (
        <motion.div
          key={p.id}
          className="absolute rounded-sm"
          style={{
            width: 8,
            height: 8,
            backgroundColor: p.color,
            left: inline ? '50%' : '50%',
            top: inline ? '50%' : '50%',
          }}
          initial={{ x: 0, y: 0, opacity: 1, rotate: 0, scale: 1 }}
          animate={{
            x: p.x,
            y: p.y,
            opacity: 0,
            rotate: p.rotate,
            scale: p.scale,
          }}
          transition={{ duration: 0.8, ease: [0.4, 0, 0.2, 1] as [number, number, number, number] }}
        />
      ))}
    </div>
  );
}
