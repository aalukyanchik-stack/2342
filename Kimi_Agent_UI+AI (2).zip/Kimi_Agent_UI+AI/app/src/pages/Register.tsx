import { useState, useCallback, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowLeft,
  ArrowRight,
  Check,
  Loader2,
  Sparkles,
  Home,
  User,
  Users,
  Baby,
  Heart,
  Monitor,
  Briefcase,
  Clock,
  Coffee,
  Lock,
  X,
} from 'lucide-react';
import { useToast } from '@/components/Toast';
import { projects, auth } from '@/lib/api';

/* ─── Types ─── */
type BudgetOption = 'До 2 млн' | '2-5 млн' | '5-10 млн' | '10+ млн' | 'Не знаю';
type FamilyOption = 'Один' | 'Пара' | 'Семья с детьми' | 'Семья + родители';
type WorkScheduleOption = 'Удаленка' | 'Офис' | 'Смешанный' | 'Гибкий';

interface WizardState {
  projectName: string;
  budget: BudgetOption | '';
  area: string;
  styleId: string;
  family: FamilyOption | '';
  hasPets: boolean;
  workSchedule: WorkScheduleOption | '';
  hobbies: string[];
}

/* ─── Style data (mirrors api.ts) ─── */
const STYLES: { id: string; name: string; description: string; image: string; locked: boolean }[] = [
  { id: '1', name: 'Скандинавский', description: 'Светлый, уютный, минимализм, дерево', image: '/style-scandi.jpg', locked: false },
  { id: '2', name: 'Лофт', description: 'Кирпич, бетон, металл, открытые коммуникации', image: '/style-loft.jpg', locked: false },
  { id: '3', name: 'Минимализм', description: 'Чистота линий, отсутствие декора, функциональность', image: '/style-minimal.jpg', locked: false },
  { id: '4', name: 'Неоклассика', description: 'Современная интерпретация классики', image: '/style-neoclassic.jpg', locked: true },
  { id: '5', name: 'Современная классика', description: 'Баланс традиций и современности', image: '/style-modern-classic.jpg', locked: true },
  { id: '6', name: 'Японский', description: 'Wabi-sabi, натуральность, асимметрия', image: '/style-japanese.jpg', locked: true },
  { id: '7', name: 'Ар-деко', description: 'Геометрия, роскошь, контрасты', image: '/style-artdeco.jpg', locked: true },
];

const BUDGET_OPTIONS: { label: BudgetOption; caption: string }[] = [
  { label: 'До 2 млн', caption: 'Экономичный ремонт' },
  { label: '2-5 млн', caption: 'Стандартный ремонт' },
  { label: '5-10 млн', caption: 'Комфортный ремонт' },
  { label: '10+ млн', caption: 'Премиум ремонт' },
  { label: 'Не знаю', caption: 'Рассчитаем вместе' },
];

const FAMILY_OPTIONS: FamilyOption[] = ['Один', 'Пара', 'Семья с детьми', 'Семья + родители'];
const WORK_SCHEDULE_OPTIONS: WorkScheduleOption[] = ['Удаленка', 'Офис', 'Смешанный', 'Гибкий'];
const HOBBY_TAGS = ['Готовлю часто', 'Работаю дома', 'Много вещей', 'Минималист'];

/* ─── Animations ─── */
const stepEnter = {
  initial: { opacity: 0, x: 40 },
  animate: { opacity: 1, x: 0 },
  exit: { opacity: 0, x: -40 },
  transition: { duration: 0.35, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] },
};

const checkVariants = {
  hidden: { scale: 0, rotate: -10 },
  visible: {
    scale: 1,
    rotate: 0,
    transition: { type: 'spring' as const, stiffness: 260, damping: 20 },
  },
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.06, delayChildren: 0.1 } },
};

const staggerItem = {
  hidden: { opacity: 0, y: 12 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.3, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] } },
};

/* ─── Helper: Confetti particles ─── */
function ConfettiBurst({ color = '#8b9d83' }: { color?: string }) {
  const particles = Array.from({ length: 24 }).map((_, i) => ({
    id: i,
    x: Math.random() * 200 - 100,
    y: Math.random() * -150 - 50,
    rot: Math.random() * 360,
    size: 4 + Math.random() * 6,
    delay: Math.random() * 0.3,
  }));

  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden flex items-center justify-center">
      {particles.map((p) => (
        <motion.div
          key={p.id}
          className="absolute rounded-sm"
          style={{
            width: p.size,
            height: p.size,
            backgroundColor: color,
          }}
          initial={{ opacity: 1, x: 0, y: 0, rotate: 0, scale: 1 }}
          animate={{
            opacity: 0,
            x: p.x,
            y: p.y,
            rotate: p.rot,
            scale: 0,
          }}
          transition={{ duration: 1.2, delay: p.delay, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
        />
      ))}
    </div>
  );
}

/* ─── Main Component ─── */
export default function Register() {
  const navigate = useNavigate();
  const { showToast } = useToast();

  const [step, setStep] = useState(1);
  const [direction, setDirection] = useState(1); // 1 = forward, -1 = back
  const [loading, setLoading] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);
  const [planReady, setPlanReady] = useState(false);

  const [data, setData] = useState<WizardState>({
    projectName: '',
    budget: '',
    area: '',
    styleId: '',
    family: '',
    hasPets: false,
    workSchedule: '',
    hobbies: [],
  });

  const goNext = useCallback(() => {
    setDirection(1);
    setStep((s) => Math.min(s + 1, 5));
  }, []);

  const goBack = useCallback(() => {
    setDirection(-1);
    setStep((s) => Math.max(s - 1, 1));
  }, []);

  const update = useCallback(<K extends keyof WizardState>(key: K, value: WizardState[K]) => {
    setData((prev) => ({ ...prev, [key]: value }));
  }, []);

  const toggleHobby = useCallback((tag: string) => {
    setData((prev) => ({
      ...prev,
      hobbies: prev.hobbies.includes(tag)
        ? prev.hobbies.filter((t) => t !== tag)
        : [...prev.hobbies, tag],
    }));
  }, []);

  const handleCreateProject = useCallback(async () => {
    setLoading(true);
    try {
      // Auto-register a demo user if not logged in
      const user = await auth.me();
      if (!user) {
        await auth.register({
          name: 'Пользователь',
          email: `user-${Date.now()}@prostranstvo.app`,
          password: 'password123',
        });
      }

      // Map style ID to slug
      const styleMap: Record<string, string> = {
        '1': 'scandinavian', '2': 'loft', '3': 'minimalism',
        '4': 'neoclassic', '5': 'modern-classic', '6': 'japanese', '7': 'artdeco',
      };
      const styleNameMap: Record<string, string> = {
        '1': 'Скандинавский', '2': 'Лофт', '3': 'Минимализм',
        '4': 'Неоклассика', '5': 'Современная классика', '6': 'Японский', '7': 'Ар-деко',
      };
      const styleSlug = styleMap[data.styleId] || 'scandinavian';
      const styleName = styleNameMap[data.styleId] || 'Скандинавский';
      const projectName = data.projectName || `${styleName}, ${data.area || 50} м²`;

      await projects.create({
        name: projectName,
        budget: data.budget === 'Не знаю' ? 0 : parseBudget(data.budget),
        styleId: styleSlug,
        area: Number(data.area) || 50,
        familySize: familySizeFromOption(data.family),
        hasPets: data.hasPets,
      });

      setShowConfetti(true);
      setPlanReady(true);
      setTimeout(() => setShowConfetti(false), 2000);
      showToast('Проект создан!', 'success');
    } catch {
      showToast('Не удалось создать проект', 'error');
    } finally {
      setLoading(false);
    }
  }, [data, showToast]);

  const handleGoToProject = useCallback(() => {
    navigate('/dashboard');
  }, [navigate]);

  /* ─── Progress ─── */
  const progress = (step / 5) * 100;

  return (
    <div className="min-h-[100dvh] bg-background flex flex-col">
      {/* Progress Header */}
      <div className="sticky top-0 z-50 bg-background">
        <div className="max-w-[600px] mx-auto px-6 pt-4 pb-3">
          <div className="flex items-center justify-between mb-3">
            {step > 1 && step < 5 ? (
              <button
                onClick={goBack}
                className="w-10 h-10 flex items-center justify-center rounded-xl hover:bg-[#e8ede5] transition-colors active:scale-95"
                aria-label="Назад"
              >
                <ArrowLeft size={20} className="text-text" />
              </button>
            ) : (
              <div className="w-10" />
            )}
            <span className="text-xs font-medium text-[#9a9a9a]">
              Шаг {step} из 5
            </span>
            {step < 5 ? (
              <button
                onClick={() => navigate('/dashboard')}
                className="w-10 h-10 flex items-center justify-center rounded-xl hover:bg-[#e8ede5] transition-colors active:scale-95"
                aria-label="Закрыть"
              >
                <X size={20} className="text-muted" />
              </button>
            ) : (
              <div className="w-10" />
            )}
          </div>
          <div className="h-1 bg-[#e0dbd4] rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-[#8b9d83] rounded-full"
              initial={false}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.4, ease: [0.4, 0, 0.2, 1] as [number, number, number, number] }}
            />
          </div>
        </div>
      </div>

      {/* Step Content */}
      <div className="flex-1 flex items-start justify-center px-6 py-4">
        <div className="w-full max-w-[600px]">
          <AnimatePresence mode="wait" custom={direction}>
            {step === 1 && (
              <StepWelcome key="step1" onStart={goNext} />
            )}
            {step === 2 && (
              <StepBudgetArea
                key="step2"
                data={data}
                update={update}
                onNext={goNext}
              />
            )}
            {step === 3 && (
              <StepStyle
                key="step3"
                selected={data.styleId}
                onSelect={(id) => update('styleId', id)}
                onNext={goNext}
              />
            )}
            {step === 4 && (
              <StepFamily
                key="step4"
                data={data}
                update={update}
                toggleHobby={toggleHobby}
                onNext={goNext}
              />
            )}
            {step === 5 && (
              <StepSuccess
                key="step5"
                data={data}
                loading={loading}
                planReady={planReady}
                showConfetti={showConfetti}
                onCreate={handleCreateProject}
                onGo={handleGoToProject}
              />
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}

/* ─── Step 1: Welcome ─── */
function StepWelcome({ onStart }: { onStart: () => void }) {
  return (
    <motion.div
      {...stepEnter}
      className="flex flex-col items-center text-center pt-8 pb-12"
    >
      {/* Illustration */}
      <motion.div
        className="w-[200px] h-[160px] mb-8 relative flex items-center justify-center"
        animate={{ y: [0, -6, 0] }}
        transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
      >
        <div className="w-full h-full bg-[#e8ede5] rounded-2xl flex items-center justify-center">
          <Home size={64} className="text-[#8b9d83]" strokeWidth={1.2} />
        </div>
      </motion.div>

      <h1 className="font-serif text-2xl font-semibold text-text mb-3">
        Начните ремонт
      </h1>
      <p className="text-sm text-muted leading-relaxed max-w-[360px] mb-8">
        PROSTRANSTVO — ваш AI-ассистент для ремонта. От идеи до заселения:
        планирование, бюджет, подрядчики и контроль этапов в одном месте.
      </p>

      <motion.button
        onClick={onStart}
        className="w-full max-w-[320px] bg-[#8b9d83] text-white font-medium py-3.5 rounded-xl transition-all duration-200 hover:bg-[#6b7a64] active:scale-[0.98] flex items-center justify-center gap-2"
        whileHover={{ y: -1 }}
      >
        Начать
        <ArrowRight size={18} />
      </motion.button>

      <p className="text-xs text-muted mt-4">
        Уже есть аккаунт?{' '}
        <button
          onClick={() => (window.location.hash = '/login')}
          className="text-accent font-medium hover:underline"
        >
          Войти
        </button>
      </p>
    </motion.div>
  );
}

/* ─── Step 2: Budget & Area ─── */
function StepBudgetArea({
  data,
  update,
  onNext,
}: {
  data: WizardState;
  update: <K extends keyof WizardState>(key: K, value: WizardState[K]) => void;
  onNext: () => void;
}) {
  return (
    <motion.div {...stepEnter} className="pb-8">
      <h2 className="font-serif text-[22px] font-semibold text-text mb-1">
        Какой у вас бюджет?
      </h2>
      <p className="text-sm text-muted mb-6">
        Выберите диапазон — мы рассчитаем стоимость этапов
      </p>

      {/* Project Name */}
      <div className="mb-6">
        <label className="block text-xs font-medium uppercase text-muted tracking-[0.04em] mb-2">
          Название проекта
        </label>
        <input
          type="text"
          value={data.projectName}
          onChange={(e) => update('projectName', e.target.value)}
          placeholder="Например, Моя квартира на Арбате"
          className="w-full bg-white border border-[#e0dbd4] rounded-xl py-3.5 px-4 text-base text-text placeholder:text-[#9a9a9a] outline-none transition-all duration-200 focus:border-[#8b9d83] focus:shadow-[0_0_0_3px_rgba(139,157,131,0.15)]"
        />
      </div>

      <motion.div
        className="flex flex-wrap gap-3 mb-8"
        variants={staggerContainer}
        initial="hidden"
        animate="visible"
      >
        {BUDGET_OPTIONS.map((opt) => {
          const active = data.budget === opt.label;
          return (
            <motion.button
              key={opt.label}
              variants={staggerItem}
              onClick={() => update('budget', opt.label)}
              className={
                active
                  ? 'bg-[#e8ede5] border-2 border-[#8b9d83] text-text font-medium px-5 py-3 rounded-xl transition-all duration-200 active:scale-[0.98] flex items-center gap-2'
                  : 'bg-white border-2 border-[#e0dbd4] text-text font-medium px-5 py-3 rounded-xl transition-all duration-200 hover:border-[#8b9d83]/40 active:scale-[0.98] flex items-center gap-2'
              }
            >
              {active && (
                <motion.span variants={checkVariants} initial="hidden" animate="visible">
                  <Check size={16} className="text-[#8b9d83]" />
                </motion.span>
              )}
              <div className="text-left">
                <div className="text-sm font-medium">{opt.label}</div>
                <div className="text-xs text-muted">{opt.caption}</div>
              </div>
            </motion.button>
          );
        })}
      </motion.div>

      {/* Area Input */}
      <div className="mb-8">
        <label className="block text-xs font-medium uppercase text-muted tracking-[0.04em] mb-2">
          Площадь квартиры
        </label>
        <div className="relative">
          <input
            type="number"
            value={data.area}
            onChange={(e) => update('area', e.target.value)}
            placeholder="Например, 65"
            min={1}
            className="w-full bg-white border border-[#e0dbd4] rounded-xl py-3.5 px-4 pr-12 text-base text-text placeholder:text-[#9a9a9a] outline-none transition-all duration-200 focus:border-[#8b9d83] focus:shadow-[0_0_0_3px_rgba(139,157,131,0.15)]"
          />
          <span className="absolute right-4 top-1/2 -translate-y-1/2 text-sm text-muted">м²</span>
        </div>
      </div>

      <button
        onClick={onNext}
        disabled={!data.budget || !data.area || Number(data.area) <= 0}
        className="w-full bg-[#8b9d83] text-white font-medium py-3.5 rounded-xl transition-all duration-200 hover:bg-[#6b7a64] active:scale-[0.98] disabled:opacity-50 disabled:active:scale-100 flex items-center justify-center gap-2"
      >
        Продолжить
        <ArrowRight size={18} />
      </button>
    </motion.div>
  );
}

/* ─── Step 3: Style ─── */
function StepStyle({
  selected,
  onSelect,
  onNext,
}: {
  selected: string;
  onSelect: (id: string) => void;
  onNext: () => void;
}) {
  return (
    <motion.div {...stepEnter} className="pb-8">
      <h2 className="font-serif text-[22px] font-semibold text-text mb-1">
        Выберите стиль
      </h2>
      <p className="text-sm text-muted mb-6">
        Выберите один — потом можно изменить
      </p>

      {/* Horizontal scrollable cards */}
      <div className="flex gap-4 overflow-x-auto pb-4 -mx-2 px-2 snap-x snap-mandatory scrollbar-thin">
        {STYLES.map((style, i) => {
          const isSelected = selected === style.id;
          return (
            <motion.div
              key={style.id}
              className="flex-shrink-0 w-[220px] snap-start relative"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.06, duration: 0.35, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
            >
              <button
                onClick={() => !style.locked && onSelect(style.id)}
                disabled={style.locked}
                className={`w-full text-left bg-white border rounded-2xl overflow-hidden transition-all duration-200 ${
                  style.locked
                    ? 'border-[#e0dbd4] opacity-70'
                    : isSelected
                    ? 'border-[#8b9d83] ring-[3px] ring-[#8b9d83]/30'
                    : 'border-[#e0dbd4] hover:shadow-md hover:-translate-y-0.5'
                }`}
              >
                <div className="relative h-[140px] overflow-hidden">
                  <img
                    src={style.image}
                    alt={style.name}
                    className={`w-full h-full object-cover transition-transform duration-500 ${
                      isSelected ? 'scale-105' : 'scale-100'
                    }`}
                    loading="lazy"
                  />
                  {isSelected && !style.locked && (
                    <div className="absolute inset-0 bg-[#8b9d83]/20 flex items-center justify-center">
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-lg"
                      >
                        <Check size={20} className="text-[#8b9d83]" />
                      </motion.div>
                    </div>
                  )}
                  {style.locked && (
                    <div className="absolute inset-0 bg-[#f7f5f2]/85 flex flex-col items-center justify-center gap-2">
                      <Lock size={24} className="text-muted" />
                      <span className="text-[10px] font-medium uppercase tracking-wider text-muted bg-white px-2 py-1 rounded-md border border-[#e0dbd4]">
                        Доступно в PRO
                      </span>
                    </div>
                  )}
                </div>
                <div className="p-3">
                  <h3 className="text-sm font-medium text-text">{style.name}</h3>
                  <p className="text-xs text-muted mt-0.5 line-clamp-2">{style.description}</p>
                </div>
              </button>
            </motion.div>
          );
        })}
      </div>

      <button
        onClick={onNext}
        disabled={!selected}
        className="w-full bg-[#8b9d83] text-white font-medium py-3.5 rounded-xl transition-all duration-200 hover:bg-[#6b7a64] active:scale-[0.98] disabled:opacity-50 disabled:active:scale-100 flex items-center justify-center gap-2 mt-4"
      >
        Продолжить
        <ArrowRight size={18} />
      </button>
    </motion.div>
  );
}

/* ─── Step 4: Family ─── */
function StepFamily({
  data,
  update,
  toggleHobby,
  onNext,
}: {
  data: WizardState;
  update: <K extends keyof WizardState>(key: K, value: WizardState[K]) => void;
  toggleHobby: (tag: string) => void;
  onNext: () => void;
}) {
  const familyIcons: Record<FamilyOption, React.ReactNode> = {
    'Один': <User size={20} />,
    'Пара': <Heart size={20} />,
    'Семья с детьми': <Baby size={20} />,
    'Семья + родители': <Users size={20} />,
  };

  const scheduleIcons: Record<WorkScheduleOption, React.ReactNode> = {
    'Удаленка': <Monitor size={20} />,
    'Офис': <Briefcase size={20} />,
    'Смешанный': <Clock size={20} />,
    'Гибкий': <Coffee size={20} />,
  };

  return (
    <motion.div {...stepEnter} className="pb-8">
      <h2 className="font-serif text-[22px] font-semibold text-text mb-1">
        Состав семьи
      </h2>
      <p className="text-sm text-muted mb-6">
        Это влияет на планировку и функциональность
      </p>

      {/* Family */}
      <div className="mb-6">
        <label className="block text-xs font-medium uppercase text-muted tracking-[0.04em] mb-3">
          Кто будет жить в квартире?
        </label>
        <div className="flex flex-wrap gap-2">
          {FAMILY_OPTIONS.map((opt) => {
            const active = data.family === opt;
            return (
              <button
                key={opt}
                onClick={() => update('family', opt)}
                className={
                  active
                    ? 'bg-[#8b9d83] text-white border border-[#8b9d83] font-medium px-5 py-2.5 rounded-full transition-all duration-200 active:scale-95 flex items-center gap-2'
                    : 'bg-white text-text border border-[#e0dbd4] font-medium px-5 py-2.5 rounded-full transition-all duration-200 hover:border-[#8b9d83]/40 active:scale-95 flex items-center gap-2'
                }
              >
                <span className={active ? 'text-white' : 'text-[#8b9d83]'}>
                  {familyIcons[opt]}
                </span>
                {opt}
              </button>
            );
          })}
        </div>
      </div>

      {/* Pets toggle */}
      <div className="mb-6">
        <div className="flex items-center justify-between bg-white border border-[#e0dbd4] rounded-xl px-4 py-3.5">
          <span className="text-sm font-medium text-text">Есть ли питомцы?</span>
          <button
            onClick={() => update('hasPets', !data.hasPets)}
            className={`relative w-12 h-7 rounded-full transition-colors duration-200 ${
              data.hasPets ? 'bg-[#8b9d83]' : 'bg-[#e0dbd4]'
            }`}
          >
            <motion.div
              className="absolute top-0.5 left-0.5 w-6 h-6 bg-white rounded-full shadow-sm"
              animate={{ x: data.hasPets ? 20 : 0 }}
              transition={{ type: 'spring', stiffness: 400, damping: 25 }}
            />
          </button>
        </div>
      </div>

      {/* Work schedule */}
      <div className="mb-6">
        <label className="block text-xs font-medium uppercase text-muted tracking-[0.04em] mb-3">
          График работы
        </label>
        <div className="grid grid-cols-2 gap-2">
          {WORK_SCHEDULE_OPTIONS.map((opt) => {
            const active = data.workSchedule === opt;
            return (
              <button
                key={opt}
                onClick={() => update('workSchedule', opt)}
                className={
                  active
                    ? 'bg-[#e8ede5] border-2 border-[#8b9d83] text-text font-medium py-3 rounded-xl transition-all duration-200 active:scale-[0.98] flex items-center justify-center gap-2'
                    : 'bg-white border-2 border-[#e0dbd4] text-text font-medium py-3 rounded-xl transition-all duration-200 hover:border-[#8b9d83]/40 active:scale-[0.98] flex items-center justify-center gap-2'
                }
              >
                <span className={active ? 'text-[#8b9d83]' : 'text-muted'}>
                  {scheduleIcons[opt]}
                </span>
                {opt}
              </button>
            );
          })}
        </div>
      </div>

      {/* Hobbies */}
      <div className="mb-8">
        <label className="block text-xs font-medium uppercase text-muted tracking-[0.04em] mb-3">
          Хобби и привычки
        </label>
        <div className="flex flex-wrap gap-2">
          {HOBBY_TAGS.map((tag) => {
            const active = data.hobbies.includes(tag);
            return (
              <button
                key={tag}
                onClick={() => toggleHobby(tag)}
                className={
                  active
                    ? 'bg-[#8b9d83] text-white border border-[#8b9d83] text-sm font-medium px-4 py-2 rounded-full transition-all duration-200 active:scale-95'
                    : 'bg-white text-text border border-[#e0dbd4] text-sm font-medium px-4 py-2 rounded-full transition-all duration-200 hover:border-[#8b9d83]/40 active:scale-95'
                }
              >
                {active && <Check size={14} className="inline mr-1" />}
                {tag}
              </button>
            );
          })}
        </div>
      </div>

      <button
        onClick={onNext}
        disabled={!data.family || !data.workSchedule}
        className="w-full bg-[#8b9d83] text-white font-medium py-3.5 rounded-xl transition-all duration-200 hover:bg-[#6b7a64] active:scale-[0.98] disabled:opacity-50 disabled:active:scale-100 flex items-center justify-center gap-2"
      >
        Продолжить
        <ArrowRight size={18} />
      </button>
    </motion.div>
  );
}

/* ─── Step 5: Plan Generated ─── */
function StepSuccess({
  data,
  loading,
  planReady,
  showConfetti,
  onCreate,
  onGo,
}: {
  data: WizardState;
  loading: boolean;
  planReady: boolean;
  showConfetti: boolean;
  onCreate: () => void;
  onGo: () => void;
}) {
  const selectedStyle = STYLES.find((s) => s.id === data.styleId);
  const budgetMap: Record<string, string> = {
    'До 2 млн': '~1.5 млн ₽',
    '2-5 млн': '~3.5 млн ₽',
    '5-10 млн': '~7 млн ₽',
    '10+ млн': '~12 млн ₽',
    'Не знаю': 'Будет рассчитан',
  };

  useEffect(() => {
    if (!planReady && !loading) {
      onCreate();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <motion.div
      {...stepEnter}
      className="flex flex-col items-center text-center pt-4 pb-12 relative"
    >
      {showConfetti && <ConfettiBurst />}

      {/* Checkmark */}
      <motion.div
        className="w-20 h-20 bg-[#e8ede5] rounded-full flex items-center justify-center mb-6"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ type: 'spring', stiffness: 200, damping: 15 }}
      >
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2, type: 'spring', stiffness: 260, damping: 20 }}
        >
          <Check size={36} className="text-[#8b9d83]" strokeWidth={2.5} />
        </motion.div>
      </motion.div>

      <h2 className="font-serif text-[28px] font-semibold text-text mb-2">
        {planReady ? 'План готов!' : 'AI создает ваш план...'}
      </h2>
      <p className="text-sm text-muted mb-8">
        {planReady
          ? 'AI составил персональный план ремонта'
          : 'Анализируем ваши ответы и подбираем этапы...'}
      </p>

      {/* Summary Card */}
      <motion.div
        className="w-full bg-white border border-[#e0dbd4] rounded-2xl p-5 mb-8 text-left"
        initial={{ opacity: 0, y: 20 }}
        animate={planReady ? { opacity: 1, y: 0 } : { opacity: 0.5, y: 10 }}
        transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
      >
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 bg-[#e8ede5] rounded-xl flex items-center justify-center">
            <Sparkles size={20} className="text-[#8b9d83]" />
          </div>
          <div>
            <p className="text-sm font-medium text-text">{selectedStyle?.name || 'Скандинавский'}</p>
            <p className="text-xs text-muted">{selectedStyle?.description || 'Светлый, уютный стиль'}</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-4">
          <div className="bg-[#f7f5f2] rounded-xl p-3">
            <p className="text-[10px] uppercase tracking-wider text-muted mb-1">Площадь</p>
            <p className="text-base font-medium text-text">{data.area || '65'} м²</p>
          </div>
          <div className="bg-[#f7f5f2] rounded-xl p-3">
            <p className="text-[10px] uppercase tracking-wider text-muted mb-1">Бюджет</p>
            <p className="text-base font-medium text-text">{budgetMap[data.budget] || '—'}</p>
          </div>
        </div>

        <div className="bg-[#f7f5f2] rounded-xl p-3 flex items-center gap-3">
          <Clock size={16} className="text-[#8b9d83]" />
          <div>
            <p className="text-[10px] uppercase tracking-wider text-muted">Срок</p>
            <p className="text-sm font-medium text-text">~45–60 дней</p>
          </div>
        </div>

        {/* Timeline preview */}
        <div className="mt-4 pt-4 border-t border-[#e0dbd4]">
          <p className="text-[10px] uppercase tracking-wider text-muted mb-3">10 этапов ремонта</p>
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
            {['Дизайн', 'Демонтаж', 'Черновая', 'Чистовая', 'Кухня', 'Электрика', 'Мебель', 'Умный дом', 'Уборка', 'Заселение'].map((stage, i) => (
              <div key={stage} className="flex flex-col items-center gap-1 min-w-[48px]">
                <motion.div
                  className="w-2.5 h-2.5 rounded-full bg-[#8b9d83]"
                  initial={{ scale: 0 }}
                  animate={planReady ? { scale: 1 } : { scale: 0 }}
                  transition={{ delay: 0.5 + i * 0.08 }}
                />
                <span className="text-[9px] text-muted text-center leading-tight whitespace-nowrap">{stage}</span>
              </div>
            ))}
          </div>
        </div>
      </motion.div>

      <button
        onClick={onGo}
        disabled={!planReady || loading}
        className="w-full bg-[#8b9d83] text-white font-medium py-3.5 rounded-xl transition-all duration-200 hover:bg-[#6b7a64] active:scale-[0.98] disabled:opacity-50 disabled:active:scale-100 flex items-center justify-center gap-2"
      >
        {loading ? (
          <>
            <Loader2 size={18} className="animate-spin" />
            Создаем проект...
          </>
        ) : (
          <>
            <Home size={18} />
            Перейти в проект
          </>
        )}
      </button>

      {!planReady && (
        <motion.div
          className="absolute inset-0 bg-background/60 flex items-center justify-center z-10"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          <Loader2 size={32} className="text-[#8b9d83] animate-spin" />
        </motion.div>
      )}
    </motion.div>
  );
}

/* ─── Helpers ─── */
function parseBudget(label: BudgetOption | ''): number {
  switch (label) {
    case 'До 2 млн': return 1500000;
    case '2-5 млн': return 3500000;
    case '5-10 млн': return 7000000;
    case '10+ млн': return 12000000;
    default: return 0;
  }
}

function familySizeFromOption(family: FamilyOption | ''): number {
  switch (family) {
    case 'Один': return 1;
    case 'Пара': return 2;
    case 'Семья с детьми': return 3;
    case 'Семья + родители': return 4;
    default: return 2;
  }
}
