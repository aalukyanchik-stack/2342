import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Mail,
  Lock,
  Eye,
  EyeOff,
  UserCircle,
  Home,
  ArrowRight,
  Loader2,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/components/Toast';
import { auth } from '@/lib/api';

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.08,
      delayChildren: 0.2,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 16 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.3, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] },
  },
};

export default function Login() {
  const navigate = useNavigate();
  const { login, loginAsDemo } = useAuth();
  const { showToast } = useToast();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<{ email?: string; password?: string; form?: string }>({});

  const validateEmail = (value: string) => {
    if (!value) return 'Введите email';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) return 'Введите корректный email';
    return '';
  };

  const validatePassword = (value: string) => {
    if (!value) return 'Введите пароль';
    if (value.length < 6) return 'Минимум 6 символов';
    return '';
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});

    const emailError = validateEmail(email);
    const passwordError = validatePassword(password);

    if (emailError || passwordError) {
      setErrors({ email: emailError, password: passwordError });
      return;
    }

    setIsLoading(true);
    try {
      await login(email, password);
      showToast('Добро пожаловать!', 'success');
    } catch {
      setErrors({ form: 'Неверный email или пароль' });
      showToast('Неверный email или пароль', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const handleTestLogin = async () => {
    setIsLoading(true);
    try {
      await loginAsDemo();
      showToast('Добро пожаловать!', 'success');
    } catch {
      showToast('Не удалось войти', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDemoProject = () => {
    auth.login('demo@prostranstvo.app', 'demo').then(() => {
      window.location.hash = '/dashboard';
      window.location.reload();
    });
  };

  return (
    <div className="min-h-[100dvh] flex">
      {/* Desktop left column — hero image */}
      <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden">
        <img
          src="/hero-bg.jpg"
          alt="Interior"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-[#1a1a1a]/40" />
        <div className="relative z-10 flex flex-col justify-end p-12">
          <p className="text-[#f7f5f2] text-xs font-medium uppercase tracking-[0.1em] mb-3">
            AI-АССИСТЕНТ РЕМОНТА
          </p>
          <h2 className="font-serif text-[32px] font-medium text-white leading-tight">
            Войдите, чтобы продолжить путь
          </h2>
        </div>
      </div>

      {/* Form area */}
      <div className="flex-1 flex items-center justify-center bg-background px-6 py-12 lg:px-12">
        <motion.div
          className="w-full max-w-[420px]"
          initial="hidden"
          animate="visible"
          variants={containerVariants}
        >
          {/* Logo */}
          <motion.div className="flex justify-center mb-10" variants={itemVariants}>
            <button onClick={() => navigate('/')} className="flex items-baseline gap-2">
              <span className="font-serif text-[20px] font-semibold text-text tracking-tight">
                PROSTRANSTVO
              </span>
              <span className="inline-block w-2 h-2 bg-accent" />
            </button>
          </motion.div>

          {/* Title */}
          <motion.h1
            className="font-serif text-2xl md:text-[28px] font-semibold text-text text-center mb-2"
            variants={itemVariants}
          >
            Вход в PROSTRANSTVO
          </motion.h1>
          <motion.p
            className="text-sm text-muted text-center mb-8"
            variants={itemVariants}
          >
            Войдите в свой аккаунт, чтобы управлять проектами
          </motion.p>

          {/* Form */}
          <motion.form onSubmit={handleSubmit} variants={containerVariants}>
            {/* Email */}
            <motion.div className="mb-4" variants={itemVariants}>
              <label className="block text-xs font-medium uppercase text-muted tracking-[0.04em] mb-1.5">
                Email
              </label>
              <div className="relative">
                <Mail
                  size={18}
                  className="absolute left-4 top-1/2 -translate-y-1/2 text-[#9a9a9a]"
                />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    if (errors.email) setErrors((prev) => ({ ...prev, email: undefined }));
                  }}
                  placeholder="your@email.com"
                  disabled={isLoading}
                  className="w-full bg-white border border-[#e0dbd4] rounded-xl py-3.5 pl-11 pr-4 text-base text-text placeholder:text-[#9a9a9a] outline-none transition-all duration-200 focus:border-[#8b9d83] focus:shadow-[0_0_0_3px_rgba(139,157,131,0.15)] disabled:opacity-60"
                />
              </div>
              {errors.email && (
                <p className="text-xs text-[#c47d7d] mt-1.5">{errors.email}</p>
              )}
            </motion.div>

            {/* Password */}
            <motion.div className="mb-2" variants={itemVariants}>
              <label className="block text-xs font-medium uppercase text-muted tracking-[0.04em] mb-1.5">
                Пароль
              </label>
              <div className="relative">
                <Lock
                  size={18}
                  className="absolute left-4 top-1/2 -translate-y-1/2 text-[#9a9a9a]"
                />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    if (errors.password) setErrors((prev) => ({ ...prev, password: undefined }));
                  }}
                  placeholder="••••••••"
                  disabled={isLoading}
                  className="w-full bg-white border border-[#e0dbd4] rounded-xl py-3.5 pl-11 pr-12 text-base text-text placeholder:text-[#9a9a9a] outline-none transition-all duration-200 focus:border-[#8b9d83] focus:shadow-[0_0_0_3px_rgba(139,157,131,0.15)] disabled:opacity-60"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-[#9a9a9a] hover:text-muted transition-colors"
                  tabIndex={-1}
                  aria-label={showPassword ? 'Скрыть пароль' : 'Показать пароль'}
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
              {errors.password && (
                <p className="text-xs text-[#c47d7d] mt-1.5">{errors.password}</p>
              )}
            </motion.div>

            {/* Forgot password */}
            <motion.div className="text-right mb-6" variants={itemVariants}>
              <button
                type="button"
                onClick={() => showToast('Функция восстановления пароля скоро появится', 'info')}
                className="text-xs text-accent hover:underline"
              >
                Забыли пароль?
              </button>
            </motion.div>

            {/* Submit */}
            <motion.div variants={itemVariants}>
              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-[#8b9d83] text-white font-medium py-3.5 rounded-xl transition-all duration-200 hover:bg-[#6b7a64] active:scale-[0.98] disabled:opacity-60 disabled:active:scale-100 flex items-center justify-center gap-2"
              >
                {isLoading ? (
                  <>
                    <Loader2 size={18} className="animate-spin" />
                    <span className="opacity-60">Вход...</span>
                  </>
                ) : (
                  'Войти'
                )}
              </button>
            </motion.div>

            {errors.form && (
              <motion.p
                initial={{ opacity: 0, y: 4 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-sm text-[#c47d7d] text-center mt-3"
              >
                {errors.form}
              </motion.p>
            )}
          </motion.form>

          {/* Divider */}
          <motion.div
            className="flex items-center gap-3 my-6"
            variants={itemVariants}
          >
            <div className="flex-1 h-px bg-[#e0dbd4]" />
            <span className="text-xs text-[#9a9a9a]">или</span>
            <div className="flex-1 h-px bg-[#e0dbd4]" />
          </motion.div>

          {/* Test login */}
          <motion.button
            variants={itemVariants}
            onClick={handleTestLogin}
            disabled={isLoading}
            className="w-full border border-[#8b9d83] text-text font-medium py-3 rounded-xl transition-all duration-200 hover:bg-[#e8ede5] active:scale-[0.98] disabled:opacity-60 disabled:active:scale-100 flex items-center justify-center gap-2"
          >
            <UserCircle size={18} className="text-[#8b9d83]" />
            Войти как тестовый пользователь
          </motion.button>

          {/* Google placeholder */}
          <motion.button
            variants={itemVariants}
            disabled
            className="w-full border border-[#e0dbd4] text-[#9a9a9a] font-medium py-3 rounded-xl mt-3 flex items-center justify-center gap-2 opacity-60 cursor-not-allowed"
          >
            <svg width="18" height="18" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="#34A853"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="#FBBC05"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
              />
              <path
                fill="#EA4335"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
              />
            </svg>
            Войти через Google
            <span className="ml-1 text-[10px] bg-[#e0dbd4] text-[#6b6b6b] px-1.5 py-0.5 rounded">
              Скоро
            </span>
          </motion.button>

          {/* Register link */}
          <motion.p
            className="text-center text-sm mt-6 text-muted"
            variants={itemVariants}
          >
            Нет аккаунта?{' '}
            <button
              onClick={() => navigate('/register')}
              className="font-medium text-[#8b9d83] hover:underline"
            >
              Зарегистрироваться
            </button>
          </motion.p>

          {/* Demo project card */}
          <motion.div
            className="mt-8 bg-white border border-[#e0dbd4] rounded-xl p-4"
            variants={itemVariants}
          >
            <div className="flex items-start gap-3">
              <div className="mt-0.5">
                <Home size={20} className="text-[#8b9d83]" />
              </div>
              <div>
                <p className="text-sm text-text mb-1">
                  Хотите посмотреть без регистрации?
                </p>
                <button
                  onClick={handleDemoProject}
                  className="text-sm font-medium text-[#8b9d83] hover:underline flex items-center gap-1"
                >
                  Открыть демо-проект «ЖК Уютный»
                  <ArrowRight size={14} />
                </button>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}
