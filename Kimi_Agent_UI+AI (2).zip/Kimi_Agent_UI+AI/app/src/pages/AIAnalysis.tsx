import { useState, useRef, useCallback, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowLeft,
  UploadCloud,
  Camera,
  Trash2,
  Sparkles,
  Bookmark,
  Check,
  AlertCircle,
  ImagePlus,
} from 'lucide-react';
import { ai as aiApi } from '@/lib/api';
import Layout from '@/components/Layout';

/* ------------------------------------------------------------------ */
/*  AI Analysis Page                                                    */
/* ------------------------------------------------------------------ */

type AnalysisState = 'empty' | 'uploaded' | 'analyzing' | 'filled' | 'error';

interface ColorItem {
  color: string;
  name: string;
  role: string;
}

interface MaterialItem {
  name: string;
  category: string;
  confidence: number;
}

interface FurnitureItem {
  type: string;
  style: string;
  color: string;
}

interface AIResult {
  style: { name: string; confidence: number; matchSlug: string };
  colorPalette: ColorItem[];
  materials: MaterialItem[];
  furniture: FurnitureItem[];
  textures: string[];
  roomType: string;
  moodDescription: string;
}

const mockResult: AIResult = {
  style: { name: 'Скандинавский', confidence: 0.92, matchSlug: 'scandinavian' },
  colorPalette: [
    { color: '#F5F5F0', name: 'Тёплый белый', role: 'primary' },
    { color: '#D4C4A8', name: 'Бежевый', role: 'secondary' },
    { color: '#8B9D83', name: 'Шалфей', role: 'accent' },
    { color: '#A08060', name: 'Тёплое дерево', role: 'accent' },
    { color: '#4A4A4A', name: 'Угольный', role: 'neutral' },
  ],
  materials: [
    { name: 'Светлый дуб', category: 'Паркет', confidence: 0.89 },
    { name: 'Лён', category: 'Текстиль', confidence: 0.76 },
    { name: 'Белая краска', category: 'Стены', confidence: 0.95 },
    { name: 'Керамика', category: 'Декор', confidence: 0.71 },
  ],
  furniture: [
    { type: 'Диван', style: 'Модульный', color: 'Серый' },
    { type: 'Журнальный стол', style: 'Минимальный', color: 'Светлый дуб' },
    { type: 'Кресло', style: 'Скандинавское', color: 'Бежевый' },
    { type: 'Люстра', style: 'Плетёная', color: 'Натуральный' },
  ],
  textures: ['Дерево', 'Лён', 'Керамика'],
  roomType: 'Гостиная',
  moodDescription:
    'Уютный скандинавский интерьер с мягким естественным светом. Светлые тона дерева и текстиля создают расслабляющую атмосферу, а живые растения добавляют свежести.',
};

const funFacts = [
  'Скандинавский стиль появился в 1950-х как ответ на суровый климат севера.',
  'В Японии существует практика «данбари» — искусство складывать вещи без складок.',
  'Первые лофты появились в Нью-Йорке в 1960-х годах.',
  'Мрамор использовался в интерьерах ещё в Древнем Риме.',
  'Цвет стен может визуально изменить размер комнаты на 20%.',
];

const steps = [
  'Загрузка фото...',
  'AI анализирует изображение...',
  'Извлекаем стиль и материалы...',
  'Создаем рекомендации...',
];

/* ------------------------------------------------------------------ */
/*  Components                                                          */
/* ------------------------------------------------------------------ */

function AnalyzingState({ progress }: { progress: number }) {
  const [completedSteps, setCompletedSteps] = useState<number>(0);
  const [factIndex, setFactIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setFactIndex((i) => (i + 1) % funFacts.length);
    }, 2500);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const target = Math.min(Math.floor((progress / 100) * steps.length), steps.length);
    setCompletedSteps(target);
  }, [progress]);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      className="w-full bg-white border border-[#e0dbd4] rounded-2xl p-8 md:p-10 text-center"
    >
      {/* Spinner */}
      <div className="flex items-center justify-center gap-2 mb-6">
        {[0, 1, 2].map((i) => (
          <motion.div
            key={i}
            className="w-3 h-3 rounded-full bg-[#8b9d83]"
            animate={{
              scale: [0.8, 1.2, 0.8],
              opacity: [0.5, 1, 0.5],
            }}
            transition={{
              duration: 1,
              repeat: Infinity,
              delay: i * 0.2,
              ease: 'easeInOut',
            }}
          />
        ))}
      </div>

      <h3 className="font-sans text-lg font-medium text-[#1a1a1a] mb-1">
        AI анализирует изображение...
      </h3>
      <p className="font-sans text-sm text-[#6b6b6b] mb-6">
        Определяем стиль, цвета, материалы и текстуры
      </p>

      {/* Progress bar */}
      <div className="w-full h-2 bg-[#e0dbd4] rounded-full overflow-hidden mb-8">
        <motion.div
          className="h-full bg-[#8b9d83] rounded-full"
          initial={{ width: 0 }}
          animate={{ width: `${progress}%` }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
        />
      </div>

      {/* Steps */}
      <div className="space-y-3 mb-8">
        {steps.map((step, i) => (
          <motion.div
            key={step}
            className="flex items-center gap-3"
            initial={{ opacity: 0.4 }}
            animate={{
              opacity: i < completedSteps ? 1 : i === completedSteps ? 1 : 0.4,
            }}
            transition={{ duration: 0.3 }}
          >
            <div
              className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 transition-colors duration-300 ${
                i < completedSteps
                  ? 'bg-[#8b9d83]'
                  : i === completedSteps
                  ? 'bg-[#8b9d83]/20'
                  : 'bg-[#e0dbd4]'
              }`}
            >
              {i < completedSteps ? (
                <motion.div
                  initial={{ scale: 0, rotate: -90 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{
                    type: 'spring',
                    stiffness: 400,
                    damping: 15,
                  }}
                >
                  <Check size={14} className="text-white" />
                </motion.div>
              ) : (
                <span className="font-sans text-[10px] font-medium text-[#6b6b6b]">
                  {i + 1}
                </span>
              )}
            </div>
            <span
              className={`font-sans text-sm transition-colors duration-300 ${
                i <= completedSteps ? 'text-[#1a1a1a] font-medium' : 'text-[#6b6b6b]'
              }`}
            >
              {step}
            </span>
          </motion.div>
        ))}
      </div>

      {/* Fun fact */}
      <AnimatePresence mode="wait">
        <motion.p
          key={factIndex}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.4 }}
          className="font-sans text-sm text-[#8b9d83] italic"
        >
          Знаете ли вы? {funFacts[factIndex]}
        </motion.p>
      </AnimatePresence>
    </motion.div>
  );
}

function ResultsSection({ result, onReset, onCreateMoodboard }: {
  result: AIResult;
  onReset: () => void;
  onCreateMoodboard: () => void;
}) {
  const [copiedColor, setCopiedColor] = useState<string | null>(null);

  const copyColor = (hex: string) => {
    navigator.clipboard.writeText(hex).catch(() => {});
    setCopiedColor(hex);
    setTimeout(() => setCopiedColor(null), 1500);
  };

  const sectionVariants = {
    hidden: { opacity: 0, y: 20 },
    show: (i: number) => ({
      opacity: 1,
      y: 0,
      transition: {
        delay: i * 0.1,
        duration: 0.4,
        ease: [0.16, 1, 0.3, 1] as [number, number, number, number],
      },
    }),
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <motion.div
        custom={0}
        variants={sectionVariants}
        initial="hidden"
        animate="show"
        className="flex items-center gap-2 mb-2"
      >
        <Sparkles size={20} className="text-[#8b9d83]" />
        <h2 className="font-serif text-xl font-semibold text-[#1a1a1a]">
          Анализ завершен!
        </h2>
      </motion.div>

      {/* Style Result Card */}
      <motion.div
        custom={1}
        variants={sectionVariants}
        initial="hidden"
        animate="show"
        className="bg-white border border-[#e0dbd4] rounded-xl p-5"
      >
        <div className="flex items-start gap-4 mb-4">
          <div className="w-24 h-24 rounded-lg bg-[#f7f5f2] flex items-center justify-center shrink-0 overflow-hidden">
            <img
              src="/style-scandi.jpg"
              alt={result.style.name}
              className="w-full h-full object-cover"
            />
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-sans text-sm text-[#6b6b6b] mb-1">Обнаруженный стиль</p>
            <h3 className="font-serif text-[28px] font-semibold text-[#1a1a1a] leading-tight">
              {result.style.name}
            </h3>
          </div>
        </div>

        {/* Confidence */}
        <div className="mb-3">
          <div className="flex items-center justify-between mb-1.5">
            <span className="font-sans text-sm font-medium text-[#1a1a1a]">
              Уверенность AI
            </span>
            <motion.span
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="font-sans text-sm font-semibold text-[#5a7a5a]"
            >
              {Math.round(result.style.confidence * 100)}%
            </motion.span>
          </div>
          <div className="w-full h-2 bg-[#e0dbd4] rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-[#8b9d83] rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${result.style.confidence * 100}%` }}
              transition={{
                duration: 1,
                delay: 0.3,
                ease: [0.16, 1, 0.3, 1] as [number, number, number, number],
              }}
            />
          </div>
        </div>

        <p className="font-sans text-sm text-[#6b6b6b] mb-3">
          Высокая вероятность соответствия. Характерные признаки: светлые тона,
          натуральное дерево, минимум декора.
        </p>

        <div className="flex flex-wrap gap-2">
          <span className="px-2.5 py-1 rounded-lg bg-[#e8ede5] text-[#5c6b55] font-sans text-xs font-medium">
            Похожие: Минимализм
          </span>
          <span className="px-2.5 py-1 rounded-lg bg-[#e8ede5] text-[#5c6b55] font-sans text-xs font-medium">
            Современная классика
          </span>
        </div>
      </motion.div>

      {/* Color Palette */}
      <motion.div
        custom={2}
        variants={sectionVariants}
        initial="hidden"
        animate="show"
        className="bg-white border border-[#e0dbd4] rounded-xl p-5"
      >
        <h4 className="font-sans text-sm font-semibold text-[#1a1a1a] mb-4">
          Цветовая палитра
        </h4>
        <div className="flex flex-wrap gap-5">
          {result.colorPalette.map((c, i) => (
            <motion.button
              key={c.color}
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{
                delay: 0.2 + i * 0.08,
                duration: 0.3,
                ease: [0.34, 1.56, 0.64, 1] as [number, number, number, number],
              }}
              onClick={() => copyColor(c.color)}
              className="flex flex-col items-center gap-1.5 group relative"
            >
              <div
                className="w-14 h-14 rounded-full border border-[#e0dbd4] shadow-sm transition-transform duration-200 group-hover:scale-110"
                style={{ backgroundColor: c.color }}
              />
              <span className="font-sans text-[11px] text-[#6b6b6b] uppercase">
                {c.color}
              </span>
              <span className="font-sans text-[11px] text-[#9a9a9a]">{c.name}</span>
              <span className="font-sans text-[10px] text-[#8b9d83] uppercase tracking-wide">
                {c.role}
              </span>
              {copiedColor === c.color && (
                <motion.div
                  initial={{ opacity: 0, y: 4 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="absolute -top-6 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded bg-[#1a1a1a] text-white font-sans text-[10px] whitespace-nowrap"
                >
                  Скопировано
                </motion.div>
              )}
            </motion.button>
          ))}
        </div>
      </motion.div>

      {/* Materials */}
      <motion.div
        custom={3}
        variants={sectionVariants}
        initial="hidden"
        animate="show"
        className="bg-white border border-[#e0dbd4] rounded-xl p-5"
      >
        <h4 className="font-sans text-sm font-semibold text-[#1a1a1a] mb-4">
          Материалы
        </h4>
        <div className="space-y-3">
          {result.materials.map((m, i) => (
            <motion.div
              key={m.name}
              initial={{ opacity: 0, x: 12 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 + i * 0.06, duration: 0.3 }}
              className="flex items-center gap-3"
            >
              <div className="w-10 h-10 rounded-lg bg-[#f7f5f2] flex items-center justify-center shrink-0">
                <span className="font-sans text-[10px] font-bold text-[#8b9d83]">
                  {m.category[0]}
                </span>
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-sans text-sm font-medium text-[#1a1a1a]">
                    {m.name}
                  </span>
                  <span className="font-sans text-xs text-[#6b6b6b]">
                    {Math.round(m.confidence * 100)}%
                  </span>
                </div>
                <div className="w-full h-1 bg-[#e0dbd4] rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#8b9d83] rounded-full"
                    style={{ width: `${m.confidence * 100}%` }}
                  />
                </div>
              </div>
              <span className="font-sans text-xs text-[#9a9a9a] shrink-0">
                {m.category}
              </span>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Furniture */}
      <motion.div
        custom={4}
        variants={sectionVariants}
        initial="hidden"
        animate="show"
        className="bg-white border border-[#e0dbd4] rounded-xl p-5"
      >
        <h4 className="font-sans text-sm font-semibold text-[#1a1a1a] mb-4">
          Мебель
        </h4>
        <div className="grid grid-cols-2 gap-3">
          {result.furniture.map((f) => (
            <div
              key={f.type}
              className="p-3 rounded-lg bg-[#efeae4]"
            >
              <p className="font-sans text-sm font-medium text-[#1a1a1a]">{f.type}</p>
              <p className="font-sans text-xs text-[#6b6b6b]">
                {f.style} · {f.color}
              </p>
            </div>
          ))}
        </div>
      </motion.div>

      {/* Textures */}
      <motion.div
        custom={5}
        variants={sectionVariants}
        initial="hidden"
        animate="show"
        className="bg-white border border-[#e0dbd4] rounded-xl p-5"
      >
        <h4 className="font-sans text-sm font-semibold text-[#1a1a1a] mb-4">
          Текстуры
        </h4>
        <div className="flex flex-wrap gap-2">
          {result.textures.map((t) => (
            <span
              key={t}
              className="px-3 py-1.5 rounded-lg bg-[#e8ede5] text-[#5c6b55] font-sans text-sm font-medium"
            >
              {t}
            </span>
          ))}
        </div>
      </motion.div>

      {/* Room Type + Mood */}
      <motion.div
        custom={6}
        variants={sectionVariants}
        initial="hidden"
        animate="show"
        className="bg-white border border-[#e0dbd4] rounded-xl p-5"
      >
        <p className="font-sans text-sm text-[#6b6b6b] mb-1">Тип помещения</p>
        <p className="font-sans text-base font-medium text-[#1a1a1a] mb-4">
          {result.roomType}
        </p>
        <blockquote className="border-l-2 border-[#8b9d83] pl-4 italic font-sans text-sm text-[#6b6b6b] leading-relaxed">
          «{result.moodDescription}»
        </blockquote>
      </motion.div>

      {/* Actions */}
      <motion.div
        custom={7}
        variants={sectionVariants}
        initial="hidden"
        animate="show"
        className="pt-4 space-y-3"
      >
        <button
          onClick={onCreateMoodboard}
          className="w-full py-4 rounded-xl bg-[#8b9d83] text-white font-sans font-medium text-base flex items-center justify-center gap-2 transition-all hover:bg-[#6b7a64] active:scale-[0.97] shadow-md hover:shadow-lg"
        >
          <Sparkles size={18} />
          Создать мудборд
        </button>
        <div className="flex gap-3">
          <button
            onClick={onReset}
            className="flex-1 py-3 rounded-xl border border-[#8b9d83] text-[#1a1a1a] font-sans font-medium text-sm flex items-center justify-center gap-2 transition-colors hover:bg-[#e8ede5]"
          >
            <Camera size={16} />
            Новый анализ
          </button>
          <button
            onClick={() => {}}
            className="flex-1 py-3 rounded-xl font-sans font-medium text-sm text-[#8b9d83] flex items-center justify-center gap-2 transition-colors hover:bg-[rgba(139,157,131,0.08)]"
          >
            <Bookmark size={16} />
            Сохранить
          </button>
        </div>
      </motion.div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Main Page                                                           */
/* ------------------------------------------------------------------ */

export default function AIAnalysis() {
  const navigate = useNavigate();
  const [state, setState] = useState<AnalysisState>('empty');
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const [errorMsg, setErrorMsg] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFile = useCallback(
    async (file: File) => {
      if (!file.type.startsWith('image/')) {
        setErrorMsg('Неподдерживаемый формат. Используйте JPG или PNG.');
        setState('error');
        return;
      }
      if (file.size > 10 * 1024 * 1024) {
        setErrorMsg('Слишком большой файл. Максимум 10 МБ.');
        setState('error');
        return;
      }

      const url = URL.createObjectURL(file);
      setPreviewUrl(url);
      setState('uploaded');
    },
    []
  );

  const startAnalysis = useCallback(async () => {
    setState('analyzing');
    setProgress(0);

    const duration = 3000;
    const startTime = Date.now();

    const tick = () => {
      const elapsed = Date.now() - startTime;
      const p = Math.min((elapsed / duration) * 100, 100);
      setProgress(p);
      if (p < 100) {
        requestAnimationFrame(tick);
      }
    };
    requestAnimationFrame(tick);

    try {
      await aiApi.analyzeImage(previewUrl ?? '');
      setTimeout(() => {
        setState('filled');
      }, duration);
    } catch {
      setErrorMsg('Не удалось проанализировать изображение');
      setState('error');
    }
  }, [previewUrl]);

  const reset = useCallback(() => {
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl(null);
    setState('empty');
    setProgress(0);
    setErrorMsg('');
  }, [previewUrl]);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      const file = e.dataTransfer.files[0];
      if (file) handleFile(file);
    },
    [handleFile]
  );

  const [isDragOver, setIsDragOver] = useState(false);

  return (
    <Layout>
      <div className="min-h-[100dvh] bg-[#f7f5f2]">
        <div className="px-4 md:px-8 pt-4 md:pt-6 pb-8 max-w-[800px] mx-auto">
          {/* Header */}
          <div className="flex items-center gap-3 mb-6">
            <button
              onClick={() => navigate('/dashboard')}
              className="w-10 h-10 flex items-center justify-center rounded-xl hover:bg-[rgba(139,157,131,0.08)] transition-colors"
              aria-label="Назад"
            >
              <ArrowLeft size={20} className="text-[#1a1a1a]" />
            </button>
            <div>
              <h1 className="font-serif text-[24px] md:text-[28px] font-semibold text-[#1a1a1a]">
                AI Анализ
              </h1>
              <p className="font-sans text-sm text-[#6b6b6b] mt-0.5">
                Загрузите фото интерьера — AI определит стиль
              </p>
            </div>
          </div>

          <AnimatePresence mode="wait">
            {/* Empty / Uploaded */}
            {(state === 'empty' || state === 'uploaded') && (
              <motion.div
                key="upload"
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                transition={{ duration: 0.4 }}
                className="space-y-4"
              >
                {/* Upload zone */}
                <div
                  onDragOver={(e) => {
                    e.preventDefault();
                    setIsDragOver(true);
                  }}
                  onDragLeave={() => setIsDragOver(false)}
                  onDrop={(e) => {
                    setIsDragOver(false);
                    handleDrop(e);
                  }}
                  onClick={() => fileInputRef.current?.click()}
                  className={`w-full bg-white border-2 border-dashed rounded-2xl py-12 md:py-16 px-6 text-center cursor-pointer transition-all duration-200 ${
                    isDragOver
                      ? 'border-[#8b9d83] bg-[rgba(139,157,131,0.05)]'
                      : 'border-[#e0dbd4] hover:border-[#c4bfb6]'
                  }`}
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) handleFile(file);
                    }}
                  />
                  <motion.div
                    animate={isDragOver ? { scale: 1.1 } : { scale: 1 }}
                    transition={{ duration: 0.2 }}
                    className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-[#e8ede5] mb-4"
                  >
                    {previewUrl ? (
                      <ImagePlus size={24} className="text-[#8b9d83]" />
                    ) : (
                      <UploadCloud size={24} className="text-[#8b9d83]" />
                    )}
                  </motion.div>
                  <p className="font-sans text-base font-medium text-[#6b6b6b] mb-1">
                    Перетащите фото сюда или нажмите для загрузки
                  </p>
                  <p className="font-sans text-xs text-[#9a9a9a]">
                    Поддерживаются JPG, PNG до 10 МБ
                  </p>
                </div>

                {/* Preview */}
                {previewUrl && (
                  <motion.div
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-white border border-[#e0dbd4] rounded-xl p-4"
                  >
                    <div className="flex items-start gap-4">
                      <img
                        src={previewUrl}
                        alt="Preview"
                        className="w-24 h-24 rounded-lg object-cover"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="font-sans text-sm text-[#1a1a1a] mb-2 truncate">
                          Загруженное изображение
                        </p>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            reset();
                          }}
                          className="inline-flex items-center gap-1.5 font-sans text-sm text-[#c47d7d] hover:underline"
                        >
                          <Trash2 size={14} />
                          Удалить
                        </button>
                      </div>
                    </div>
                    <button
                      onClick={startAnalysis}
                      className="w-full mt-4 py-3 rounded-xl bg-[#8b9d83] text-white font-sans font-medium text-base transition-all hover:bg-[#6b7a64] active:scale-[0.97]"
                    >
                      Анализировать
                    </button>
                  </motion.div>
                )}

                {/* Demo hint */}
                {!previewUrl && (
                  <div className="text-center">
                    <p className="font-sans text-xs text-[#9a9a9a]">
                      Или сделайте скриншот из Instagram
                    </p>
                  </div>
                )}
              </motion.div>
            )}

            {/* Analyzing */}
            {state === 'analyzing' && (
              <motion.div
                key="analyzing"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              >
                <AnalyzingState progress={progress} />
              </motion.div>
            )}

            {/* Filled */}
            {state === 'filled' && (
              <motion.div
                key="filled"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              >
                <ResultsSection
                  result={mockResult}
                  onReset={reset}
                  onCreateMoodboard={() => navigate('/moodboard/new')}
                />
              </motion.div>
            )}

            {/* Error */}
            {state === 'error' && (
              <motion.div
                key="error"
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="bg-white border border-[#e0dbd4] rounded-xl p-8 text-center"
              >
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-[rgba(196,125,125,0.12)] mb-4">
                  <AlertCircle size={24} className="text-[#c47d7d]" />
                </div>
                <h3 className="font-sans text-lg font-medium text-[#1a1a1a] mb-2">
                  Не удалось распознать изображение
                </h3>
                <p className="font-sans text-sm text-[#6b6b6b] mb-6">{errorMsg}</p>
                <div className="flex flex-col gap-3">
                  <button
                    onClick={reset}
                    className="w-full py-3 rounded-xl border border-[#8b9d83] text-[#1a1a1a] font-sans font-medium text-sm transition-colors hover:bg-[#e8ede5]"
                  >
                    Попробовать снова
                  </button>
                  <button
                    onClick={() => navigate('/contractors')}
                    className="w-full py-3 rounded-xl font-sans font-medium text-sm text-[#8b9d83] transition-colors hover:bg-[rgba(139,157,131,0.08)]"
                  >
                    Получить помощь дизайнера
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </Layout>
  );
}
