import { useState, useEffect, useRef, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowLeft,
  Plus,
  Save,
  Share2,
  Download,
  Layers,
  Trash2,
  X,
  GripVertical,
  ImagePlus,
  Sparkles,
  Grid3x3,
  MoreHorizontal,
  Type,
  Move,
} from 'lucide-react';
import { moodboards, type MoodboardItem, type Moodboard } from '@/lib/api';
import Layout from '@/components/Layout';

/* ------------------------------------------------------------------ */
/*  Moodboard Editor Page                                               */
/* ------------------------------------------------------------------ */

interface CanvasItem extends MoodboardItem {
  type: 'image' | 'color' | 'text';
  content?: string;
  color?: string;
}

const CANVAS_WIDTH = 1200;
const CANVAS_HEIGHT = 800;

const sampleItems: CanvasItem[] = [
  {
    id: 'sample-1',
    moodboardId: 'demo',
    imageUrl: '/style-scandi.jpg',
    positionX: 60,
    positionY: 60,
    width: 280,
    height: 210,
    zIndex: 1,
    type: 'image',
  },
  {
    id: 'sample-2',
    moodboardId: 'demo',
    imageUrl: '/style-loft.jpg',
    positionX: 380,
    positionY: 80,
    width: 240,
    height: 180,
    zIndex: 2,
    type: 'image',
  },
  {
    id: 'sample-3',
    moodboardId: 'demo',
    imageUrl: '/style-minimal.jpg',
    positionX: 660,
    positionY: 120,
    width: 220,
    height: 165,
    zIndex: 3,
    type: 'image',
  },
  {
    id: 'sample-4',
    moodboardId: 'demo',
    imageUrl: '',
    positionX: 100,
    positionY: 320,
    width: 100,
    height: 100,
    zIndex: 4,
    type: 'color',
    color: '#F5F5F0',
  },
  {
    id: 'sample-5',
    moodboardId: 'demo',
    imageUrl: '',
    positionX: 230,
    positionY: 340,
    width: 80,
    height: 80,
    zIndex: 5,
    type: 'color',
    color: '#8B9D83',
  },
  {
    id: 'sample-6',
    moodboardId: 'demo',
    imageUrl: '',
    positionX: 500,
    positionY: 320,
    width: 200,
    height: 120,
    zIndex: 6,
    type: 'text',
    content: 'Скандинавский уют — свет, дерево и воздух',
  },
];

/* ------------------------------------------------------------------ */
/*  Utility: clamp                                                     */
/* ------------------------------------------------------------------ */

function clamp(val: number, min: number, max: number) {
  return Math.min(Math.max(val, min), max);
}

/* ------------------------------------------------------------------ */
/*  Moodboard Editor                                                    */
/* ------------------------------------------------------------------ */

export default function MoodboardEditor() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const canvasRef = useRef<HTMLDivElement>(null);

  const [items, setItems] = useState<CanvasItem[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [dragState, setDragState] = useState<{
    itemId: string;
    startX: number;
    startY: number;
    initialX: number;
    initialY: number;
  } | null>(null);

  const [showLayers, setShowLayers] = useState(false);
  const [showAddMenu, setShowAddMenu] = useState(false);
  const [showShare, setShowShare] = useState(false);
  const [showGrid, setShowGrid] = useState(true);
  const [unsaved, setUnsaved] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [editorName, setEditorName] = useState('Новый мудборд');
  const [isEditingName, setIsEditingName] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  /* Load or create moodboard */
  useEffect(() => {
    if (id === 'new') {
      setItems([...sampleItems]);
      setEditorName('Новый мудборд');
      return;
    }
    moodboards
      .get(id!)
      .then((m: Moodboard) => {
        setItems(m.items.map((it) => ({ ...it, type: 'image' as const })));
        setEditorName(m.name);
      })
      .catch(() => {
        // Fallback to sample data
        setItems([...sampleItems]);
      });
  }, [id]);

  const selectedItem = items.find((it) => it.id === selectedId) ?? null;

  /* Drag handlers */
  const handlePointerDown = useCallback(
    (e: React.PointerEvent, itemId: string) => {
      e.preventDefault();
      e.stopPropagation();
      const item = items.find((i) => i.id === itemId);
      if (!item) return;
      setSelectedId(itemId);
      setDragState({
        itemId,
        startX: e.clientX,
        startY: e.clientY,
        initialX: item.positionX,
        initialY: item.positionY,
      });
    },
    [items]
  );

  useEffect(() => {
    if (!dragState) return;

    const handleMove = (e: PointerEvent) => {
      setItems((prev) =>
        prev.map((it) => {
          if (it.id !== dragState.itemId) return it;
          const dx = e.clientX - dragState.startX;
          const dy = e.clientY - dragState.startY;
          return {
            ...it,
            positionX: clamp(
              dragState.initialX + dx,
              0,
              CANVAS_WIDTH - it.width
            ),
            positionY: clamp(
              dragState.initialY + dy,
              0,
              CANVAS_HEIGHT - it.height
            ),
          };
        })
      );
      setUnsaved(true);
    };

    const handleUp = () => {
      setDragState(null);
    };

    window.addEventListener('pointermove', handleMove);
    window.addEventListener('pointerup', handleUp);
    return () => {
      window.removeEventListener('pointermove', handleMove);
      window.removeEventListener('pointerup', handleUp);
    };
  }, [dragState]);

  /* Canvas click to deselect */
  const handleCanvasClick = useCallback(
    (e: React.MouseEvent) => {
      if (e.target === canvasRef.current) {
        setSelectedId(null);
      }
    },
    []
  );

  /* Double-click to bring to front */
  const handleDoubleClick = useCallback((itemId: string) => {
    setItems((prev) => {
      const maxZ = Math.max(...prev.map((i) => i.zIndex), 0);
      return prev.map((it) =>
        it.id === itemId ? { ...it, zIndex: maxZ + 1 } : it
      );
    });
    setUnsaved(true);
  }, []);

  /* Delete item */
  const deleteItem = useCallback((itemId: string) => {
    setItems((prev) => prev.filter((it) => it.id !== itemId));
    setSelectedId((prev) => (prev === itemId ? null : prev));
    setUnsaved(true);
  }, []);

  /* Update item property */
  const updateItem = useCallback(
    (itemId: string, patch: Partial<CanvasItem>) => {
      setItems((prev) =>
        prev.map((it) => (it.id === itemId ? { ...it, ...patch } : it))
      );
      setUnsaved(true);
    },
    []
  );

  /* Bring to front / send to back via layer panel */
  const moveLayer = useCallback(
    (itemId: string, direction: 'up' | 'down') => {
      setItems((prev) => {
        const sorted = [...prev].sort((a, b) => a.zIndex - b.zIndex);
        const idx = sorted.findIndex((i) => i.id === itemId);
        if (idx === -1) return prev;
        const newIdx = direction === 'up'
          ? Math.min(idx + 1, sorted.length - 1)
          : Math.max(idx - 1, 0);
        const [removed] = sorted.splice(idx, 1);
        sorted.splice(newIdx, 0, removed);
        return sorted.map((it, i) => ({ ...it, zIndex: i + 1 }));
      });
      setUnsaved(true);
    },
    []
  );

  /* Add items */
  const addImage = useCallback(() => {
    fileInputRef.current?.click();
  }, []);

  const handleFileChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const url = URL.createObjectURL(file);
      const newItem: CanvasItem = {
        id: `img-${Date.now()}`,
        moodboardId: id ?? 'new',
        imageUrl: url,
        positionX: 100 + Math.random() * 100,
        positionY: 100 + Math.random() * 100,
        width: 240,
        height: 180,
        zIndex: Math.max(...items.map((i) => i.zIndex), 0) + 1,
        type: 'image',
      };
      setItems((prev) => [...prev, newItem]);
      setSelectedId(newItem.id);
      setUnsaved(true);
      setShowAddMenu(false);
    },
    [id, items]
  );

  const addColor = useCallback(
    (color: string) => {
      const newItem: CanvasItem = {
        id: `color-${Date.now()}`,
        moodboardId: id ?? 'new',
        imageUrl: '',
        positionX: 150 + Math.random() * 80,
        positionY: 150 + Math.random() * 80,
        width: 80,
        height: 80,
        zIndex: Math.max(...items.map((i) => i.zIndex), 0) + 1,
        type: 'color',
        color,
      };
      setItems((prev) => [...prev, newItem]);
      setSelectedId(newItem.id);
      setUnsaved(true);
      setShowAddMenu(false);
    },
    [id, items]
  );

  const addText = useCallback(() => {
    const newItem: CanvasItem = {
      id: `text-${Date.now()}`,
      moodboardId: id ?? 'new',
      imageUrl: '',
      positionX: 200,
      positionY: 200,
      width: 200,
      height: 60,
      zIndex: Math.max(...items.map((i) => i.zIndex), 0) + 1,
      type: 'text',
      content: 'Новая заметка',
    };
    setItems((prev) => [...prev, newItem]);
    setSelectedId(newItem.id);
    setUnsaved(true);
    setShowAddMenu(false);
  }, [id, items]);

  /* Save */
  const handleSave = useCallback(async () => {
    setIsSaving(true);
    try {
      if (id && id !== 'new') {
        // Existing board: update via API (mock localStorage)
        const all = JSON.parse(localStorage.getItem('moodboards') || '[]');
        const idx = all.findIndex((m: Moodboard) => m.id === id);
        const cleanItems = items.map(({ type, content, color, ...rest }) => rest);
        if (idx !== -1) {
          all[idx] = { ...all[idx], name: editorName, items: cleanItems };
        } else {
          all.push({
            id,
            userId: 'demo',
            projectId: 'demo-lavada',
            name: editorName,
            items: cleanItems,
          });
        }
        localStorage.setItem('moodboards', JSON.stringify(all));
      } else {
        // Create new
        const cleanItems = items.map(({ type, content, color, ...rest }) => rest);
        await moodboards.create({
          userId: 'demo',
          projectId: 'demo-lavada',
          name: editorName,
        });
        const all = JSON.parse(localStorage.getItem('moodboards') || '[]');
        all[all.length - 1].items = cleanItems;
        localStorage.setItem('moodboards', JSON.stringify(all));
      }
      setUnsaved(false);
    } catch {
      // ignore
    } finally {
      setIsSaving(false);
    }
  }, [id, items, editorName]);

  /* Export PNG */
  const handleExportPNG = useCallback(() => {
    const canvas = document.createElement('canvas');
    canvas.width = CANVAS_WIDTH;
    canvas.height = CANVAS_HEIGHT;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    // Grid
    if (showGrid) {
      ctx.fillStyle = '#e0dbd4';
      for (let x = 0; x < CANVAS_WIDTH; x += 20) {
        for (let y = 0; y < CANVAS_HEIGHT; y += 20) {
          ctx.fillRect(x, y, 1, 1);
        }
      }
    }

    // Draw items (simplified — only colors and text, images skipped for simplicity)
    const sorted = [...items].sort((a, b) => a.zIndex - b.zIndex);
    sorted.forEach((it) => {
      if (it.type === 'color' && it.color) {
        ctx.fillStyle = it.color;
        ctx.fillRect(it.positionX, it.positionY, it.width, it.height);
        ctx.strokeStyle = '#e0dbd4';
        ctx.lineWidth = 1;
        ctx.strokeRect(it.positionX, it.positionY, it.width, it.height);
      } else if (it.type === 'text' && it.content) {
        ctx.fillStyle = 'rgba(255,255,255,0.9)';
        ctx.fillRect(it.positionX, it.positionY, it.width, it.height);
        ctx.fillStyle = '#1a1a1a';
        ctx.font = '14px Inter, sans-serif';
        ctx.fillText(it.content, it.positionX + 8, it.positionY + 24);
      }
    });

    const link = document.createElement('a');
    link.download = `${editorName}.png`;
    link.href = canvas.toDataURL();
    link.click();
  }, [items, showGrid, editorName]);

  /* Keyboard shortcuts */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Delete' || e.key === 'Backspace') {
        if (selectedId) deleteItem(selectedId);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [selectedId, deleteItem]);

  /* Sorted items by z-index */
  const sortedItems = [...items].sort((a, b) => a.zIndex - b.zIndex);

  return (
    <Layout>
      <div className="min-h-[100dvh] bg-[#f7f5f2] flex flex-col">
        {/* Header Toolbar */}
        <div className="h-14 bg-white border-b border-[#e0dbd4] flex items-center px-4 gap-3 shrink-0 z-50">
          <button
            onClick={() => navigate('/dashboard')}
            className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-[#f7f5f2] transition-colors"
          >
            <ArrowLeft size={18} className="text-[#1a1a1a]" />
          </button>

          {/* Title */}
          {isEditingName ? (
            <input
              autoFocus
              value={editorName}
              onChange={(e) => setEditorName(e.target.value)}
              onBlur={() => setIsEditingName(false)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') setIsEditingName(false);
              }}
              className="font-serif text-base font-medium text-[#1a1a1a] bg-transparent border-b border-[#8b9d83] outline-none px-1"
            />
          ) : (
            <button
              onClick={() => setIsEditingName(true)}
              className="flex items-center gap-1"
            >
              <h1 className="font-serif text-base font-medium text-[#1a1a1a]">
                Мудборд
              </h1>
              <span className="font-sans text-sm text-[#6b6b6b]">
                {editorName}
                {unsaved && ' *'}
              </span>
            </button>
          )}

          <div className="flex-1" />

          {/* Desktop toolbar */}
          <div className="hidden md:flex items-center gap-2">
            <button
              onClick={() => setShowAddMenu(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-sans text-sm font-medium text-[#8b9d83] hover:bg-[rgba(139,157,131,0.08)] transition-colors"
            >
              <Plus size={16} />
              Добавить
            </button>
            <button
              onClick={() => setShowShare(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-sans text-sm font-medium text-[#8b9d83] hover:bg-[rgba(139,157,131,0.08)] transition-colors"
            >
              <Share2 size={16} />
              Поделиться
            </button>
            <button
              onClick={handleSave}
              disabled={isSaving}
              className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-[#8b9d83] text-white font-sans text-sm font-medium transition-colors hover:bg-[#6b7a64] disabled:opacity-60"
            >
              <Save size={16} />
              {isSaving ? 'Сохранение...' : 'Сохранить'}
            </button>
          </div>

          {/* Mobile: icon-only actions */}
          <div className="flex md:hidden items-center gap-1">
            <button
              onClick={() => setShowAddMenu(true)}
              className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-[#f7f5f2]"
            >
              <Plus size={18} className="text-[#8b9d83]" />
            </button>
            <button
              onClick={handleSave}
              className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-[#f7f5f2]"
            >
              <Save size={18} className="text-[#8b9d83]" />
            </button>
          </div>
        </div>

        {/* Main workspace */}
        <div className="flex-1 flex overflow-hidden">
          {/* Canvas area */}
          <div className="flex-1 overflow-auto p-4 md:p-6">
            <div
              ref={canvasRef}
              onClick={handleCanvasClick}
              className="relative mx-auto"
              style={{
                width: CANVAS_WIDTH,
                height: CANVAS_HEIGHT,
                backgroundColor: '#ffffff',
                backgroundImage: showGrid
                  ? 'radial-gradient(#e0dbd4 1px, transparent 1px)'
                  : 'none',
                backgroundSize: showGrid ? '20px 20px' : 'auto',
                boxShadow: '0 2px 12px rgb(0 0 0 / 0.06)',
              }}
            >
              {/* Empty state overlay */}
              {items.length === 0 && (
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <div className="border-2 border-dashed border-[#e0dbd4] rounded-2xl p-10 text-center">
                    <Grid3x3
                      size={48}
                      className="text-[#8b9d83] mx-auto mb-4"
                      style={{ opacity: 0.3 }}
                    />
                    <p className="font-sans text-sm text-[#9a9a9a] mb-3">
                      Перетащите изображения сюда
                    </p>
                    <button
                      onClick={() => setShowAddMenu(true)}
                      className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#8b9d83] text-white font-sans text-sm font-medium"
                    >
                      <ImagePlus size={16} />
                      Добавить из галереи
                    </button>
                    <div className="mt-6">
                      <p className="font-sans text-xs text-[#9a9a9a] mb-2">
                        Пример мудборда:
                      </p>
                      <img
                        src="/moodboard-sample.jpg"
                        alt="Пример"
                        className="w-48 h-36 object-cover rounded-lg mx-auto"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Items */}
              {sortedItems.map((item) => {
                const isSelected = selectedId === item.id;
                return (
                  <motion.div
                    key={item.id}
                    initial={{ scale: 0, rotate: -5 }}
                    animate={{ scale: 1, rotate: 0 }}
                    transition={{
                      type: 'spring',
                      stiffness: 300,
                      damping: 20,
                    }}
                    onPointerDown={(e) => handlePointerDown(e, item.id)}
                    onDoubleClick={() => handleDoubleClick(item.id)}
                    className={`absolute cursor-move select-none ${
                      isSelected ? 'ring-2 ring-[#8b9d83]' : ''
                    }`}
                    style={{
                      left: item.positionX,
                      top: item.positionY,
                      width: item.width,
                      height: item.height,
                      zIndex: item.zIndex,
                    }}
                  >
                    {item.type === 'image' && (
                      <img
                        src={item.imageUrl}
                        alt=""
                        className="w-full h-full object-cover rounded-lg shadow-md pointer-events-none"
                        draggable={false}
                      />
                    )}
                    {item.type === 'color' && (
                      <div
                        className="w-full h-full rounded-lg border border-[#e0dbd4] shadow-sm flex items-end justify-center pb-2 pointer-events-none"
                        style={{ backgroundColor: item.color }}
                      >
                        <span className="font-sans text-[10px] text-[#1a1a1a] bg-white/80 px-1 rounded">
                          {item.color}
                        </span>
                      </div>
                    )}
                    {item.type === 'text' && (
                      <div className="w-full h-full bg-white/90 border border-[#e0dbd4] rounded-lg p-2 shadow-sm pointer-events-none overflow-hidden">
                        <p className="font-sans text-sm text-[#1a1a1a]">
                          {item.content}
                        </p>
                      </div>
                    )}
                  </motion.div>
                );
              })}
            </div>
          </div>

          {/* Desktop: Properties panel */}
          <AnimatePresence>
            {selectedItem && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ duration: 0.2 }}
                className="hidden md:flex w-[240px] flex-col bg-white border-l border-[#e0dbd4] p-4 overflow-y-auto"
              >
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-sans text-sm font-semibold text-[#1a1a1a]">
                    Свойства
                  </h3>
                  <button
                    onClick={() => setSelectedId(null)}
                    className="w-6 h-6 flex items-center justify-center rounded hover:bg-[#f7f5f2]"
                  >
                    <X size={14} className="text-[#6b6b6b]" />
                  </button>
                </div>

                <div className="space-y-4">
                  {/* Position */}
                  <div>
                    <label className="font-sans text-xs text-[#6b6b6b] mb-1 block">
                      Позиция
                    </label>
                    <div className="flex gap-2">
                      <div className="flex-1">
                        <span className="font-sans text-[10px] text-[#9a9a9a]">X</span>
                        <input
                          type="number"
                          value={Math.round(selectedItem.positionX)}
                          onChange={(e) =>
                            updateItem(selectedItem.id, {
                              positionX: Number(e.target.value),
                            })
                          }
                          className="w-full px-2 py-1.5 rounded-lg border border-[#e0dbd4] font-sans text-sm"
                        />
                      </div>
                      <div className="flex-1">
                        <span className="font-sans text-[10px] text-[#9a9a9a]">Y</span>
                        <input
                          type="number"
                          value={Math.round(selectedItem.positionY)}
                          onChange={(e) =>
                            updateItem(selectedItem.id, {
                              positionY: Number(e.target.value),
                            })
                          }
                          className="w-full px-2 py-1.5 rounded-lg border border-[#e0dbd4] font-sans text-sm"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Size */}
                  <div>
                    <label className="font-sans text-xs text-[#6b6b6b] mb-1 block">
                      Размер
                    </label>
                    <div className="flex gap-2">
                      <div className="flex-1">
                        <span className="font-sans text-[10px] text-[#9a9a9a]">W</span>
                        <input
                          type="number"
                          value={Math.round(selectedItem.width)}
                          onChange={(e) =>
                            updateItem(selectedItem.id, {
                              width: Number(e.target.value),
                            })
                          }
                          className="w-full px-2 py-1.5 rounded-lg border border-[#e0dbd4] font-sans text-sm"
                        />
                      </div>
                      <div className="flex-1">
                        <span className="font-sans text-[10px] text-[#9a9a9a]">H</span>
                        <input
                          type="number"
                          value={Math.round(selectedItem.height)}
                          onChange={(e) =>
                            updateItem(selectedItem.id, {
                              height: Number(e.target.value),
                            })
                          }
                          className="w-full px-2 py-1.5 rounded-lg border border-[#e0dbd4] font-sans text-sm"
                        />
                      </div>
                    </div>
                  </div>

                  {/* z-index */}
                  <div>
                    <label className="font-sans text-xs text-[#6b6b6b] mb-1 block">
                      z-index
                    </label>
                    <input
                      type="number"
                      value={selectedItem.zIndex}
                      onChange={(e) =>
                        updateItem(selectedItem.id, {
                          zIndex: Number(e.target.value),
                        })
                      }
                      className="w-full px-2 py-1.5 rounded-lg border border-[#e0dbd4] font-sans text-sm"
                    />
                  </div>

                  {/* Text content (if text item) */}
                  {selectedItem.type === 'text' && (
                    <div>
                      <label className="font-sans text-xs text-[#6b6b6b] mb-1 block">
                        Текст
                      </label>
                      <textarea
                        value={selectedItem.content ?? ''}
                        onChange={(e) =>
                          updateItem(selectedItem.id, {
                            content: e.target.value,
                          })
                        }
                        className="w-full px-2 py-1.5 rounded-lg border border-[#e0dbd4] font-sans text-sm resize-none"
                        rows={3}
                      />
                    </div>
                  )}

                  {/* Color content (if color item) */}
                  {selectedItem.type === 'color' && (
                    <div>
                      <label className="font-sans text-xs text-[#6b6b6b] mb-1 block">
                        Цвет
                      </label>
                      <div className="flex items-center gap-2">
                        <input
                          type="color"
                          value={selectedItem.color ?? '#ffffff'}
                          onChange={(e) =>
                            updateItem(selectedItem.id, {
                              color: e.target.value,
                            })
                          }
                          className="w-10 h-10 rounded-lg border border-[#e0dbd4] cursor-pointer"
                        />
                        <input
                          type="text"
                          value={selectedItem.color ?? ''}
                          onChange={(e) =>
                            updateItem(selectedItem.id, {
                              color: e.target.value,
                            })
                          }
                          className="flex-1 px-2 py-1.5 rounded-lg border border-[#e0dbd4] font-sans text-sm"
                        />
                      </div>
                    </div>
                  )}

                  {/* Delete */}
                  <button
                    onClick={() => deleteItem(selectedItem.id)}
                    className="w-full py-2.5 rounded-xl bg-[rgba(196,125,125,0.12)] text-[#8a4a4a] font-sans text-sm font-medium flex items-center justify-center gap-2 transition-colors hover:bg-[rgba(196,125,125,0.2)]"
                  >
                    <Trash2 size={14} />
                    Удалить элемент
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Mobile bottom toolbar */}
        <div className="md:hidden fixed bottom-0 left-0 right-0 h-16 bg-white border-t border-[#e0dbd4] z-[100] flex items-center justify-around px-2 safe-area-pb">
          <button
            onClick={() => setShowAddMenu(true)}
            className="flex flex-col items-center gap-0.5 py-2 px-3"
          >
            <Plus size={20} className="text-[#8b9d83]" />
            <span className="text-[10px] font-sans text-[#8b9d83]">Добавить</span>
          </button>
          <button
            onClick={() => setShowGrid((g) => !g)}
            className="flex flex-col items-center gap-0.5 py-2 px-3"
          >
            <Grid3x3
              size={20}
              className={showGrid ? 'text-[#8b9d83]' : 'text-[#9a9a9a]'}
            />
            <span className="text-[10px] font-sans text-[#9a9a9a]">Сетка</span>
          </button>
          <button
            onClick={() => setShowLayers(true)}
            className="flex flex-col items-center gap-0.5 py-2 px-3"
          >
            <Layers size={20} className="text-[#8b9d83]" />
            <span className="text-[10px] font-sans text-[#8b9d83]">Слои</span>
          </button>
          <button
            onClick={() => setShowShare(true)}
            className="flex flex-col items-center gap-0.5 py-2 px-3"
          >
            <MoreHorizontal size={20} className="text-[#8b9d83]" />
            <span className="text-[10px] font-sans text-[#8b9d83]">Ещё</span>
          </button>
        </div>

        {/* Add Menu (mobile sheet / desktop popover) */}
        <AnimatePresence>
          {showAddMenu && (
            <>
              <motion.div
                className="fixed inset-0 z-[300] bg-[rgba(26,26,26,0.4)] backdrop-blur-sm"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setShowAddMenu(false)}
              />
              <motion.div
                className="md:hidden fixed bottom-0 left-0 right-0 z-[400] bg-white rounded-t-[24px] p-6 pb-10"
                initial={{ y: '100%' }}
                animate={{ y: 0 }}
                exit={{ y: '100%' }}
                transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
              >
                <AddMenuContent
                  onAddImage={addImage}
                  onAddColor={addColor}
                  onAddText={addText}
                  onClose={() => setShowAddMenu(false)}
                />
              </motion.div>
              <motion.div
                className="hidden md:block fixed top-16 right-4 z-[400] bg-white rounded-xl border border-[#e0dbd4] shadow-lg p-4 w-[220px]"
                initial={{ opacity: 0, y: -8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
              >
                <AddMenuContent
                  onAddImage={addImage}
                  onAddColor={addColor}
                  onAddText={addText}
                  onClose={() => setShowAddMenu(false)}
                />
              </motion.div>
            </>
          )}
        </AnimatePresence>

        {/* Layers Panel (mobile sheet / desktop sidebar toggle) */}
        <AnimatePresence>
          {showLayers && (
            <>
              <motion.div
                className="fixed inset-0 z-[300] bg-[rgba(26,26,26,0.4)] backdrop-blur-sm md:hidden"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setShowLayers(false)}
              />
              <motion.div
                className="md:hidden fixed bottom-0 left-0 right-0 z-[400] bg-white rounded-t-[24px] p-6 pb-10 max-h-[60vh] overflow-y-auto"
                initial={{ y: '100%' }}
                animate={{ y: 0 }}
                exit={{ y: '100%' }}
                transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
              >
                <LayersPanel
                  items={sortedItems}
                  selectedId={selectedId}
                  onSelect={setSelectedId}
                  onMove={moveLayer}
                  onDelete={deleteItem}
                  onClose={() => setShowLayers(false)}
                />
              </motion.div>
            </>
          )}
        </AnimatePresence>

        {/* Share Modal */}
        <AnimatePresence>
          {showShare && (
            <>
              <motion.div
                className="fixed inset-0 z-[300] bg-[rgba(26,26,26,0.4)] backdrop-blur-sm"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setShowShare(false)}
              />
              <motion.div
                className="fixed inset-x-4 md:inset-x-auto md:left-1/2 md:-translate-x-1/2 top-1/2 -translate-y-1/2 md:w-[360px] z-[400] bg-white rounded-2xl p-6 shadow-xl"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
              >
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-serif text-lg font-semibold text-[#1a1a1a]">
                    Поделиться
                  </h3>
                  <button
                    onClick={() => setShowShare(false)}
                    className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-[#f7f5f2]"
                  >
                    <X size={18} className="text-[#6b6b6b]" />
                  </button>
                </div>
                <div className="space-y-3">
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(window.location.href);
                      setShowShare(false);
                    }}
                    className="w-full flex items-center gap-3 p-3 rounded-xl border border-[#e0dbd4] hover:border-[#8b9d83] transition-colors"
                  >
                    <Share2 size={18} className="text-[#8b9d83]" />
                    <span className="font-sans text-sm text-[#1a1a1a]">
                      Скопировать ссылку
                    </span>
                  </button>
                  <button
                    onClick={handleExportPNG}
                    className="w-full flex items-center gap-3 p-3 rounded-xl border border-[#e0dbd4] hover:border-[#8b9d83] transition-colors"
                  >
                    <Download size={18} className="text-[#8b9d83]" />
                    <span className="font-sans text-sm text-[#1a1a1a]">
                      Экспорт PNG
                    </span>
                  </button>
                  <button
                    onClick={() => {
                      window.print();
                    }}
                    className="w-full flex items-center gap-3 p-3 rounded-xl border border-[#e0dbd4] hover:border-[#8b9d83] transition-colors"
                  >
                    <Download size={18} className="text-[#8b9d83]" />
                    <span className="font-sans text-sm text-[#1a1a1a]">
                      Экспорт PDF
                    </span>
                  </button>
                </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>

        {/* Hidden file input */}
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={handleFileChange}
        />
      </div>
    </Layout>
  );
}

/* ------------------------------------------------------------------ */
/*  Add Menu Content                                                    */
/* ------------------------------------------------------------------ */

function AddMenuContent({
  onAddImage,
  onAddColor,
  onAddText,
  onClose,
}: {
  onAddImage: () => void;
  onAddColor: (c: string) => void;
  onAddText: () => void;
  onClose: () => void;
}) {
  const presetColors = [
    '#F5F5F0',
    '#D4C4A8',
    '#8B9D83',
    '#A08060',
    '#4A4A4A',
    '#E8DDD0',
    '#C9A96E',
    '#1A1A2E',
  ];

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-serif text-lg font-semibold text-[#1a1a1a]">
          Добавить элемент
        </h3>
        <button onClick={onClose} className="p-1">
          <X size={20} className="text-[#6b6b6b]" />
        </button>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <button
          onClick={onAddImage}
          className="flex flex-col items-center gap-2 p-4 rounded-xl border border-[#e0dbd4] hover:border-[#8b9d83] transition-colors"
        >
          <ImagePlus size={24} className="text-[#8b9d83]" />
          <span className="font-sans text-sm text-[#1a1a1a]">Загрузить фото</span>
        </button>
        <button
          onClick={() => {}}
          className="flex flex-col items-center gap-2 p-4 rounded-xl border border-[#e0dbd4] hover:border-[#8b9d83] transition-colors opacity-60"
        >
          <Sparkles size={24} className="text-[#8b9d83]" />
          <span className="font-sans text-sm text-[#1a1a1a]">Из AI анализа</span>
        </button>
        <button
          onClick={onAddText}
          className="flex flex-col items-center gap-2 p-4 rounded-xl border border-[#e0dbd4] hover:border-[#8b9d83] transition-colors"
        >
          <Type size={24} className="text-[#8b9d83]" />
          <span className="font-sans text-sm text-[#1a1a1a]">Текст</span>
        </button>
      </div>
      <div className="mt-4">
        <p className="font-sans text-xs text-[#6b6b6b] mb-2">Цвета</p>
        <div className="flex flex-wrap gap-2">
          {presetColors.map((c) => (
            <button
              key={c}
              onClick={() => onAddColor(c)}
              className="w-10 h-10 rounded-full border border-[#e0dbd4] transition-transform hover:scale-110"
              style={{ backgroundColor: c }}
              aria-label={`Добавить цвет ${c}`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Layers Panel                                                        */
/* ------------------------------------------------------------------ */

function LayersPanel({
  items,
  selectedId,
  onSelect,
  onMove,
  onDelete,
  onClose,
}: {
  items: CanvasItem[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  onMove: (id: string, dir: 'up' | 'down') => void;
  onDelete: (id: string) => void;
  onClose: () => void;
}) {
  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-serif text-lg font-semibold text-[#1a1a1a]">Слои</h3>
        <button onClick={onClose} className="p-1">
          <X size={20} className="text-[#6b6b6b]" />
        </button>
      </div>
      <div className="space-y-2">
        {[...items].reverse().map((item) => (
          <motion.div
            key={item.id}
            layout
            className={`flex items-center gap-2 p-2 rounded-xl border transition-colors ${
              selectedId === item.id
                ? 'border-[#8b9d83] bg-[rgba(139,157,131,0.06)]'
                : 'border-transparent hover:bg-[#f7f5f2]'
            }`}
          >
            <button
              onClick={() => onSelect(item.id)}
              className="flex items-center gap-3 flex-1 min-w-0"
            >
              <GripVertical size={14} className="text-[#c4bfb6] shrink-0" />
              <div className="w-8 h-8 rounded-lg bg-[#f7f5f2] border border-[#e0dbd4] overflow-hidden shrink-0 flex items-center justify-center">
                {item.type === 'image' ? (
                  <img
                    src={item.imageUrl}
                    alt=""
                    className="w-full h-full object-cover"
                  />
                ) : item.type === 'color' ? (
                  <div
                    className="w-full h-full"
                    style={{ backgroundColor: item.color }}
                  />
                ) : (
                  <Type size={12} className="text-[#6b6b6b]" />
                )}
              </div>
              <span className="font-sans text-sm text-[#1a1a1a] truncate">
                {item.type === 'image'
                  ? 'Изображение'
                  : item.type === 'color'
                  ? item.color
                  : item.content}
              </span>
            </button>
            <div className="flex items-center gap-1 shrink-0">
              <button
                onClick={() => onMove(item.id, 'up')}
                className="w-6 h-6 flex items-center justify-center rounded hover:bg-[#e0dbd4]"
              >
                <Move size={12} className="text-[#6b6b6b]" />
              </button>
              <button
                onClick={() => onDelete(item.id)}
                className="w-6 h-6 flex items-center justify-center rounded hover:bg-[rgba(196,125,125,0.12)]"
              >
                <Trash2 size={12} className="text-[#c47d7d]" />
              </button>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
