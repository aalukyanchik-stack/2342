import { useState, useEffect, useMemo, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Search, AlertCircle, Users, Plus } from 'lucide-react';
import { contractors, type Contractor } from '@/lib/api';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/components/Toast';
import ContractorCard from '@/components/contractors/ContractorCard';
import ContractorModal from '@/components/contractors/ContractorModal';
import ContractorSkeleton from '@/components/contractors/ContractorSkeleton';

const FILTERS = [
  'Все',
  'Электрика',
  'Сантехника',
  'Плиточник',
  'Маляр',
  'Дизайнер',
  'Сборщик мебели',
  'Уборщик',
];

const RICH_CONTRACTORS: Array<Contractor & { about: string; services: { name: string; price: string }[]; telegram: string; yearsExp: number; projectsCount: number }> = [
  {
    id: 'rc-1', name: 'Иван Петров', specialization: 'Электрика', rating: 4.9, reviews: 24, region: 'Москва',
    phone: '+7 (900) 123-45-67', email: 'ivan.elec@mail.ru', priceRange: '$$',
    about: 'Опытный электрик с 15-летним стажем. Монтаж проводки любой сложности, умный дом, автоматика. Гарантия 2 года.',
    services: [{ name: 'Замена розетки', price: '500 ₽' }, { name: 'Монтаж проводки', price: 'от 3,000 ₽/час' }, { name: 'Умный дом', price: 'от 25,000 ₽' }],
    telegram: 'ivan_electric', yearsExp: 15, projectsCount: 340, avatar: '/avatar-default.jpg',
  },
  {
    id: 'rc-2', name: 'Сергей Смирнов', specialization: 'Сантехника', rating: 4.7, reviews: 18, region: 'Москва',
    phone: '+7 (900) 234-56-78', email: 'serg.plumber@mail.ru', priceRange: '$',
    about: 'Все виды сантехнических работ. Замена труб, установка сантехники, тёплые полы. Работаю быстро и чисто.',
    services: [{ name: 'Замена смесителя', price: '1,500 ₽' }, { name: 'Монтаж труб', price: 'от 2,500 ₽/час' }, { name: 'Тёплый пол', price: 'от 8,000 ₽' }],
    telegram: 'smirnov_santeh', yearsExp: 10, projectsCount: 210, avatar: '/avatar-default.jpg',
  },
  {
    id: 'rc-3', name: 'Алексей Кузнецов', specialization: 'Плиточник', rating: 4.8, reviews: 15, region: 'Москва',
    phone: '+7 (900) 345-67-89', email: 'alex.tile@mail.ru', priceRange: '$$',
    about: 'Профессиональная укладка плитки, керамогранита, мозаики. Идеальные швы, сложные раскладки, подрезка.',
    services: [{ name: 'Укладка плитки', price: 'от 2,800 ₽/м²' }, { name: 'Керамогранит', price: 'от 3,200 ₽/м²' }, { name: 'Мозаика', price: 'от 4,500 ₽/м²' }],
    telegram: 'kuznetsov_tile', yearsExp: 12, projectsCount: 180, avatar: '/avatar-default.jpg',
  },
  {
    id: 'rc-4', name: 'Мария Волкова', specialization: 'Дизайнер', rating: 5.0, reviews: 32, region: 'Москва',
    phone: '+7 (900) 456-78-90', email: 'maria.design@mail.ru', priceRange: '$$$',
    about: 'Интерьерный дизайнер. Полный цикл: концепция, визуализация, сопровождение ремонта. Специализация — скандинавский и современный стили.',
    services: [{ name: 'Консультация', price: '5,000 ₽' }, { name: 'Дизайн-проект', price: 'от 8,000 ₽/м²' }, { name: 'Авторский надзор', price: 'от 25,000 ₽/мес' }],
    telegram: 'volkova_design', yearsExp: 8, projectsCount: 95, avatar: '/avatar-default.jpg',
  },
  {
    id: 'rc-5', name: 'Дмитрий Лебедев', specialization: 'Маляр', rating: 4.6, reviews: 9, region: 'Москва',
    phone: '+7 (900) 567-89-01', email: 'dima.paint@mail.ru', priceRange: '$',
    about: 'Покраска, поклейка обоев, декоративная штукатурка. Использую материалы премиум-класса. Чистота на объекте.',
    services: [{ name: 'Покраска стен', price: 'от 400 ₽/м²' }, { name: 'Обои', price: 'от 350 ₽/м²' }, { name: 'Декор. штукатурка', price: 'от 800 ₽/м²' }],
    telegram: 'lebedev_paint', yearsExp: 6, projectsCount: 120, avatar: '/avatar-default.jpg',
  },
  {
    id: 'rc-6', name: 'Николай Соколов', specialization: 'Электрика', rating: 4.8, reviews: 21, region: 'Москва',
    phone: '+7 (900) 678-90-12', email: 'nik.elec@mail.ru', priceRange: '$$',
    about: 'Электромонтаж в квартирах и домах. Слаботочка, видеонаблюдение, интернет. Сертифицированный специалист.',
    services: [{ name: 'Электромонтаж', price: 'от 3,500 ₽/час' }, { name: 'Видеонаблюдение', price: 'от 15,000 ₽' }, { name: 'Слаботочка', price: 'от 2,000 ₽/час' }],
    telegram: 'sokolov_elec', yearsExp: 14, projectsCount: 290, avatar: '/avatar-default.jpg',
  },
  {
    id: 'rc-7', name: 'Ольга Морозова', specialization: 'Сборщик мебели', rating: 4.9, reviews: 41, region: 'Москва',
    phone: '+7 (900) 789-01-23', email: 'olga.furn@mail.ru', priceRange: '$',
    about: 'Сборка и установка кухонь, шкафов-купе, мебели ИКЕА. Свой инструмент, аккуратность, уборка после работы.',
    services: [{ name: 'Кухня', price: 'от 5,000 ₽' }, { name: 'Шкаф-купе', price: 'от 3,500 ₽' }, { name: 'Мебель ИКЕА', price: 'от 1,500 ₽/ед' }],
    telegram: 'morozova_furn', yearsExp: 7, projectsCount: 520, avatar: '/avatar-default.jpg',
  },
  {
    id: 'rc-8', name: 'Андрей Попов', specialization: 'Уборщик', rating: 4.5, reviews: 13, region: 'Москва',
    phone: '+7 (900) 890-12-34', email: 'andrey.clean@mail.ru', priceRange: '$',
    about: 'Генеральная уборка после ремонта. Уборка строительной пыли, мойка окон, химчистка. Профессиональная техника Kärcher.',
    services: [{ name: 'Ген. уборка', price: 'от 80 ₽/м²' }, { name: 'Мойка окон', price: 'от 300 ₽/м²' }, { name: 'Химчистка', price: 'от 2,000 ₽' }],
    telegram: 'popov_clean', yearsExp: 5, projectsCount: 150, avatar: '/avatar-default.jpg',
  },
  {
    id: 'rc-9', name: 'Екатерина Новикова', specialization: 'Дизайнер', rating: 4.7, reviews: 19, region: 'Москва',
    phone: '+7 (900) 901-23-45', email: 'katya.design@mail.ru', priceRange: '$$',
    about: 'Дизайн интерьера и ремонт под ключ. Работаю с бюджетами любого уровня. Бесплатная консультация.',
    services: [{ name: 'Дизайн-проект', price: 'от 6,000 ₽/м²' }, { name: 'Ремонт под ключ', price: 'от 25,000 ₽/м²' }, { name: 'Консультация', price: 'бесплатно' }],
    telegram: 'novikova_design', yearsExp: 6, projectsCount: 75, avatar: '/avatar-default.jpg',
  },
  {
    id: 'rc-10', name: 'Михаил Козлов', specialization: 'Сантехника', rating: 4.8, reviews: 27, region: 'Москва',
    phone: '+7 (900) 012-34-56', email: 'misha.plumb@mail.ru', priceRange: '$$',
    about: 'Сложные сантехнические работы. Котельные, водоснабжение, канализация. Проектирование и монтаж.',
    services: [{ name: 'Монтаж котла', price: 'от 8,000 ₽' }, { name: 'Водоснабжение', price: 'от 3,500 ₽/час' }, { name: 'Ремонт труб', price: 'от 2,500 ₽/час' }],
    telegram: 'kozlov_plumb', yearsExp: 11, projectsCount: 260, avatar: '/avatar-default.jpg',
  },
  {
    id: 'rc-11', name: 'Татьяна Соловьёва', specialization: 'Плиточник', rating: 4.6, reviews: 14, region: 'Москва',
    phone: '+7 (900) 123-45-68', email: 'tanya.tile@mail.ru', priceRange: '$$',
    about: 'Плиточные работы с гарантией. Большой формат, сложные углы, душевые поддоны. Помощь в подборе материалов.',
    services: [{ name: 'Плитка', price: 'от 2,500 ₽/м²' }, { name: 'Крупный формат', price: 'от 3,500 ₽/м²' }, { name: 'Подбор материалов', price: 'бесплатно' }],
    telegram: 'solovyova_tile', yearsExp: 9, projectsCount: 160, avatar: '/avatar-default.jpg',
  },
  {
    id: 'rc-12', name: 'Владимир Васильев', specialization: 'Маляр', rating: 4.7, reviews: 11, region: 'Москва',
    phone: '+7 (900) 234-56-79', email: 'vlad.paint@mail.ru', priceRange: '$',
    about: 'Отделочные работы премиум-класса. Венецианская штукатурка, марморино, покраска эмалью.',
    services: [{ name: 'Покраска', price: 'от 450 ₽/м²' }, { name: 'Венецианка', price: 'от 1,200 ₽/м²' }, { name: 'Подготовка стен', price: 'от 300 ₽/м²' }],
    telegram: 'vasiliev_paint', yearsExp: 13, projectsCount: 200, avatar: '/avatar-default.jpg',
  },
  {
    id: 'rc-13', name: 'Анна Павлова', specialization: 'Сборщик мебели', rating: 4.9, reviews: 36, region: 'Москва',
    phone: '+7 (900) 345-67-80', email: 'anna.furn@mail.ru', priceRange: '$',
    about: 'Сборка мебели любой сложности. Гардеробные, кухни, детские комнаты. Работаю быстро и аккуратно.',
    services: [{ name: 'Сборка мебели', price: 'от 1,500 ₽/ед' }, { name: 'Гардеробная', price: 'от 4,500 ₽' }, { name: 'Кухня', price: 'от 6,000 ₽' }],
    telegram: 'pavlova_furn', yearsExp: 5, projectsCount: 410, avatar: '/avatar-default.jpg',
  },
  {
    id: 'rc-14', name: 'Роман Фёдоров', specialization: 'Уборщик', rating: 4.4, reviews: 8, region: 'Москва',
    phone: '+7 (900) 456-78-91', email: 'roman.clean@mail.ru', priceRange: '$',
    about: 'Уборка после ремонта и строительства. Вывоз мусора, демонтажные работы, подготовка к сдаче.',
    services: [{ name: 'Уборка после ремонта', price: 'от 70 ₽/м²' }, { name: 'Вывоз мусора', price: 'от 3,000 ₽' }, { name: 'Мойка окон', price: 'от 250 ₽/м²' }],
    telegram: 'fedorov_clean', yearsExp: 4, projectsCount: 90, avatar: '/avatar-default.jpg',
  },
  {
    id: 'rc-15', name: 'Елена Макарова', specialization: 'Дизайнер', rating: 4.8, reviews: 22, region: 'Москва',
    phone: '+7 (900) 567-89-02', email: 'elena.design@mail.ru', priceRange: '$$$',
    about: 'Дизайн интерьера и ландшафтный дизайн. Экологичные материалы, авторская мебель, текстиль.',
    services: [{ name: 'Дизайн интерьера', price: 'от 9,000 ₽/м²' }, { name: 'Ландшафт', price: 'от 15,000 ₽/м²' }, { name: 'Текстильный дизайн', price: 'от 5,000 ₽' }],
    telegram: 'makaroova_design', yearsExp: 10, projectsCount: 85, avatar: '/avatar-default.jpg',
  },
  {
    id: 'rc-16', name: 'Павел Семёнов', specialization: 'Электрика', rating: 4.6, reviews: 17, region: 'Москва',
    phone: '+7 (900) 678-90-13', email: 'pavel.elec@mail.ru', priceRange: '$',
    about: 'Бюджетный электрик. Замена автоматов, розеток, люстр. Работаю в выходные. Без выходных.',
    services: [{ name: 'Замена автомата', price: '800 ₽' }, { name: 'Розетка', price: '400 ₽' }, { name: 'Люстра', price: '1,200 ₽' }],
    telegram: 'semenov_elec', yearsExp: 7, projectsCount: 180, avatar: '/avatar-default.jpg',
  },
];

export default function ContractorsPage() {
  const { showToast } = useToast();
  const { hasFeature } = useAuth();
  const isProPlus = hasFeature('contractorsPublish');

  const [all, setAll] = useState<(Contractor & { about?: string; services?: { name: string; price: string }[]; telegram?: string; yearsExp?: number; projectsCount?: number })[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [search, setSearch] = useState('');
  const [activeFilter, setActiveFilter] = useState('Все');
  const [modalOpen, setModalOpen] = useState(false);
  const [selected, setSelected] = useState<typeof all[0] | null>(null);
  const [savedIds, setSavedIds] = useState<string[]>([]);

  // Seed rich contractors on mount
  useEffect(() => {
    const seed = async () => {
      try {
        const existing = await contractors.list();
        const hasRich = existing.some(c => c.id.startsWith('rc-'));
        if (!hasRich) {
          const allStored = JSON.parse(localStorage.getItem('contractors') || '[]') as Contractor[];
          const enriched = [...RICH_CONTRACTORS, ...allStored];
          localStorage.setItem('contractors', JSON.stringify(enriched));
        }
      } catch { /* ignore */ }
    };
    seed();
  }, []);

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      setError(false);
      const specFilter = activeFilter === 'Все' ? undefined : activeFilter;
      const data = await contractors.list(specFilter ? { specialization: specFilter } : undefined);
      // Merge with rich data if available
      const stored = JSON.parse(localStorage.getItem('contractors') || '[]') as typeof all;
      const merged = data.map(d => {
        const rich = stored.find(s => s.id === d.id);
        return rich ? { ...d, ...rich } : d;
      });
      setAll(merged);
    } catch {
      setError(true);
    } finally {
      setLoading(false);
    }
  }, [activeFilter]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const filtered = useMemo(() => {
    let list = all;
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(c => c.name.toLowerCase().includes(q) || c.specialization.toLowerCase().includes(q));
    }
    return list;
  }, [all, search]);

  const handleSave = useCallback((id: string) => {
    setSavedIds(prev => {
      const next = prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id];
      if (!prev.includes(id)) {
        showToast('Подрядчик добавлен в проект', 'success');
      }
      return next;
    });
  }, [showToast]);

  const handleCall = useCallback((phone?: string) => {
    if (phone) window.location.href = `tel:${phone}`;
    else showToast('Телефон не указан', 'info');
  }, [showToast]);

  return (
    <div className="min-h-[100dvh] bg-background">
      <div className="max-w-[1000px] mx-auto px-4 py-6 md:py-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
        >
          <div className="flex items-start justify-between mb-1">
            <div>
              <h1 className="font-serif text-[24px] font-semibold text-text">Подрядчики</h1>
              <p className="text-sm text-muted mt-1">База проверенных мастеров</p>
            </div>
            {isProPlus ? (
              <button
                onClick={() => showToast('Функция в разработке', 'info')}
                className="hidden md:inline-flex items-center gap-1 text-sm font-medium text-[#8b9d83] hover:bg-[rgba(139,157,131,0.08)] px-3 py-2 rounded-lg transition-colors"
              >
                <Plus size={16} /> Стать подрядчиком
              </button>
            ) : (
              <span className="hidden md:inline-flex items-center gap-1 text-xs text-muted bg-[#e8ede5] px-3 py-1.5 rounded-lg">
                Доступно в PRO+
              </span>
            )}
          </div>
        </motion.div>

        {/* Search */}
        <div className="mt-5 mb-4 relative">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Найти по имени или специализации..."
            className="w-full border border-border rounded-xl pl-9 pr-4 py-3 text-sm focus:outline-none focus:border-[#8b9d83] focus:shadow-[0_0_0_3px_rgba(139,157,131,0.15)]"
          />
        </div>

        {/* Filter Chips */}
        <div className="flex gap-2 overflow-x-auto pb-2 mb-4 scrollbar-hide">
          {FILTERS.map(filter => (
            <button
              key={filter}
              onClick={() => setActiveFilter(filter)}
              className={`whitespace-nowrap px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                activeFilter === filter
                  ? 'bg-[#8b9d83] text-white'
                  : 'bg-[#e8ede5] text-[#5c6b55] hover:bg-[#d4d8d0]'
              }`}
            >
              {filter}
            </button>
          ))}
        </div>

        {/* Content */}
        {loading ? (
          <ContractorSkeleton count={6} />
        ) : error ? (
          <div className="text-center py-12">
            <AlertCircle className="mx-auto mb-3 text-[#c47d7d]" size={40} />
            <h3 className="font-medium text-text mb-1">Не удалось загрузить подрядчиков</h3>
            <button
              onClick={fetchData}
              className="mt-3 border border-[#8b9d83] text-[#1a1a1a] px-4 py-2 rounded-xl text-sm font-medium hover:bg-[#e8ede5] transition-colors"
            >
              Повторить
            </button>
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-12">
            <Users className="mx-auto mb-3 text-[#8b9d83]" size={40} />
            <h3 className="font-serif text-lg font-semibold text-text mb-2">Подрядчики не найдены</h3>
            <p className="text-sm text-muted mb-6 max-w-[320px] mx-auto">Попробуйте изменить фильтры или поисковый запрос</p>
            <button
              onClick={() => { setSearch(''); setActiveFilter('Все'); }}
              className="border border-[#8b9d83] text-[#1a1a1a] text-sm font-medium px-4 py-2 rounded-xl hover:bg-[#e8ede5] transition-colors"
            >
              Сбросить фильтры
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filtered.map((contractor, idx) => (
              <ContractorCard
                key={contractor.id}
                contractor={contractor}
                index={idx}
                onOpen={() => { setSelected(contractor); setModalOpen(true); }}
                onCall={() => handleCall(contractor.phone)}
                onSave={() => handleSave(contractor.id)}
                saved={savedIds.includes(contractor.id)}
              />
            ))}
          </div>
        )}
      </div>

      {/* Detail Modal */}
      <ContractorModal
        contractor={selected}
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        onHire={() => { if (selected?.phone) handleCall(selected.phone); }}
        onSave={() => { if (selected) handleSave(selected.id); }}
        saved={selected ? savedIds.includes(selected.id) : false}
      />
    </div>
  );
}
