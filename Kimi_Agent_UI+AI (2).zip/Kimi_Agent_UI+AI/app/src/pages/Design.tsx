import { useState, useEffect, useCallback } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowLeft,
  ArrowRight,
  Lock,
  Search,
  X,
  Check,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { styles as stylesApi, type Style } from '@/lib/api';

/* ------------------------------------------------------------------ */
/*  Design Page — Style selection with detail modal                   */
/* ------------------------------------------------------------------ */

const FREE_STYLE_LIMIT = 3;

const containerVariants = {
  hidden: {},
  show: {
    transition: {
      staggerChildren: 0.06,
    },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 24 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.35, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] },
  },
};

const modalOverlayVariants = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { duration: 0.25 } },
};

const modalSheetVariants = {
  hidden: { y: '100%' },
  show: {
    y: 0,
    transition: { duration: 0.35, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] },
  },
  exit: {
    y: '100%',
    transition: { duration: 0.3, ease: [0.4, 0, 1, 1] as [number, number, number, number] },
  },
};

const modalPanelVariants = {
  hidden: { x: '100%' },
  show: {
    x: 0,
    transition: { duration: 0.35, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] },
  },
  exit: {
    x: '100%',
    transition: { duration: 0.3, ease: [0.4, 0, 1, 1] as [number, number, number, number] },
  },
};

/* ------------------------------------------------------------------ */
/*  Helper: Style detail content (shared between mobile + desktop)    */
/* ------------------------------------------------------------------ */

function StyleDetailContent({
  style,
  onSelect,
}: {
  style: Style;
  onSelect: () => void;
}) {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  const longDescriptions: Record<string, string> = {
    scandinavian:
      'Скандинавский стиль — это сочетание минимализма и уюта. Он родился в Северной Европе, где долгие зимы требовали максимального использования естественного света.\n\nХарактерные черты: светлая палитра, натуральное дерево, текстиль из льна и хлопка, живые растения и много воздуха.',
    loft:
      'Лофт — стиль городских пространств, переоборудованных из промышленных зданий. Открытые коммуникации, кирпичные стены и бетонные полы создают атмосферу свободы.\n\nИдеально подходит для творческих личностей и больших помещений с высокими потолками.',
    minimalism:
      'Минимализм — искусство отсекать лишнее. Каждый предмет в интерьере имеет функцию. Чистые линии, монохромная палитра и качественные материалы.\n\nЭто стиль для тех, кто ценит порядок, тишину и пространство для мысли.',
    neoclassic:
      'Неоклассика — современная интерпретация величественной классики. Сохраняются пропорции и симметрия, но убирается излишняя помпезность.\n\nМолдинги, лепнина и паркет елочкой сочетаются с современной мебелью.',
    'modern-classic':
      'Современная классика — баланс между традициями и современностью. Тёплые деревянные поверхности, качественный текстиль и латунные акценты создают изысканную, но уютную атмосферу.\n\nПодходит для семейных интерьеров с вниманием к деталям.',
    japanese:
      'Японский стиль основан на философии wabi-sabi — принятии несовершенства и красоты времени. Натуральные материалы, асимметрия и связь с природой.\n\nБамбук, рисовая бумага, камень и минимум декора создают медитативное пространство.',
    artdeco:
      'Ар-деко — роскошь геометрии и контрастов. Родился в 1920-х и до сих пор ассоциируется с гламуром и уверенностью.\n\nМрамор, золото, бархат и зеркала в сочетании с чёткими линиями создают драматичные интерьеры.',
  };

  const similarStylesMap: Record<string, string[]> = {
    scandinavian: ['Минимализм', 'Современная классика'],
    loft: ['Индустриальный', 'Минимализм'],
    minimalism: ['Скандинавский', 'Японский'],
    neoclassic: ['Современная классика', 'Ар-деко'],
    'modern-classic': ['Неоклассика', 'Скандинавский'],
    japanese: ['Минимализм', 'Скандинавский'],
    artdeco: ['Неоклассика', 'Лофт'],
  };

  const referenceImages = [
    style.imageUrl,
    '/style-scandi.jpg',
    '/style-loft.jpg',
    '/style-minimal.jpg',
    '/style-neoclassic.jpg',
    '/style-modern-classic.jpg',
  ].slice(0, 6);

  const materialUsage: Record<string, string> = {
    'Светлый дуб': 'Паркет, мебель',
    Лен: 'Шторы, текстиль',
    'Белая краска': 'Стены, потолок',
    Кирпич: 'Акцентные стены',
    Бетон: 'Полы, столешницы',
    Сталь: 'Мебель, лестницы',
    Стекло: 'Перегородки, столы',
    'Белый мрамор': 'Столешницы, полы',
    Молдинги: 'Стены, потолок',
    Лепнина: 'Декор потолка',
    'Паркет елочкой': 'Пол',
    Паркет: 'Пол',
    Текстиль: 'Шторы, подушки',
    Латунь: 'Светильники, фурнитура',
    Бамбук: 'Мебель, аксессуары',
    'Рисовая бумага': 'Ширмы, абажуры',
    Камень: 'Акцентные стены',
    Мрамор: 'Столешницы, столы',
    Золото: 'Акценты, рамы',
    Бархат: 'Мебель, шторы',
    Зеркала: 'Декор, расширение пространства',
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto">
      {/* Hero */}
      <div className="relative h-[40vh] min-h-[240px] shrink-0 overflow-hidden">
        <img
          src={style.imageUrl}
          alt={style.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
        <h2 className="absolute bottom-6 left-6 right-6 font-serif text-[32px] font-semibold text-white leading-tight">
          {style.name}
        </h2>
      </div>

      {/* Content */}
      <div className="p-6 space-y-8">
        {/* Description */}
        <div className="space-y-4">
          {(longDescriptions[style.slug] ?? style.description)
            .split('\n')
            .map((p, i) => (
              <p key={i} className="font-sans text-[16px] text-[#1a1a1a] leading-[1.7]">
                {p}
              </p>
            ))}
        </div>

        {/* Materials */}
        <div>
          <h4 className="font-sans text-sm font-semibold text-[#1a1a1a] mb-3">
            Типичные материалы
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {style.materials.map((m, i) => (
              <motion.div
                key={m}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{
                  delay: 0.1 + i * 0.06,
                  duration: 0.3,
                  ease: [0.16, 1, 0.3, 1] as [number, number, number, number],
                }}
                className="flex items-center gap-3 bg-white border border-[#e0dbd4] rounded-xl p-3"
              >
                <div
                  className="w-10 h-10 rounded-full shrink-0"
                  style={{ backgroundColor: style.colors[i % style.colors.length] }}
                />
                <div>
                  <p className="font-sans text-sm font-medium text-[#1a1a1a]">{m}</p>
                  <p className="font-sans text-xs text-[#6b6b6b]">
                    {materialUsage[m] ?? 'Отделка'}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Color palette */}
        <div>
          <h4 className="font-sans text-sm font-semibold text-[#1a1a1a] mb-3">
            Цветовая палитра
          </h4>
          <div className="flex flex-wrap gap-4">
            {style.colors.map((c, i) => (
              <motion.div
                key={c}
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{
                  delay: 0.15 + i * 0.06,
                  duration: 0.3,
                  ease: [0.34, 1.56, 0.64, 1] as [number, number, number, number],
                }}
                className="flex flex-col items-center gap-1"
              >
                <div
                  className="w-12 h-12 rounded-full"
                  style={{ backgroundColor: c }}
                />
                <span className="font-sans text-[11px] text-[#6b6b6b] uppercase">
                  {c}
                </span>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Reference gallery */}
        <div>
          <h4 className="font-sans text-sm font-semibold text-[#1a1a1a] mb-3">
            Референсы
          </h4>
          <div className="flex gap-3 overflow-x-auto pb-2 -mx-6 px-6">
            {referenceImages.map((img, i) => (
              <motion.button
                key={i}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.05, duration: 0.3 }}
                onClick={() => setSelectedImage(img)}
                className="shrink-0 w-[160px] h-[120px] rounded-lg overflow-hidden"
              >
                <img
                  src={img}
                  alt={`Референс ${i + 1}`}
                  className="w-full h-full object-cover"
                />
              </motion.button>
            ))}
          </div>
        </div>

        {/* Similar styles */}
        <div>
          <h4 className="font-sans text-sm font-semibold text-[#1a1a1a] mb-3">
            Похожие стили
          </h4>
          <div className="flex flex-wrap gap-2">
            {(similarStylesMap[style.slug] ?? []).map((name) => (
              <span
                key={name}
                className="px-3 py-1.5 rounded-lg bg-[#e8ede5] text-[#5c6b55] font-sans text-xs font-medium"
              >
                {name}
              </span>
            ))}
          </div>
        </div>

        {/* CTA */}
        <button
          onClick={onSelect}
          className="w-full py-4 rounded-xl bg-[#8b9d83] text-white font-sans font-medium text-base transition-all duration-200 hover:bg-[#6b7a64] active:scale-[0.97]"
        >
          Выбрать этот стиль
        </button>

        <div className="h-6" />
      </div>

      {/* Lightbox */}
      <AnimatePresence>
        {selectedImage && (
          <motion.div
            className="fixed inset-0 z-[500] bg-black/80 flex items-center justify-center p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSelectedImage(null)}
          >
            <motion.img
              src={selectedImage}
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.9 }}
              className="max-w-full max-h-[80vh] rounded-xl object-contain"
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Style Card                                                          */
/* ------------------------------------------------------------------ */

function StyleCard({
  style,
  isLocked,
  isSelected,
  onOpen,
  onLockedTap,
}: {
  style: Style;
  isLocked: boolean;
  isSelected: boolean;
  onOpen: () => void;
  onLockedTap: () => void;
}) {
  const [swatchScales, setSwatchScales] = useState<number[]>(
    style.materials.map(() => 1)
  );

  const handleHoverStart = () => {
    if (isLocked) return;
    style.materials.forEach((_, i) => {
      setTimeout(() => {
        setSwatchScales((prev) => {
          const next = [...prev];
          next[i] = 1.1;
          return next;
        });
        setTimeout(() => {
          setSwatchScales((prev) => {
            const next = [...prev];
            next[i] = 1;
            return next;
          });
        }, 200);
      }, i * 100);
    });
  };

  return (
    <motion.div
      variants={cardVariants}
      whileHover={!isLocked ? { y: -4, boxShadow: '0 8px 24px rgb(0 0 0 / 0.08)' } : {}}
      whileTap={!isLocked ? { scale: 0.98 } : {}}
      onHoverStart={handleHoverStart}
      className="relative bg-white border border-[#e0dbd4] rounded-2xl overflow-hidden flex flex-col"
    >
      {/* Image */}
      <div className="relative h-[280px] md:h-[360px] overflow-hidden shrink-0">
        <motion.img
          src={style.imageUrl}
          alt={style.name}
          className="w-full h-full object-cover"
          whileHover={!isLocked ? { scale: 1.03 } : {}}
          transition={{ duration: 0.5 }}
        />
        {isSelected && (
          <div className="absolute top-3 right-3 w-8 h-8 rounded-full bg-[#8b9d83] flex items-center justify-center">
            <Check size={16} className="text-white" />
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-5 flex flex-col flex-1">
        <h3 className="font-serif text-[20px] font-medium text-[#1a1a1a] mb-1">
          {style.name}
        </h3>
        <p className="font-sans text-sm text-[#6b6b6b] line-clamp-2 mb-3">
          {style.description}
        </p>

        {/* Materials row */}
        <div className="flex items-center gap-2 mb-3">
          {style.materials.slice(0, 4).map((m, i) => (
            <div key={m} className="flex items-center gap-1.5">
              <motion.div
                className="w-5 h-5 rounded-full"
                style={{
                  backgroundColor: style.colors[i % style.colors.length],
                  scale: swatchScales[i],
                }}
                transition={{ duration: 0.2 }}
              />
              <span className="font-sans text-[11px] text-[#6b6b6b]">{m}</span>
            </div>
          ))}
        </div>

        {/* Badges */}
        <div className="flex flex-wrap gap-2 mb-4">
          <span className="px-2.5 py-1 rounded-lg bg-[#e8ede5] text-[#5c6b55] font-sans text-[11px] font-medium uppercase tracking-wide">
            Сложность: {style.complexity}
          </span>
          <span className="px-2.5 py-1 rounded-lg bg-[#efeae4] text-[#8a7038] font-sans text-[11px] font-medium uppercase tracking-wide">
            Бюджет: {style.budgetLevel}
          </span>
        </div>

        {/* CTA */}
        <div className="mt-auto flex items-center justify-end">
          {isLocked ? (
            <button
              onClick={onLockedTap}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#8b9d83] text-white font-sans text-sm font-medium transition-colors hover:bg-[#6b7a64]"
            >
              <Lock size={14} />
              Обновить до PRO
            </button>
          ) : (
            <button
              onClick={onOpen}
              className="flex items-center gap-1.5 font-sans text-sm font-medium text-[#8b9d83] px-3 py-2 rounded-lg hover:bg-[rgba(139,157,131,0.08)] transition-colors"
            >
              Подробнее
              <ArrowRight size={16} />
            </button>
          )}
        </div>
      </div>

      {/* Lock overlay */}
      {isLocked && (
        <div className="absolute inset-0 bg-[#f7f5f2]/85 flex flex-col items-center justify-center z-10 rounded-2xl">
          <Lock size={32} className="text-[#9a9a9a] mb-2" />
          <p className="font-sans text-sm font-medium text-[#6b6b6b]">
            Доступно в PRO
          </p>
        </div>
      )}
    </motion.div>
  );
}

/* ------------------------------------------------------------------ */
/*  Skeleton Card                                                       */
/* ------------------------------------------------------------------ */

function SkeletonCard() {
  return (
    <div className="bg-white border border-[#e0dbd4] rounded-2xl overflow-hidden flex flex-col">
      <div className="h-[280px] md:h-[360px] skeleton-shimmer" />
      <div className="p-5 space-y-3">
        <div className="h-5 w-2/3 skeleton-shimmer rounded" />
        <div className="h-4 w-full skeleton-shimmer rounded" />
        <div className="h-4 w-3/4 skeleton-shimmer rounded" />
        <div className="flex gap-2 pt-2">
          <div className="h-6 w-20 skeleton-shimmer rounded" />
          <div className="h-6 w-20 skeleton-shimmer rounded" />
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Main Design Page                                                    */
/* ------------------------------------------------------------------ */

export default function Design() {
  const navigate = useNavigate();
  const location = useLocation();
  const { hasFeature } = useAuth();
  const [styles, setStyles] = useState<Style[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedStyle, setSelectedStyle] = useState<Style | null>(null);
  const [activeStyleId, setActiveStyleId] = useState<string | null>(null);
  const [shakeCard, setShakeCard] = useState<number | null>(null);

  const fromOnboarding = location.state?.fromOnboarding ?? false;
  const canAccessAll = hasFeature('allStyles');

  useEffect(() => {
    stylesApi
      .list()
      .then((s) => {
        setStyles(s);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const filteredStyles = styles.filter((s) =>
    s.name.toLowerCase().includes(search.toLowerCase())
  );

  const handleLockedTap = useCallback(
    (index: number) => {
      setShakeCard(index);
      setTimeout(() => setShakeCard(null), 300);
    },
    []
  );

  const handleSelectStyle = (style: Style) => {
    setActiveStyleId(style.id);
    setSelectedStyle(null);
    // In a real app, you'd save to project here
  };

  return (<>
    <div className="min-h-[100dvh] bg-[#f7f5f2]">
        {/* Header */}
        <div className="px-4 md:px-8 pt-4 md:pt-6 pb-4 max-w-[1000px] mx-auto">
          <div className="flex items-center gap-3 mb-4">
            {fromOnboarding && (
              <button
                onClick={() => navigate(-1)}
                className="w-10 h-10 flex items-center justify-center rounded-xl hover:bg-[rgba(139,157,131,0.08)] transition-colors"
                aria-label="Назад"
              >
                <ArrowLeft size={20} className="text-[#1a1a1a]" />
              </button>
            )}
            <div className="flex-1">
              <h1 className="font-serif text-[24px] md:text-[28px] font-semibold text-[#1a1a1a]">
                Выберите стиль
              </h1>
              <p className="font-sans text-sm text-[#6b6b6b] mt-1">
                7 интерьерных стилей с референсами и материалами
              </p>
            </div>
          </div>

          {/* Search (desktop) */}
          <div className="hidden md:block relative mb-6">
            <Search
              size={18}
              className="absolute left-4 top-1/2 -translate-y-1/2 text-[#9a9a9a]"
            />
            <input
              type="text"
              placeholder="Найти стиль..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full max-w-sm pl-11 pr-4 py-3 rounded-xl border border-[#e0dbd4] bg-white font-sans text-base text-[#1a1a1a] placeholder:text-[#9a9a9a] focus:outline-none focus:border-[#8b9d83] focus:ring-[3px] focus:ring-[rgba(139,157,131,0.15)] transition-all"
            />
          </div>

          {/* Selected banner */}
          {activeStyleId && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-4 p-3 rounded-xl bg-[#e8ede5] border border-[#8b9d83] flex items-center justify-between"
            >
              <p className="font-sans text-sm font-medium text-[#5c6b55]">
                Текущий стиль проекта:{' '}
                <span className="font-semibold">
                  {styles.find((s) => s.id === activeStyleId)?.name}
                </span>
              </p>
              <button
                onClick={() => setActiveStyleId(null)}
                className="font-sans text-sm font-medium text-[#8b9d83] hover:underline"
              >
                Изменить
              </button>
            </motion.div>
          )}
        </div>

        {/* Grid */}
        <div className="px-4 md:px-8 pb-24 max-w-[1000px] mx-auto">
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[0, 1, 2].map((i) => (
                <SkeletonCard key={i} />
              ))}
            </div>
          ) : (
            <motion.div
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
              variants={containerVariants}
              initial="hidden"
              animate="show"
            >
              {filteredStyles.map((style, i) => {
                const isLocked = !canAccessAll && i >= FREE_STYLE_LIMIT;
                return (
                  <motion.div
                    key={style.id}
                    animate={
                      shakeCard === i
                        ? {
                            rotate: [0, 3, -3, 3, 0],
                            transition: { duration: 0.3 },
                          }
                        : {}
                    }
                  >
                    <StyleCard
                      style={style}
                      isLocked={isLocked}
                      isSelected={activeStyleId === style.id}
                      onOpen={() => setSelectedStyle(style)}
                      onLockedTap={() => handleLockedTap(i)}
                    />
                  </motion.div>
                );
              })}
            </motion.div>
          )}
        </div>
      </div>

      {/* Detail Modal / Sheet */}
      <AnimatePresence>
        {selectedStyle && (
          <>
            {/* Overlay */}
            <motion.div
              className="fixed inset-0 z-[300] bg-[rgba(26,26,26,0.4)] backdrop-blur-sm"
              variants={modalOverlayVariants}
              initial="hidden"
              animate="show"
              exit="hidden"
              onClick={() => setSelectedStyle(null)}
            />

            {/* Mobile: bottom sheet */}
            <div className="md:hidden fixed inset-x-0 bottom-0 z-[400] h-[85vh] bg-white rounded-t-[24px] overflow-hidden flex flex-col">
              <div className="flex items-center justify-center pt-3 pb-1">
                <div className="w-10 h-1 rounded-full bg-[#d4d0c9]" />
              </div>
              <button
                onClick={() => setSelectedStyle(null)}
                className="absolute top-3 right-4 w-8 h-8 flex items-center justify-center rounded-full bg-black/20 z-10"
              >
                <X size={16} className="text-white" />
              </button>
              <motion.div
                className="flex-1 overflow-hidden"
                variants={modalSheetVariants}
                initial="hidden"
                animate="show"
                exit="exit"
              >
                <StyleDetailContent
                  style={selectedStyle}
                  onSelect={() => handleSelectStyle(selectedStyle)}
                />
              </motion.div>
            </div>

            {/* Desktop: side panel */}
            <motion.div
              className="hidden md:flex fixed right-0 top-0 bottom-0 z-[400] w-1/2 max-w-[600px] bg-white shadow-xl flex-col"
              variants={modalPanelVariants}
              initial="hidden"
              animate="show"
              exit="exit"
            >
              <div className="flex items-center justify-between px-6 py-4 border-b border-[#e0dbd4] shrink-0">
                <h3 className="font-serif text-lg font-semibold text-[#1a1a1a]">
                  {selectedStyle.name}
                </h3>
                <button
                  onClick={() => setSelectedStyle(null)}
                  className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-[#f7f5f2] transition-colors"
                >
                  <X size={18} className="text-[#6b6b6b]" />
                </button>
              </div>
              <div className="flex-1 overflow-hidden">
                <StyleDetailContent
                  style={selectedStyle}
                  onSelect={() => handleSelectStyle(selectedStyle)}
                />
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
