import { useRef, useState, useEffect, useCallback } from 'react';
import { motion, useInView, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import {
  MessageCircle,
  Palette,
  ListChecks,
  CalendarCheck,
  Check,
  X,
  ArrowRight,
  Sofa,
  Lightbulb,
  Home as HomeIcon,
  Sparkles,
} from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';

const easeEnter: [number, number, number, number] = [0.16, 1, 0.3, 1];
const easeSmooth: [number, number, number, number] = [0.4, 0, 0.2, 1];

const projects = [
  {
    name: 'ЖК Уютный',
    image: '/proj-kitchen1.jpg',
    specs: ['38 м²', 'Современная классика', 'Завершён'],
    description: 'Реальный проект в Минске. Продуманная планировка, современная классика с тёплыми деревянными поверхностями и латунными акцентами. Ремонт завершён за 3 месяца.',
  },
];

const steps = [
  { icon: MessageCircle, title: 'Ответьте на 5 вопросов', desc: 'Бюджет, стиль, площадь — и AI поймет, что вам нужно' },
  { icon: Palette, title: 'Выберите стиль', desc: '7 интерьеров с референсами и материалами' },
  { icon: ListChecks, title: 'Получите план', desc: '10 этапов ремонта с чек-листами и сроками' },
  { icon: CalendarCheck, title: 'Знайте, что делать сегодня', desc: 'Каждый день — чёткая задача. Не думайте — делайте' },
];

const plans = [
  {
    name: 'FREE',
    price: 'Бесплатно',
    features: [
      { text: '1 проект', available: true },
      { text: '3 стиля', available: true },
      { text: 'AI Import', available: false },
      { text: 'Telegram Bot', available: false },
      { text: 'База подрядчиков', available: true, limited: true },
    ],
    cta: 'Начать',
    highlighted: false,
    badge: '',
  },
  {
    name: 'PRO',
    price: '$9.99/мес',
    features: [
      { text: 'Безлимит проектов', available: true },
      { text: '7 стилей', available: true },
      { text: 'AI Import', available: true },
      { text: 'Telegram Bot', available: true },
      { text: 'База подрядчиков', available: true },
    ],
    cta: 'Выбрать',
    highlighted: true,
    badge: 'Популярный',
  },
  {
    name: 'PRO+',
    price: '$29.99/мес',
    features: [
      { text: 'Безлимит проектов', available: true },
      { text: '7 стилей', available: true },
      { text: 'AI Import', available: true },
      { text: 'Telegram Bot', available: true },
      { text: 'База + публикация', available: true },
    ],
    cta: 'Выбрать',
    highlighted: false,
    badge: 'Максимум',
  },
];


/* ── Project Carousel Card with auto-sliding ── */
const CAROUSEL_IMAGES = [
  '/proj-kitchen1.jpg',
  '/proj-living.jpg',
  '/proj-bedroom1.jpg',
  '/proj-bedroom3.jpg',
  '/proj-bath.jpg',
];

function ProjectCarouselCard({
  project,
  index,
  navigate,
}: {
  project: typeof projects[0];
  index: number;
  navigate: (path: string) => void;
}) {
  const [current, setCurrent] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  const next = useCallback(() => {
    setCurrent((prev) => (prev + 1) % CAROUSEL_IMAGES.length);
  }, []);

  useEffect(() => {
    if (isPaused) return;
    const timer = setInterval(next, 3000);
    return () => clearInterval(timer);
  }, [isPaused, next]);

  return (
    <motion.div
      className="bg-white rounded-2xl border border-border overflow-hidden cursor-pointer group"
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, delay: index * 0.06, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
      whileHover={{ y: -4 }}
      onClick={() => navigate('/demo-project')}
    >
      {/* Image carousel — crossfade without white flash */}
      <div
        className="relative h-[300px] md:h-[380px] overflow-hidden bg-[#f0ebe4]"
        onMouseEnter={() => setIsPaused(true)}
        onMouseLeave={() => setIsPaused(false)}
      >
        {/* All images stacked, CSS crossfade — no motion.img to avoid re-renders */}
        {CAROUSEL_IMAGES.map((src, i) => (
          <img
            key={src}
            src={src}
            alt={`${project.name} — фото ${i + 1}`}
            className="absolute inset-0 w-full h-full object-cover"
            style={{
              opacity: i === current ? 1 : 0,
              transform: i === current ? 'scale(1)' : 'scale(1.06)',
              transition: 'opacity 0.8s cubic-bezier(0.16, 1, 0.3, 1), transform 0.8s cubic-bezier(0.16, 1, 0.3, 1)',
              willChange: 'opacity, transform',
            }}
          />
        ))}

        {/* Progress bars at bottom */}
        <div className="absolute bottom-3 left-3 right-3 flex gap-1 z-10">
          {CAROUSEL_IMAGES.map((_, i) => (
            <div
              key={i}
              className="h-[3px] flex-1 rounded-full overflow-hidden"
              style={{ backgroundColor: 'rgba(255,255,255,0.35)' }}
            >
              {i === current && !isPaused ? (
                <motion.div
                  key={`progress-${current}`}
                  className="h-full rounded-full bg-white"
                  initial={{ width: '0%' }}
                  animate={{ width: '100%' }}
                  transition={{ duration: 3, ease: 'linear' }}
                />
              ) : (
                <div
                  className="h-full rounded-full bg-white"
                  style={{ width: i < current ? '100%' : '0%' }}
                />
              )}
            </div>
          ))}
        </div>

        {/* Gradient overlay at bottom for bar visibility */}
        <div className="absolute bottom-0 left-0 right-0 h-12 bg-gradient-to-t from-black/30 to-transparent pointer-events-none" />
      </div>

      {/* Content */}
      <div className="p-5">
        <h3 className="font-serif text-[20px] font-medium text-text mb-2">
          {project.name}
        </h3>
        <div className="flex flex-wrap gap-2 mb-3">
          {project.specs.map((spec) => (
            <span
              key={spec}
              className="bg-olive-100 text-olive-700 text-[11px] font-medium uppercase tracking-wider px-3 py-1.5 rounded-lg"
            >
              {spec}
            </span>
          ))}
        </div>
        <p className="text-sm text-muted leading-relaxed line-clamp-3 mb-4">
          {project.description}
        </p>
        <button
          onClick={(e) => {
            e.stopPropagation();
            navigate('/demo-project');
          }}
          className="bg-accent text-white font-medium px-4 py-2 rounded-xl hover:bg-olive-600 transition-all duration-200 active:scale-[0.97] text-sm"
        >
          Открыть проект
        </button>
      </div>
    </motion.div>
  );
}

function SectionObserver({ children, className }: { children: React.ReactNode; className?: string }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.15 });
  return (
    <div ref={ref} className={className}>
      {isInView ? children : <div className="opacity-0">{children}</div>}
    </div>
  );
}


/* ═══════════════════════════════════════════════════════════════════ */
/*  InteractiveStyles — inline style gallery with detail modal       */
/* ═══════════════════════════════════════════════════════════════════ */

interface StyleData {
  name: string;
  slug: string;
  image: string;
  references: string[];
  description: string;
  fullDescription: string;
  materials: string[];
  materialUsage: Record<string, string>;
  colors: string[];
  complexity: string;
  budget: string;
  furniture: string[];
  idealRooms: string[];
  tips: string;
  similarStyles: string[];
  moodboard: {
    textures: { src: string; label: string }[];
  };
}

const STYLE_DATA: StyleData[] = [
  {
    name: 'Скандинавский',
    slug: 'scandinavian',
    image: '/style-scandi.jpg',
    references: ['/ref-scandi-living.jpg', '/ref-scandi-bedroom.jpg', '/ref-scandi-kitchen.jpg'],
    description: 'Светлый, уютный, минимализм, дерево. Идеально для небольших квартир и семей с детьми.',
    fullDescription: 'Скандинавский стиль родился в Северной Европе, где долгие зимы и недостаток солнечного света требовали максимальной светлости и уюта в интерьерах.\n\nКлючевые принципы: функциональность, простота форм, натуральные материалы и обилие света. Белые стены и потолки отражают дневной свет, а деревянные полы и мебель из светлого дуба добавляют теплоты.\n\nТекстиль играет важную роль — льняные шторы, хлопковые пледы и меховые покрывала создают ощущение защищённости. Живые растения и минималистичный декор завершают композицию.',
    materials: ['Светлый дуб', 'Лен', 'Белая краска', 'Шерсть', 'Керамика'],
    materialUsage: { 'Светлый дуб': 'Паркет, мебель, столешницы', 'Лен': 'Шторы, постельное бельё, пледы', 'Белая краска': 'Стены, потолок, мебель', 'Шерсть': 'Ковры, пледы, подушки', 'Керамика': 'Посуда, вазы, светильники' },
    colors: ['#F5F5F0', '#D4C5A9', '#8B9D83', '#E8E0D5', '#FFFFFF'],
    complexity: 'Низкая',
    budget: 'Средний',
    furniture: ['Диван в светлой обивке', 'Деревянный обеденный стол', 'Кресло с подлокотниками из дуба', 'Кровать с изголовьем из дерева', 'Открытые полки из светлого дерева', 'Плетёный комод'],
    idealRooms: ['Гостиная', 'Спальня', 'Детская', 'Кухня'],
    tips: 'Используйте максимум естественного света — не закрывайте окна тяжёлыми шторами. Достаточно лёгких льняных занавесок.',
    similarStyles: ['Минимализм', 'Современная классика'],
    moodboard: {
      textures: [
        { src: '/texture-scandi-wood.jpg', label: 'Дуб белёный' },
        { src: '/japandi-texture-linen.jpg', label: 'Лён' },
        { src: '/japandi-texture-stone.jpg', label: 'Керамика' },
        { src: '/japandi-texture-rattan.jpg', label: 'Плетение' },
      ],
    },
  },
  {
    name: 'Лофт',
    slug: 'loft',
    image: '/style-loft.jpg',
    references: ['/ref-loft-living.jpg', '/ref-loft-bedroom.jpg', '/ref-loft-kitchen.jpg'],
    description: 'Кирпич, бетон, металл, открытые коммуникации. Для смелых и творческих личностей.',
    fullDescription: 'Лофт — стиль городских пространств, переоборудованных из бывших промышленных зданий: фабрик, складов и мастерских. Его родина — Нью-Йорк 1950-х, где художники заселяли заброшенные производственные помещения.\n\nОтличительные черты: открытая планировка, высокие потолки, кирпичные стены, бетонные полы и открытые инженерные коммуникации — воздуховоды, трубы, балки.\n\nМебель сочетает индустриальные материалы (сталь, кованое железо, старое дерево) с современным комфортом. Акцентные светильники-споты и торшеры с металлическими плафонами создают драматическую атмосферу.',
    materials: ['Кирпич', 'Бетон', 'Сталь', 'Стекло', 'Винтажное дерево'],
    materialUsage: { 'Кирпич': 'Акцентные стены, перегородки', 'Бетон': 'Полы, столешницы, стены', 'Сталь': 'Лестницы, мебель, каркасы', 'Стекло': 'Перегородки, столы, двери', 'Винтажное дерево': 'Мебель, столешницы, полы' },
    colors: ['#8B4513', '#808080', '#2C2C2C', '#D4AF37', '#FFFFFF'],
    complexity: 'Средняя',
    budget: 'Средний',
    furniture: ['Кожаный диван Chesterfield', 'Стол со столешницей из массива', 'Металлический стеллаж', 'Барные стулья с металлическим каркасом', 'Кровать с металлическим каркасом', 'Тумба из старого дерева на колёсиках'],
    idealRooms: ['Гостиная-студия', 'Кабинет', 'Спальня', 'Кухня'],
    tips: 'Не перегружайте пространство мебелью — лофт ценит воздух и масштаб. Один акцентный кожаный диван лучше, чем три маленьких.',
    similarStyles: ['Индустриальный', 'Минимализм'],
    moodboard: {
      textures: [
        { src: '/texture-loft-brick.jpg', label: 'Кирпич' },
        { src: '/japandi-texture-oak.jpg', label: 'Винтажное дерево' },
        { src: '/japandi-texture-stone.jpg', label: 'Бетон' },
        { src: '/texture-artdeco-marble.jpg', label: 'Сталь' },
      ],
    },
  },
  {
    name: 'Минимализм',
    slug: 'minimalism',
    image: '/style-minimal.jpg',
    references: ['/ref-minimal-living.jpg', '/ref-minimal-bedroom.jpg', '/ref-minimal-kitchen.jpg'],
    description: 'Чистота линий, отсутствие декора, функциональность. Каждая деталь имеет смысл.',
    fullDescription: 'Минимализм — это искусство отсекать всё лишнее, оставляя только необходимое. Стиль возник в 1960-х как ответ на перенасыщенность постиндустриального общества.\n\nКаждый предмет в минималистичном интерьере имеет функцию. Никакого декора ради декора — только чистые линии, геометрические формы и продуманные до миллиметра пропорции.\n\nЦветовая палитра монохромная: белый, серый, чёрный с редкими акцентами. Материалы — стекло, бетон, белый мрамор, матовый металл. Скрытая система хранения позволяет поддерживать идеальный порядок.',
    materials: ['Бетон', 'Стекло', 'Белый мрамор', 'Матовый металл', 'Лаконичный текстиль'],
    materialUsage: { 'Бетон': 'Полы, стены, столешницы', 'Стекло': 'Перегородки, столы, полки', 'Белый мрамор': 'Столешницы, ванные комнаты', 'Матовый металл': 'Светильники, фурнитура', 'Лаконичный текстиль': 'Шторы, обивка' },
    colors: ['#FFFFFF', '#F0F0F0', '#E0E0E0', '#333333', '#000000'],
    complexity: 'Низкая',
    budget: 'Низкий',
    furniture: ['Модульный диван прямых линий', 'Стеклянный журнальный столик', 'Встроенный шкаф без ручек', 'Кровать на низкой платформе', 'Плавающая консоль', 'Складной обеденный стол'],
    idealRooms: ['Гостиная', 'Спальня', 'Кухня', 'Ванная'],
    tips: 'Инвестируйте в качественные материалы — в минимализме нет декора, который мог бы скрыть дешёвую отделку. Каждая деталь на виду.',
    similarStyles: ['Скандинавский', 'Японский'],
    moodboard: {
      textures: [
        { src: '/texture-minimal-marble.jpg', label: 'Мрамор' },
        { src: '/japandi-texture-oak.jpg', label: 'Бетон' },
        { src: '/japandi-texture-stone.jpg', label: 'Камень' },
        { src: '/japandi-texture-rattan.jpg', label: 'Стекло' },
      ],
    },
  },
  {
    name: 'Неоклассика',
    slug: 'neoclassic',
    image: '/style-neoclassic.jpg',
    references: ['/ref-neoclassic-living.jpg', '/ref-neoclassic-bedroom.jpg', '/ref-neoclassic-kitchen.jpg'],
    description: 'Современная интерпретация классики. Молдинги, лепнина, паркет елочкой.',
    fullDescription: 'Неоклассика — это современный взгляд на величественную классику. Стиль сохраняет пропорции, симметрию и респектабельность, но отказывается от излишней помпезности и золотого изобилия традиционного классицизма.\n\nХарактерные элементы: стеновые молдинги, лепнина на потолке, паркетная доска уложенная ёлочкой, камины с изысканными обрамлениями. Колонны и пилястры могут использоваться как декоративные акценты.\n\nМебель — с изогнутыми ножками, обивкой из бархата или льна, с тонкой фрезеровкой. Люстры с хрустальными подвесками и бра с тканевыми абажурами создают многоуровневое освещение.',
    materials: ['Молдинги', 'Лепнина', 'Паркет елочкой', 'Бархат', 'Мрамор'],
    materialUsage: { 'Молдинги': 'Стены, потолок, дверные проёмы', 'Лепнина': 'Потолок, карнизы, розетки', 'Паркет елочкой': 'Пол в гостиной и спальне', 'Бархат': 'Мебель, шторы, подушки', 'Мрамор': 'Камин, столешницы' },
    colors: ['#F5F0E8', '#C9B896', '#8B7355', '#FFFFFF', '#D4C5A9'],
    complexity: 'Высокая',
    budget: 'Высокий',
    furniture: ['Диван с резными ножками', 'Кресло с бархатной обивкой', 'Столик с мраморной столешницей', 'Кровать с мягким изголовьем', 'Комод с фрезеровкой', 'Консоль с зеркалом'],
    idealRooms: ['Гостиная', 'Спальня', 'Кабинет', 'Прихожая'],
    tips: 'Соблюдайте симметрию — она ключевая в неоклассике. Если ставите кресло слева от камина, справа должно быть точно такое же.',
    similarStyles: ['Современная классика', 'Ар-деко'],
    moodboard: {
      textures: [
        { src: '/texture-neo-gold.jpg', label: 'Позолота' },
        { src: '/texture-modern-parquet.jpg', label: 'Паркет' },
        { src: '/japandi-texture-stone.jpg', label: 'Мрамор' },
        { src: '/japandi-texture-linen.jpg', label: 'Бархат' },
      ],
    },
  },
  {
    name: 'Современная классика',
    slug: 'modern-classic',
    image: '/style-modern-classic.jpg',
    references: ['/ref-modernclassic-living.jpg', '/ref-modernclassic-bedroom.jpg', '/ref-modernclassic-kitchen.jpg'],
    description: 'Баланс традиций и современности. Паркет, текстиль, латунь.',
    fullDescription: 'Современная классика — это дипломатичный компромисс между вечными ценностями и актуальными трендами. Стиль берёт лучшее из классики (качественные материалы, продуманные пропорции) и добавляет современную функциональность и комфорт.\n\nИнтерьер строится на сочетании тёплых деревянных поверхностей, качественного текстиля и металлических акцентов из латуни или бронзы. Цветовая палитра мягкая и тёплая — кремовые, песочные, оливковые оттенки.\n\nМебель сочетает классические силуэты с современными материалами. Например, диван с традиционной формой, но в современной ткани. Латунные светильники, рамы зеркал и фурнитура добавят изысканности.',
    materials: ['Паркет', 'Текстиль', 'Латунь', 'Стекло', 'Обои под ткань'],
    materialUsage: { 'Паркет': 'Полы во всех комнатах', 'Текстиль': 'Шторы, обивка, ковры', 'Латунь': 'Светильники, рамы, фурнитура', 'Стекло': 'Столы, перегородки', 'Обои под ткань': 'Акцентные стены' },
    colors: ['#F0EBE0', '#B8A88A', '#6B7B5E', '#FFFFFF', '#D4C5A9'],
    complexity: 'Средняя',
    budget: 'Средний',
    furniture: ['Диван в нейтральной обивке', 'Кожаное кресло', 'Стол из тёмного дерева', 'Кровать с мягким изголовьем', 'Буфет со стеклянными дверцами', 'Пуф с латунными ножками'],
    idealRooms: ['Гостиная', 'Спальня', 'Кухня-гостиная', 'Кабинет'],
    tips: 'Миксуйте эпохи — антикварное кресло отлично смотрится рядом с современным диваном, если объединяет их цветовая палитра.',
    similarStyles: ['Неоклассика', 'Скандинавский'],
    moodboard: {
      textures: [
        { src: '/texture-modern-parquet.jpg', label: 'Паркет' },
        { src: '/japandi-texture-linen.jpg', label: 'Текстиль' },
        { src: '/japandi-texture-oak.jpg', label: 'Дуб' },
        { src: '/texture-neo-gold.jpg', label: 'Латунь' },
      ],
    },
  },
  {
    name: 'Японский',
    slug: 'japanese',
    image: '/style-japanese.jpg',
    references: ['/ref-japanese-living.jpg', '/ref-japanese-bedroom.jpg', '/ref-japanese-bath.jpg'],
    description: 'Wabi-sabi, натуральность, асимметрия. Бамбук, рисовая бумага, камень.',
    fullDescription: 'Японский стиль основан на философии wabi-sabi — принятии несовершенства и естественного цикла вещей. Интерьер стремится к спокойствию, умиротворённости и гармонии с природой.\n\nПространство минималистично, но не холодно. Используются натуральные материалы: бамбук, рисовая бумага, натуральный камень, необработанное дерево. Татами как элемент пола или в качестве эталона пропорций.\n\nАсимметрия композиции — важный принцип. Вместо парных предметов используются группы трёх или пяти. Сёдзи (раздвижные перегородки из рисовой бумаги) мягко рассеивают свет и позволяют трансформировать пространство.',
    materials: ['Бамбук', 'Рисовая бумага', 'Камень', 'Татами', 'Кедр'],
    materialUsage: { 'Бамбук': 'Мебель, жалюзи, декор', 'Рисовая бумага': 'Ширмы, абажуры, перегородки', 'Камень': 'Акцентные стены, садики', 'Татами': 'Пол в традиционных зонах', 'Кедр': 'Ванные комнаты, сауны' },
    colors: ['#E8E0D0', '#C4B59E', '#8B9D83', '#F5F0E8', '#A09080'],
    complexity: 'Средняя',
    budget: 'Средний',
    furniture: ['Низкий стол на подушках', 'Футон (японская кровать)', 'Ширма-перегородка', 'Тумбочка из тёмного дерева', 'Лаконичная вешалка из бамбука', 'Плетёная корзина для хранения'],
    idealRooms: ['Спальня', 'Гостиная', 'Чайная комната', 'Ванная'],
    tips: 'Создайте «ма» — пустое пространство между предметами. В японском интерьере тишина и пауза важнее, чем наполненность.',
    similarStyles: ['Минимализм', 'Скандинавский'],
    moodboard: {
      textures: [
        { src: '/texture-japan-bamboo.jpg', label: 'Бамбук' },
        { src: '/japandi-texture-linen.jpg', label: 'Рисовая бумага' },
        { src: '/japandi-texture-stone.jpg', label: 'Камень' },
        { src: '/texture-scandi-wood.jpg', label: 'Кедр' },
      ],
    },
  },
  {
    name: 'Ар-деко',
    slug: 'artdeco',
    image: '/style-artdeco.jpg',
    references: ['/ref-artdeco-living.jpg', '/ref-artdeco-bedroom.jpg', '/ref-artdeco-bath.jpg'],
    description: 'Геометрия, роскошь, контрасты. Мрамор, золото, бархат, зеркала.',
    fullDescription: 'Ар-деко — стиль роскоши и уверенности, родившийся в 1920-х годах в Париже. Он сочетает современную геометрию с драгоценными материалами и создаёт интерьеры с характером и драматизмом.\n\nХарактерные черты: чёткие геометрические формы, зигзаги, солнечные лучи, ступенчатые силуэты. Контрастные сочетания — чёрный с золотым, изумрудный с латунью, тёмное дерево с мрамором.\n\nМатериалы премиальные: мрамор, золото, латунь, бархат, экзотические породы дерева. Зеркала в рамах с геометрическим орнаментом визуально расширяют пространство. Люстры-хрусталики и бра с тяжёлыми абажурами создают театральное освещение.',
    materials: ['Мрамор', 'Золото', 'Бархат', 'Зеркала', 'Эбеновое дерево'],
    materialUsage: { 'Мрамор': 'Столешницы, полы, камины', 'Золото': 'Акценты, рамы, фурнитура', 'Бархат': 'Мебель, шторы, подушки', 'Зеркала': 'Декор, расширение пространства', 'Эбеновое дерево': 'Мебель, панели, полы' },
    colors: ['#1A1A2E', '#C9A961', '#8B4513', '#FFFFFF', '#2C1810'],
    complexity: 'Высокая',
    budget: 'Высокий',
    furniture: ['Диван с бархатной обивкой', 'Кресло с геометрическим узором', 'Стол с мраморной столешницей', 'Трельяж с тройным зеркалом', 'Комод с латунными ручками', 'Кровать с мягким изголовьем'],
    idealRooms: ['Гостиная', 'Спальня', 'Кабинет', 'Ванная'],
    tips: 'Не бойтесь контрастов. Ар-деко — это театр. Чёрная стена с золотой рамой, изумрудный бархат с латунью — это работает.',
    similarStyles: ['Неоклассика', 'Лофт'],
    moodboard: {
      textures: [
        { src: '/texture-artdeco-marble.jpg', label: 'Мрамор' },
        { src: '/texture-neo-gold.jpg', label: 'Золото' },
        { src: '/japandi-texture-linen.jpg', label: 'Бархат' },
        { src: '/japandi-texture-oak.jpg', label: 'Эбеновое дерево' },
      ],
    },
  },
  {
    name: 'Japandi',
    slug: 'japandi',
    image: '/style-japandi.jpg',
    description: 'Гибрид японского и скандинавского, простота, натуральные материалы, умиротворённый баланс.',
    fullDescription: 'Japandi — это тихий разговор между двумя культурами. Скандинавский хюгге встречает японское ваби-саби, и вместе они создают пространство, где нет места лишнему.\n\nКлючевые принципы: натуральные материалы, тёплая нейтральная палитра, функциональная простота и почтительное отношение к несовершенству. Каждый предмет здесь имеет смысл — никакого декора ради декора.\n\nЦветовая гамма строится на природных оттенках: ivory, beige, taupe, stone, warm grey. Дерево светлого дуба, лён, травертин, ротанг и керамика — основные материалы. Интерьер дышит, и в этом его сила.',
    materials: ['Дуб светлый', 'Лён', 'Травертин', 'Ротанг', 'Керамика'],
    materialUsage: { 'Дуб светлый': 'Полы, мебель, столешницы', 'Лён': 'Шторы, обивка, постель', 'Травертин': 'Столешницы, акценты, вазы', 'Ротанг': 'Светильники, кресла, декор', 'Керамика': 'Посуда, вазы, плитка' },
    colors: ['#F5F0E8', '#D4C5A9', '#A89880', '#E8E0D0', '#8B9D83'],
    complexity: 'Низкая',
    budget: 'Средний',
    furniture: ['Диван в льняной обивке', 'Кресло из ротанга', 'Стол из дуба', 'Кровать на низкой платформе', 'Консоль из травертина', 'Плетёный комод'],
    idealRooms: ['Гостиная', 'Спальня', 'Кухня', 'Ванная'],
    tips: 'Используйте много текстур, но в одной цветовой гамме. Japandi — это про тактильность, а не про цветовые контрасты.',
    similarStyles: ['Скандинавский', 'Японский', 'Минимализм'],
    references: ['/ref-japandi-living.jpg', '/ref-japandi-bedroom.jpg', '/ref-japandi-kitchen.jpg'],
    moodboard: {
      textures: [
        { src: '/japandi-texture-linen.jpg', label: 'Лён' },
        { src: '/japandi-texture-oak.jpg', label: 'Дуб' },
        { src: '/japandi-texture-stone.jpg', label: 'Травертин' },
        { src: '/japandi-texture-rattan.jpg', label: 'Ротанг' },
      ],
    },
  },
];

function getRoomLabel(path: string): string {
  if (path.includes('living')) return 'Гостиная';
  if (path.includes('bedroom')) return 'Спальня';
  if (path.includes('kitchen')) return 'Кухня';
  if (path.includes('bath')) return 'Ванная';
  return 'Интерьер';
}

function StyleModalContent({ style, onClose }: { style: StyleData; onClose: () => void }) {
  const [lightboxImage, setLightboxImage] = useState<string | null>(null);

  return (
    <>
      {/* Hero image */}
      <div className="relative h-[240px] md:h-[280px] shrink-0">
        <img
          src={style.image}
          alt={style.name}
          className="w-full h-full object-cover cursor-pointer"
          onClick={() => setLightboxImage(style.image)}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
        <div className="absolute bottom-0 left-0 p-6">
          <h2 className="font-serif text-[32px] font-semibold text-white">{style.name}</h2>
          <p className="text-white/80 text-sm mt-1">{style.complexity} сложность · {style.budget} бюджет</p>
        </div>
        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-10 h-10 flex items-center justify-center rounded-full bg-white/90 text-[#1a1a1a] hover:bg-white transition-colors"
        >
          <X size={20} />
        </button>
      </div>

      {/* Scrollable content */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-6 space-y-8">
          {/* Full description */}
          <div className="space-y-3">
            {style.fullDescription.split('\n\n').map((paragraph, i) => (
              <p key={i} className="text-[#1a1a1a] text-[15px] leading-relaxed">{paragraph}</p>
            ))}
          </div>

          {/* Moodboard */}
          <div>
            <div className="mb-3">
              <h4 className="text-sm font-medium text-[#6b6b6b]">Мудборд</h4>
              <p className="text-xs text-[#9a9a9a] mt-0.5">3 интерьера в этом стиле</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {style.references.map((path, idx) => (
                <button
                  key={idx}
                  onClick={() => setLightboxImage(path)}
                  className="text-left rounded-xl overflow-hidden group bg-[#f7f5f2]"
                >
                  <div className="h-[180px] overflow-hidden">
                    <img
                      src={path}
                      alt={getRoomLabel(path)}
                      loading="lazy"
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                  </div>
                  <p className="text-sm font-medium text-[#1a1a1a] px-3 py-2.5">{getRoomLabel(path)}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Textures */}
          <div className="mb-6">
            <h4 className="text-xs font-medium uppercase tracking-wider text-muted mb-3">
              Текстуры и материалы
            </h4>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {style.moodboard.textures.map((tex, i) => (
                <button
                  key={i}
                  onClick={() => setLightboxImage(tex.src)}
                  className="group relative aspect-square rounded-xl overflow-hidden border border-border bg-[#f0ebe4]"
                >
                  <img
                    src={tex.src}
                    alt={tex.label}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    loading="lazy"
                  />
                  <span className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent px-3 py-2 text-xs text-white font-medium text-left">
                    {tex.label}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Color palette */}
          <div>
            <h4 className="text-sm font-medium text-[#6b6b6b] mb-3">Цветовая палитра</h4>
            <div className="flex gap-3 flex-wrap">
              {style.colors.map((color) => (
                <div key={color} className="flex flex-col items-center gap-1.5">
                  <div className="w-12 h-12 rounded-full shadow-sm border border-[#e0dbd4]" style={{ backgroundColor: color }} />
                  <span className="text-[11px] text-[#9a9a9a] font-mono">{color}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Materials with usage */}
          <div>
            <h4 className="text-sm font-medium text-[#6b6b6b] mb-3">Материалы и применение</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {style.materials.map((m) => (
                <div key={m} className="flex items-start gap-3 bg-[#f7f5f2] rounded-xl px-4 py-3">
                  <div className="w-3 h-3 rounded-full bg-accent mt-1 flex-shrink-0" />
                  <div>
                    <p className="text-sm font-medium text-[#1a1a1a]">{m}</p>
                    <p className="text-xs text-muted mt-0.5">{style.materialUsage[m]}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Furniture */}
          <div>
            <h4 className="text-sm font-medium text-[#6b6b6b] mb-3 flex items-center gap-2">
              <Sofa size={16} className="text-accent" />
              Типичная мебель
            </h4>
            <div className="flex flex-wrap gap-2">
              {style.furniture.map((item) => (
                <span key={item} className="inline-flex items-center gap-1.5 bg-[#f0ebe4] text-[#5a5045] text-sm px-3 py-1.5 rounded-lg">
                  {item}
                </span>
              ))}
            </div>
          </div>

          {/* Ideal rooms */}
          <div>
            <h4 className="text-sm font-medium text-[#6b6b6b] mb-3 flex items-center gap-2">
              <HomeIcon size={16} className="text-accent" />
              Подходит для
            </h4>
            <div className="flex flex-wrap gap-2">
              {style.idealRooms.map((room) => (
                <span key={room} className="inline-flex items-center gap-1.5 border border-[#e0dbd4] text-[#4a4a4a] text-sm px-3 py-1.5 rounded-lg">
                  {room}
                </span>
              ))}
            </div>
          </div>

          {/* Pro tip */}
          <div className="bg-olive-100/60 rounded-xl p-4 flex gap-3">
            <Lightbulb size={20} className="text-accent flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="text-sm font-medium text-[#4a5a43] mb-1">Совет профессионала</h4>
              <p className="text-sm text-[#5a6a53] leading-relaxed">{style.tips}</p>
            </div>
          </div>

          {/* Similar styles */}
          <div>
            <h4 className="text-sm font-medium text-[#6b6b6b] mb-3 flex items-center gap-2">
              <Sparkles size={16} className="text-accent" />
              Похожие стили
            </h4>
            <div className="flex flex-wrap gap-2">
              {style.similarStyles.map((similar) => (
                <span key={similar} className="inline-flex items-center gap-1.5 bg-[#f7f5f2] text-[#6b6b6b] text-sm px-3 py-1.5 rounded-lg">
                  {similar}
                </span>
              ))}
            </div>
          </div>

          {/* CTA */}
          <button
            onClick={onClose}
            className="w-full py-3.5 rounded-xl bg-[#8b9d83] text-white font-medium text-base transition-all hover:bg-[#6b7a64] active:scale-[0.97]"
          >
            Закрыть
          </button>
        </div>
      </div>

      {/* Lightbox */}
      <AnimatePresence>
        {lightboxImage && (
          <motion.div
            className="fixed inset-0 z-[200] flex items-center justify-center bg-black/80 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setLightboxImage(null)}
          >
            <motion.img
              src={lightboxImage}
              alt="Reference"
              className="max-w-[90vw] max-h-[85vh] rounded-xl object-contain"
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              onClick={(e) => e.stopPropagation()}
            />
            <button
              onClick={() => setLightboxImage(null)}
              className="absolute top-4 right-4 w-10 h-10 flex items-center justify-center rounded-full bg-white/90 text-[#1a1a1a] hover:bg-white transition-colors"
            >
              <X size={20} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

function InteractiveStyles() {
  const [selected, setSelected] = useState<StyleData | null>(null);

  return (
    <div className="px-4 md:px-8 max-w-[1200px] mx-auto">
      {/* Grid */}
      <div className="flex md:grid md:grid-cols-3 gap-5 overflow-x-auto md:overflow-visible pb-4 md:pb-0 snap-x snap-mandatory -mx-4 px-4 md:mx-0 md:px-0 scrollbar-hide">
        {STYLE_DATA.map((style, i) => (
          <motion.div
            key={style.slug}
            className="flex-shrink-0 w-[280px] md:w-auto snap-center bg-white rounded-2xl border border-border overflow-hidden cursor-pointer group"
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.15 }}
            transition={{ duration: 0.35, delay: i * 0.06 }}
            whileHover={{ y: -4 }}
            onClick={() => setSelected(style)}
          >
            <div className="h-[200px] md:h-[260px] overflow-hidden">
              <img
                src={style.image}
                alt={style.name}
                className="w-full h-full object-cover transition-transform duration-[400ms] ease-[cubic-bezier(0.4,0,0.2,1)] group-hover:scale-[1.04]"
              />
            </div>
            <div className="p-5">
              <h3 className="font-serif text-[18px] font-medium text-text mb-1">{style.name}</h3>
              <p className="text-sm text-muted leading-relaxed line-clamp-2 mb-3">{style.description}</p>
              <div className="flex flex-wrap gap-1.5">
                {style.materials.slice(0, 2).map((m) => (
                  <span key={m} className="inline-block bg-olive-100 text-olive-700 text-[11px] font-medium px-2.5 py-1 rounded-lg">{m}</span>
                ))}
                <span className="inline-block text-muted text-[11px] px-1 py-1">+{style.materials.length - 2}</span>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Detail Modal */}
      <AnimatePresence>
        {selected && (
          <>
            {/* ── Desktop: slide-in panel from right ── */}
            <motion.div
              className="fixed inset-0 z-[100] bg-black/40 backdrop-blur-sm hidden md:block"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelected(null)}
            />
            <motion.div
              className="hidden md:flex fixed right-0 top-0 bottom-0 z-[101] w-full max-w-[540px] bg-white shadow-2xl flex-col"
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 28, stiffness: 300 }}
            >
              <StyleModalContent style={selected} onClose={() => setSelected(null)} />
            </motion.div>

            {/* ── Mobile: bottom sheet ── */}
            <motion.div
              className="fixed inset-0 z-[100] flex items-end justify-center md:hidden"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              {/* Overlay */}
              <motion.div
                className="absolute inset-0 bg-black/40 backdrop-blur-sm"
                onClick={() => setSelected(null)}
              />
              {/* Panel */}
              <motion.div
                className="relative w-full rounded-t-2xl bg-white max-h-[85vh] flex flex-col overflow-hidden"
                initial={{ y: '100%' }}
                animate={{ y: 0 }}
                exit={{ y: '100%' }}
                transition={{ type: 'spring', damping: 28, stiffness: 300 }}
              >
                <StyleModalContent style={selected} onClose={() => setSelected(null)} />
              </motion.div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function Home() {
  const navigate = useNavigate();

  return (
    <div className="min-h-[100dvh] bg-background">
      <Navbar />

      {/* Hero */}
      <section className="relative min-h-[85vh] md:min-h-[100dvh] flex items-center overflow-hidden">
        <motion.div
          className="absolute inset-0"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, ease: easeSmooth }}
        >
          <img
            src="/hero-bg.jpg"
            alt="Интерьер"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-[rgba(26,26,26,0.25)]" />
        </motion.div>

        <div className="relative z-10 max-w-content mx-auto px-4 md:px-8 w-full pt-20 md:pt-0">
          <div className="max-w-[640px]">
            <motion.p
              className="text-[11px] font-medium uppercase tracking-[0.08em] text-[#f7f5f2] opacity-70 mb-4"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: 0.3, ease: easeEnter }}
            >
              AI-АССИСТЕНТ РЕМОНТА
            </motion.p>

            <motion.h1
              className="font-serif text-[36px] md:text-[64px] font-semibold text-white leading-[1.1] mb-5"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.45, ease: easeEnter }}
            >
              Превратите хаос ремонта в пошаговый путь
            </motion.h1>

            <motion.p
              className="text-[16px] md:text-[18px] text-[#f7f5f2] opacity-85 leading-relaxed max-w-[520px] mb-8"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: 0.65, ease: easeEnter }}
            >
              От идеи до заселения за 15 минут. AI выберет стиль, составит план и скажет, что делать сегодня.
            </motion.p>

            <motion.div
              className="flex flex-col md:flex-row gap-3 mb-10"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35, delay: 0.8, ease: easeEnter }}
            >
              <button
                onClick={() => navigate('/login')}
                className="bg-accent text-white font-medium px-6 py-3.5 rounded-xl hover:bg-olive-600 transition-all duration-200 active:scale-[0.97] text-center"
              >
                Начать ремонт
              </button>
              <button
                onClick={() => document.getElementById('examples')?.scrollIntoView({ behavior: 'smooth' })}
                className="border border-white text-white font-medium px-6 py-3.5 rounded-xl hover:bg-white/10 transition-all duration-200 active:scale-[0.97] text-center"
              >
                Смотреть примеры
              </button>
            </motion.div>

            <motion.div
              className="flex items-center gap-6 md:gap-8"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3, delay: 1.0, ease: easeEnter }}
            >
              {['10 этапов', '7 стилей', '0 стресса'].map((stat) => (
                <span key={stat} className="text-sm text-[#f7f5f2] font-medium">
                  {stat}
                </span>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* Project Examples */}
      <section id="examples" className="py-12 md:py-20 bg-white">
        <div className="max-w-content mx-auto px-4 md:px-8">
          <div className="text-center mb-10">
            <p className="text-[11px] font-medium uppercase tracking-[0.08em] text-accent mb-3">
              РЕАЛИЗОВАННЫЕ ПРОЕКТЫ
            </p>
            <h2 className="font-serif text-[28px] md:text-[40px] font-semibold text-text mb-3">
              Посмотрите реальный проект
            </h2>
            <p className="text-[16px] text-muted">
              Минск, ЖК «Уютный» — 38 м², современная классика
            </p>
          </div>

          <SectionObserver>
            <div className="grid grid-cols-1 gap-5 max-w-[600px] mx-auto">
              {projects.map((project, i) => (
                <ProjectCarouselCard
                  key={project.name}
                  project={project}
                  index={i}
                  navigate={navigate}
                />
              ))}
            </div>
          </SectionObserver>
        </div>
      </section>

      {/* Interior Styles Gallery */}
      <section id="styles" className="py-12 md:py-20 bg-background">
        <div className="max-w-content mx-auto px-4 md:px-8">
          <div className="text-center mb-10">
            <p className="text-[11px] font-medium uppercase tracking-[0.08em] text-accent mb-3">
              ВЫБЕРИТЕ СВОЙ СТИЛЬ
            </p>
            <h2 className="font-serif text-[28px] md:text-[40px] font-semibold text-text mb-3">
              7 интерьерных стилей
            </h2>
            <p className="text-[16px] text-muted">
              Каждый со своими материалами, палитрой и референсами
            </p>
          </div>

          <SectionObserver>
            <InteractiveStyles />
          </SectionObserver>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-12 md:py-20 bg-white">
        <div className="max-w-content mx-auto px-4 md:px-8">
          <div className="text-center mb-12">
            <p className="text-[11px] font-medium uppercase tracking-[0.08em] text-accent mb-3">
              КАК ЭТО РАБОТАЕТ
            </p>
            <h2 className="font-serif text-[28px] md:text-[40px] font-semibold text-text">
              От хаоса — к плану за 15 минут
            </h2>
          </div>

          <SectionObserver>
            <div className="relative grid grid-cols-1 md:grid-cols-4 gap-8 md:gap-6">
              {/* Connecting line (desktop) */}
              <div className="hidden md:block absolute top-[32px] left-[12.5%] right-[12.5%] h-[2px]">
                <motion.div
                  className="h-full bg-accent/20"
                  initial={{ scaleX: 0 }}
                  whileInView={{ scaleX: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.8, delay: 0.3, ease: easeEnter }}
                  style={{ originX: 0 }}
                />
              </div>

              {steps.map((step, i) => {
                const Icon = step.icon;
                return (
                  <motion.div
                    key={step.title}
                    className="relative text-center"
                    initial={{ opacity: 0, y: 24 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, amount: 0.2 }}
                    transition={{ duration: 0.35, delay: i * 0.1, ease: easeEnter }}
                  >
                    <div className="relative inline-flex items-center justify-center w-16 h-16 rounded-full bg-olive-100 mb-5 mx-auto">
                      <Icon size={24} className="text-accent" />
                    </div>
                    <h3 className="text-base font-semibold text-text mb-2 relative z-10">
                      {step.title}
                    </h3>
                    <p className="text-sm text-muted leading-relaxed relative z-10">
                      {step.desc}
                    </p>
                  </motion.div>
                );
              })}
            </div>
          </SectionObserver>
        </div>
      </section>

      {/* Demo Project "ЖК Уютный" */}
      <section id="demo" className="py-12 md:py-16 bg-[#efeae4]">
        <div className="max-w-content mx-auto px-4 md:px-8">
          <SectionObserver>
            <motion.div
              className="bg-white rounded-2xl border border-border overflow-hidden"
              initial={{ opacity: 0, y: 32 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{ duration: 0.5, ease: easeEnter }}
            >
              <div className="grid grid-cols-1 md:grid-cols-2">
                <div className="aspect-video md:aspect-auto overflow-hidden">
                  <img
                    src="/proj-living.jpg"
                    alt="ЖК Уютный"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-6 md:p-10 flex flex-col justify-center">
                  <p className="text-[11px] font-medium uppercase tracking-[0.08em] text-accent mb-3">
                    ДЕМО-ПРОЕКТ
                  </p>
                  <h2 className="font-serif text-[24px] md:text-[28px] font-semibold text-text mb-4">
                    ЖК Уютный
                  </h2>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {['38 м²', 'Современная классика', 'Завершён'].map((chip) => (
                      <span
                        key={chip}
                        className="bg-olive-100 text-olive-700 text-[11px] font-medium uppercase tracking-wider px-3 py-1.5 rounded-lg"
                      >
                        {chip}
                      </span>
                    ))}
                  </div>
                  <p className="text-[15px] text-muted leading-relaxed mb-6">
                    Реальный проект, по которому вы можете пройти без регистрации. Увидите, как выглядят этапы, бюджет и чек-листы.
                  </p>
                  <div className="flex flex-col sm:flex-row gap-3">
                    <button
                      onClick={() => navigate('/demo-project')}
                      className="bg-accent text-white font-medium px-6 py-3 rounded-xl hover:bg-olive-600 transition-all active:scale-[0.97] text-center"
                    >
                      Открыть проект
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          </SectionObserver>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-12 md:py-20 bg-background">
        <div className="max-w-content mx-auto px-4 md:px-8">
          <div className="text-center mb-12">
            <p className="text-[11px] font-medium uppercase tracking-[0.08em] text-accent mb-3">
              ТАРИФЫ
            </p>
            <h2 className="font-serif text-[28px] md:text-[40px] font-semibold text-text">
              Выберите подходящий план
            </h2>
          </div>

          <SectionObserver>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {plans.map((plan, i) => (
                <motion.div
                  key={plan.name}
                  className={`relative bg-white rounded-2xl p-6 md:p-8 border transition-all duration-300 ${
                    plan.highlighted
                      ? 'border-2 border-accent shadow-lg'
                      : 'border-border shadow-sm hover:shadow-md'
                  }`}
                  initial={{ opacity: 0, y: 24 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.2 }}
                  transition={{ duration: 0.35, delay: i * 0.12, ease: easeEnter }}
                >
                  {plan.badge && (
                    <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-accent text-white text-[11px] font-medium uppercase tracking-wider px-3 py-1 rounded-full">
                      {plan.badge}
                    </span>
                  )}
                  <h3 className="text-lg font-semibold text-text mb-1">{plan.name}</h3>
                  <p className="font-serif text-[28px] font-semibold text-text mb-6">{plan.price}</p>
                  <ul className="space-y-3 mb-8">
                    {plan.features.map((f) => (
                      <li key={f.text} className="flex items-center gap-3 text-sm">
                        {f.available ? (
                          <Check size={16} className="text-success flex-shrink-0" />
                        ) : (
                          <X size={16} className="text-[#d4d0c9] flex-shrink-0" />
                        )}
                        <span className={f.available ? 'text-text' : 'text-[#9a9a9a]'}>
                          {f.text}
                          {f.limited && (
                            <span className="text-[11px] text-muted ml-1">(Limited)</span>
                          )}
                        </span>
                      </li>
                    ))}
                  </ul>
                  <button
                    onClick={() => navigate('/login')}
                    className={`w-full font-medium px-5 py-3 rounded-xl transition-all active:scale-[0.97] ${
                      plan.highlighted
                        ? 'bg-accent text-white hover:bg-olive-600'
                        : 'border border-accent text-text hover:bg-olive-100'
                    }`}
                  >
                    {plan.cta}
                  </button>
                </motion.div>
              ))}
            </div>
          </SectionObserver>
        </div>
      </section>

      {/* CTA Footer Banner */}
      <section className="py-12 md:py-16 bg-text">
        <div className="max-w-content mx-auto px-4 md:px-8 text-center">
          <motion.h2
            className="font-serif text-[28px] md:text-[32px] font-semibold text-white mb-3"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, ease: easeEnter }}
          >
            Готовы начать ремонт?
          </motion.h2>
          <motion.p
            className="text-[16px] text-[#9a9a9a] mb-8"
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, delay: 0.1, ease: easeEnter }}
          >
            15 минут — и у вас будет план. Без регистрации.
          </motion.p>
          <motion.div
            className="flex flex-col items-center gap-4"
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.35, delay: 0.2, ease: easeEnter }}
          >
            <button
              onClick={() => navigate('/login')}
              className="bg-accent text-white font-medium px-8 py-4 rounded-xl hover:bg-olive-600 transition-all active:scale-[0.97] text-lg"
            >
              Начать бесплатно
            </button>
            <button
              onClick={() => navigate('/demo-project')}
              className="text-accent hover:text-olive-100 transition-colors text-sm font-medium flex items-center gap-1"
            >
              Или посмотрите демо-проект «ЖК Уютный»
              <ArrowRight size={14} />
            </button>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
