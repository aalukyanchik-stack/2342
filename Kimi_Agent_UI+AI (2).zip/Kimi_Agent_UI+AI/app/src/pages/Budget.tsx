import { useState, useEffect, useMemo, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, AlertCircle, Wallet, CheckCircle } from 'lucide-react';
import { budget, type BudgetItem } from '@/lib/api';
import { useToast } from '@/components/Toast';
import AddItemModal from '@/components/budget/AddItemModal';
import BudgetTable from '@/components/budget/BudgetTable';
import BudgetCharts from '@/components/budget/BudgetCharts';
import BudgetSkeleton from '@/components/budget/BudgetSkeleton';
import BudgetSummary from '@/components/budget/BudgetSummary';

const DEMO_ITEMS: BudgetItem[] = [
  // Works
  { id: 'bw1', projectId: 'demo-lavada', category: 'Демонтаж', name: 'Демонтаж стен', plannedCost: 30000, actualCost: 32000, type: 'work' },
  { id: 'bw2', projectId: 'demo-lavada', category: 'Электрика', name: 'Проводка', plannedCost: 80000, actualCost: 75000, type: 'work' },
  { id: 'bw3', projectId: 'demo-lavada', category: 'Электрика', name: 'Розетки и выключатели', plannedCost: 25000, actualCost: 28000, type: 'work' },
  { id: 'bw4', projectId: 'demo-lavada', category: 'Сантехника', name: 'Монтаж труб', plannedCost: 60000, actualCost: 65000, type: 'work' },
  { id: 'bw5', projectId: 'demo-lavada', category: 'Черновая отделка', name: 'Штукатурка', plannedCost: 70000, actualCost: 72000, type: 'work' },
  { id: 'bw6', projectId: 'demo-lavada', category: 'Черновая отделка', name: 'Стяжка пола', plannedCost: 50000, actualCost: 48000, type: 'work' },
  { id: 'bw7', projectId: 'demo-lavada', category: 'Чистовая отделка', name: 'Покраска стен', plannedCost: 45000, actualCost: 40000, type: 'work' },
  { id: 'bw8', projectId: 'demo-lavada', category: 'Чистовая отделка', name: 'Поклейка обоев', plannedCost: 35000, actualCost: 38000, type: 'work' },
  { id: 'bw9', projectId: 'demo-lavada', category: 'Полы', name: 'Укладка ламината', plannedCost: 40000, actualCost: 42000, type: 'work' },
  { id: 'bw10', projectId: 'demo-lavada', category: 'Двери/окна', name: 'Установка дверей', plannedCost: 30000, actualCost: 29500, type: 'work' },
  // Materials
  { id: 'bm1', projectId: 'demo-lavada', category: 'Полы', name: 'Паркет (30м²)', plannedCost: 120000, actualCost: 125000, type: 'material' },
  { id: 'bm2', projectId: 'demo-lavada', category: 'Чистовая отделка', name: 'Плитка (ванная)', plannedCost: 50000, actualCost: 48000, type: 'material' },
  { id: 'bm3', projectId: 'demo-lavada', category: 'Чистовая отделка', name: 'Обои (гостиная)', plannedCost: 25000, actualCost: 30000, type: 'material' },
  { id: 'bm4', projectId: 'demo-lavada', category: 'Сантехника', name: 'Смесители', plannedCost: 40000, actualCost: 42000, type: 'material' },
  { id: 'bm5', projectId: 'demo-lavada', category: 'Сантехника', name: 'Ванна + душ', plannedCost: 60000, actualCost: 58000, type: 'material' },
  { id: 'bm6', projectId: 'demo-lavada', category: 'Мебель', name: 'Кухонный гарнитур', plannedCost: 180000, actualCost: 185000, type: 'material' },
  { id: 'bm7', projectId: 'demo-lavada', category: 'Электрика', name: 'Розетки Legrand', plannedCost: 12000, actualCost: 13000, type: 'material' },
  { id: 'bm8', projectId: 'demo-lavada', category: 'Двери/окна', name: 'Межкомнатные двери', plannedCost: 45000, actualCost: 44000, type: 'material' },
];

function formatCurrency(n: number): string {
  return n.toLocaleString('ru-RU') + ' ₽';
}

export default function BudgetPage() {
  const { showToast } = useToast();
  const [items, setItems] = useState<BudgetItem[]>([]);
  const [tab, setTab] = useState<'work' | 'material'>('work');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [seeded, setSeeded] = useState(false);

  // Seed demo budget data once
  useEffect(() => {
    const seed = async () => {
      try {
        const existing = await budget.list('demo-lavada');
        if (existing.length === 0) {
          for (const item of DEMO_ITEMS) {
            const { id: _id, ...rest } = item;
            await budget.create(rest as Omit<BudgetItem, 'id'>);
          }
        }
        setSeeded(true);
      } catch {
        setSeeded(true);
      }
    };
    seed();
  }, []);

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      setError(false);
      const data = await budget.list('demo-lavada');
      setItems(data);
    } catch {
      setError(true);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (seeded) fetchData();
  }, [seeded, fetchData]);

  const handleAdd = useCallback(async (item: Omit<BudgetItem, 'id' | 'projectId'>) => {
    try {
      await budget.create({ ...item, projectId: 'demo-lavada' });
      await fetchData();
      showToast('Статья добавлена', 'success');
    } catch {
      showToast('Ошибка сохранения', 'error');
    }
  }, [fetchData, showToast]);

  const handleUpdate = useCallback(async (id: string, data: Partial<BudgetItem>) => {
    try {
      await budget.update(id, data);
      await fetchData();
      showToast('Бюджет обновлен', 'success');
    } catch {
      showToast('Ошибка обновления', 'error');
    }
  }, [fetchData, showToast]);

  const handleDelete = useCallback(async (id: string) => {
    try {
      const all = JSON.parse(localStorage.getItem('budgetItems') || '[]') as BudgetItem[];
      const filtered = all.filter((b) => b.id !== id);
      localStorage.setItem('budgetItems', JSON.stringify(filtered));
      await fetchData();
      showToast('Статья удалена', 'success');
    } catch {
      showToast('Ошибка удаления', 'error');
    }
  }, [fetchData, showToast]);

  const filteredItems = useMemo(() => items.filter((i) => i.type === tab), [items, tab]);

  const totalPlan = filteredItems.reduce((s, i) => s + i.plannedCost, 0);
  const totalFact = filteredItems.reduce((s, i) => s + i.actualCost, 0);
  const isOverBudget = totalFact > totalPlan;

  if (loading && !seeded) {
    return (
      <div className="min-h-[100dvh] bg-background flex items-center justify-center">
        <div className="skeleton-shimmer h-6 w-32 rounded-md" />
      </div>
    );
  }

  return (
    <div className="min-h-[100dvh] bg-background">
      <div className="max-w-[1000px] mx-auto px-4 py-6 md:py-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
        >
          <h1 className="font-serif text-[24px] font-semibold text-text mb-1">Бюджет</h1>
          <p className="text-sm text-muted mb-4">План/факт/отклонение по категориям</p>
        </motion.div>

        {loading ? (
          <BudgetSkeleton />
        ) : error ? (
          <div className="text-center py-12">
            <AlertCircle className="mx-auto mb-3 text-[#c47d7d]" size={40} />
            <h3 className="font-medium text-text mb-1">Ошибка загрузки данных</h3>
            <button
              onClick={fetchData}
              className="mt-3 border border-[#8b9d83] text-[#1a1a1a] px-4 py-2 rounded-xl text-sm font-medium hover:bg-[#e8ede5] transition-colors"
            >
              Повторить
            </button>
          </div>
        ) : items.length === 0 ? (
          <div className="text-center py-12">
            <Wallet className="mx-auto mb-3 text-[#8b9d83]" size={40} />
            <h3 className="font-serif text-lg font-semibold text-text mb-2">Добавьте первую статью расходов</h3>
            <p className="text-sm text-muted mb-6 max-w-[320px] mx-auto">
              Начните планировать бюджет ремонта — мы будем отслеживать отклонения
            </p>
            <button
              onClick={() => setModalOpen(true)}
              className="bg-[#8b9d83] text-white text-sm font-medium px-5 py-2.5 rounded-xl hover:bg-[#6b7a64] transition-colors active:scale-[0.97]"
            >
              Добавить расход
            </button>
          </div>
        ) : (
          <>
            {/* Summary */}
            <BudgetSummary items={filteredItems} />

            {/* Charts */}
            <BudgetCharts items={filteredItems} />

            {/* Tabs */}
            <div className="flex gap-0 mb-4 border-b border-border relative">
              {(['work', 'material'] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => setTab(t)}
                  className={`relative px-4 py-2.5 text-sm font-medium transition-colors ${
                    tab === t ? 'text-[#8b9d83]' : 'text-[#6b6b6b] hover:text-text'
                  }`}
                >
                  {t === 'work' ? 'Работы' : 'Материалы'}
                  {tab === t && (
                    <motion.div
                      layoutId="budget-tab-indicator"
                      className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#8b9d83]"
                      transition={{ duration: 0.3, ease: [0.4, 0, 0.2, 1] as [number, number, number, number] }}
                    />
                  )}
                </button>
              ))}
            </div>

            {/* Tab Content */}
            <AnimatePresence mode="wait">
              <motion.div
                key={tab}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.2 }}
              >
                <BudgetTable items={filteredItems} onUpdate={handleUpdate} onDelete={handleDelete} />
              </motion.div>
            </AnimatePresence>

            {/* Add Button */}
            <button
              onClick={() => setModalOpen(true)}
              className="mt-4 w-full md:w-auto border border-[#8b9d83] text-[#1a1a1a] text-sm font-medium px-4 py-2.5 rounded-xl hover:bg-[#e8ede5] transition-colors inline-flex items-center gap-2 justify-center"
            >
              <Plus size={16} /> Добавить статью
            </button>

            {/* Bottom Summary */}
            <div className="mt-6 bg-white border border-border rounded-xl p-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-sm">
                <div className="flex justify-between md:justify-start md:gap-3">
                  <span className="text-muted">Всего план:</span>
                  <span className="font-medium text-text">{formatCurrency(totalPlan)}</span>
                </div>
                <div className="flex justify-between md:justify-start md:gap-3">
                  <span className="text-muted">Всего факт:</span>
                  <span className="font-medium text-text">{formatCurrency(totalFact)}</span>
                </div>
                <div className="flex justify-between md:justify-start md:gap-3">
                  <span className="text-muted">Отклонение:</span>
                  <span className={`font-medium ${isOverBudget ? 'text-[#c47d7d]' : 'text-[#7a9e7a]'}`}>
                    {totalFact - totalPlan > 0 ? '+' : ''}{formatCurrency(totalFact - totalPlan)}
                  </span>
                </div>
              </div>
              <div
                className={`mt-3 px-3 py-2 rounded-lg text-sm font-medium flex items-center gap-2 ${
                  isOverBudget
                    ? 'bg-[rgba(196,125,125,0.12)] text-[#8a4a4a]'
                    : 'bg-[rgba(122,158,122,0.12)] text-[#5a7a5a]'
                }`}
              >
                {isOverBudget ? <AlertCircle size={16} /> : <CheckCircle size={16} />}
                {isOverBudget
                  ? `⚠️ Бюджет превышен на ${Math.round(((totalFact - totalPlan) / totalPlan) * 100)}%`
                  : 'Бюджет в норме'}
              </div>
            </div>
          </>
        )}
      </div>

      <AddItemModal open={modalOpen} onClose={() => setModalOpen(false)} onSave={handleAdd} defaultType={tab} />
    </div>
  );
}
