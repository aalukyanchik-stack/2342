import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowLeft,
  X,
  Camera,
  Palette,
  LayoutGrid,
  Hammer,
  Wallet,
  Sparkles,
} from 'lucide-react';

/* ------------------------------------------------------------------ */
/*  DATA                                                               */
/* ------------------------------------------------------------------ */

const PROJECT = {
  name: 'ЖК Уютный',
  subtitle: '38 м² · Современная классика · Завершён',
  styleName: 'Современная классика',
  styleDescription:
    'Баланс традиций и современности. Паркет, текстиль, латунь. Тёплые деревянные поверхности, качественный текстиль и металлические акценты создают изысканную, но уютную атмосферу.',
  palette: ['#F0EBE0', '#B8A88A', '#B8B5A3', '#FFFFFF', '#D4C5A9'],
  materials: ['Паркет', 'Текстиль', 'Латунь', 'Стекло', 'Обои под ткань'],
};

const PHOTOS = [
  { src: '/proj-living.jpg', label: 'Гостиная' },
  { src: '/proj-kitchen1.jpg', label: 'Кухня' },
  { src: '/proj-kitchen2.jpg', label: 'Кухня' },
  { src: '/proj-bedroom1.jpg', label: 'Спальня' },
  { src: '/proj-bedroom2.jpg', label: 'Спальня' },
  { src: '/proj-bedroom3.jpg', label: 'Спальня' },
  { src: '/proj-bath.jpg', label: 'Ванная комната' },
  { src: '/proj-terrace1.jpg', label: 'Терраса' },
  { src: '/proj-terrace2.jpg', label: 'Терраса' },
  { src: '/proj-terrace3.jpg', label: 'Терраса' },
  { src: '/proj-terrace4.jpg', label: 'Терраса' },
];

const SPECS = [
  { label: 'Общая площадь', value: '38 м²' },
  { label: 'Жилая', value: '32 м²' },
  { label: 'Кухня', value: '8 м²' },
  { label: 'Спальня', value: '14 м²' },
  { label: 'Ванная', value: '4 м²' },
  { label: 'Терраса', value: '6 м²' },
  { label: 'Комнат', value: '1' },
  { label: 'Этаж', value: '3/9' },
];

const STAGES = [
  { name: 'Демонтаж', duration: '3 дня', works: 'Демонтаж старых покрытий, вывоз мусора', materials: null, cost: '$200' },
  { name: 'Электрика', duration: '5 дней', works: 'Прокладка кабелей, установка розеток/выключателей, сборка щитка', materials: 'Кабель ВВГнг 100м, розетки Legrand, автоматы', cost: '$550' },
  { name: 'Сантехника', duration: '3 дня', works: 'Разводка труб ГВС/ХВС, установка унитаза/раковины/душа', materials: 'Трубы Rehau, фитинги, смесители Grohe, сифоны', cost: '$500' },
  { name: 'Штукатурка и стяжка', duration: '7 дней', works: 'Штукатурка стен, стяжка пола', materials: 'Штукатурка гипсовая 350кг, маяки, стяжка 12 мешков', cost: '$900' },
  { name: 'Полы', duration: '4 дня', works: 'Укладка паркета ёлочкой, шлифовка, лакировка', materials: 'Паркетная доска Quick-Step 32м² ($2400)', cost: '$3,200' },
  { name: 'Потолки', duration: '2 дня', works: 'Монтаж натяжных потолков', materials: 'ПВХ-полотно, профиль, люстра', cost: '$1,060' },
  { name: 'Плитка', duration: '5 дней', works: 'Укладка плитки в ванной и на кухне, затирка', materials: 'Керамогранит кухня 4м² ($320), керамогранит ванная 12м² ($720), мозаика пол 4м² ($280), затирка', cost: '$1,820' },
  { name: 'Покраска и обои', duration: '4 дня', works: 'Грунтовка, покраска стен, поклейка обоев', materials: 'Краска 20л, обои под покраску 95м² ($950), малярный инструмент', cost: '$1,350' },
  { name: 'Двери', duration: '2 дня', works: 'Установка 3 дверей, плинтуса', materials: 'Межкомнатные двери шпонированные 3шт ($1200), дверные ручки, петли', cost: '$1,400' },
  { name: 'Финальная уборка', duration: '1 день', works: 'Генеральная уборка, вывоз мусора', materials: null, cost: '$100' },
];

const BUDGET_CARDS = [
  { label: 'Материалы', value: '~$6,980', colorClass: 'bg-[#8b9d83] text-white', pct: 65 },
  { label: 'Работы', value: '~$3,700', colorClass: 'bg-[#d4c5a9] text-[#1a1a1a]', pct: 35 },
];
const BUDGET_TOTAL = '$10,680';

/* ------------------------------------------------------------------ */
/*  HELPER: scroll animation variant                                   */
/* ------------------------------------------------------------------ */

const sectionVariants = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0 },
};

const transition = {
  duration: 0.5,
  ease: [0.16, 1, 0.3, 1] as [number, number, number, number],
};

/* ------------------------------------------------------------------ */
/*  COMPONENT                                                          */
/* ------------------------------------------------------------------ */

export default function DemoProject() {
  const navigate = useNavigate();
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const galleryRef = useRef<HTMLDivElement>(null);

  const openLightbox = (src: string) => setSelectedImage(src);
  const closeLightbox = () => setSelectedImage(null);

  return (
    <div className="min-h-[100dvh] bg-[#f7f5f2] font-sans text-[#1a1a1a]">
      {/* ============================================================ */}
      {/* 1. HEADER                                                    */}
      {/* ============================================================ */}
      <motion.div
        className="max-w-[1000px] mx-auto px-4 md:px-8 pt-6 md:pt-10 pb-6"
        initial={{ opacity: 0, y: -12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ ...transition, delay: 0 }}
      >
        <button
          onClick={() => navigate(-1)}
          className="inline-flex items-center gap-2 text-sm text-[#6b6b6b] hover:text-[#1a1a1a] transition-colors mb-4 group"
        >
          <ArrowLeft
            size={18}
            className="transition-transform group-hover:-translate-x-0.5"
          />
          <span>Назад</span>
        </button>

        <h1 className="font-serif text-2xl md:text-[30px] font-semibold text-[#1a1a1a] mb-1">
          {PROJECT.name}
        </h1>
        <p className="text-sm text-[#6b6b6b]">{PROJECT.subtitle}</p>
      </motion.div>

      {/* ============================================================ */}
      {/* 2. PHOTO GALLERY (horizontal scroll)                         */}
      {/* ============================================================ */}
      <motion.section
        className="py-6 md:py-10"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        variants={sectionVariants}
        transition={{ ...transition, delay: 0.05 }}
      >
        <div className="max-w-[1000px] mx-auto px-4 md:px-8 mb-4">
          <div className="flex items-center gap-2 mb-1">
            <Camera size={18} className="text-[#8b9d83]" />
            <h2 className="font-serif text-xl md:text-[22px] font-semibold text-[#1a1a1a]">
              Фото проекта
            </h2>
          </div>
          <p className="text-sm text-[#6b6b6b]">
            {PHOTOS.length} фото · нажмите для просмотра
          </p>
        </div>

        <div
          ref={galleryRef}
          className="flex gap-3 overflow-x-auto px-4 md:px-8 pb-4 scrollbar-hide"
          style={{ scrollbarWidth: 'none' }}
        >
          {PHOTOS.map((photo, i) => (
            <motion.button
              key={i}
              className="flex-shrink-0 group text-left"
              onClick={() => openLightbox(photo.src)}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.04 }}
            >
              <div className="w-[200px] md:w-[240px] h-[140px] md:h-[168px] rounded-xl overflow-hidden border border-[#e0dbd4] bg-white shadow-sm">
                <img
                  src={photo.src}
                  alt={photo.label}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  loading="lazy"
                />
              </div>
              <p className="text-xs text-[#6b6b6b] mt-2 pl-0.5">{photo.label}</p>
            </motion.button>
          ))}
        </div>
      </motion.section>

      {/* ============================================================ */}
      {/* 3. STYLE CARD                                                */}
      {/* ============================================================ */}
      <motion.section
        className="py-10 md:py-16"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        variants={sectionVariants}
        transition={transition}
      >
        <div className="max-w-[1000px] mx-auto px-4 md:px-8">
          <div className="bg-white rounded-2xl border border-[#e0dbd4] shadow-sm p-6 md:p-8">
            <div className="flex items-center gap-2 mb-5">
              <Palette size={18} className="text-[#8b9d83]" />
              <h2 className="font-serif text-xl md:text-[22px] font-semibold text-[#1a1a1a]">
                Стиль интерьера
              </h2>
            </div>

            <h3 className="font-serif text-lg font-semibold text-[#1a1a1a] mb-2">
              {PROJECT.styleName}
            </h3>
            <p className="text-sm text-[#6b6b6b] leading-relaxed mb-5 max-w-[640px]">
              {PROJECT.styleDescription}
            </p>

            {/* Color palette */}
            <p className="text-xs text-[#6b6b6b] uppercase tracking-wider mb-2.5 font-medium">
              Цветовая палитра
            </p>
            <div className="flex gap-3 mb-6">
              {PROJECT.palette.map((color, i) => (
                <div key={i} className="flex flex-col items-center gap-1.5">
                  <div
                    className="w-10 h-10 rounded-full border border-[#e0dbd4] shadow-sm"
                    style={{ backgroundColor: color }}
                  />
                  <span className="text-[10px] text-[#6b6b6b] font-mono">
                    {color}
                  </span>
                </div>
              ))}
            </div>

            {/* Material chips */}
            <p className="text-xs text-[#6b6b6b] uppercase tracking-wider mb-2.5 font-medium">
              Материалы
            </p>
            <div className="flex flex-wrap gap-2">
              {PROJECT.materials.map((m) => (
                <span
                  key={m}
                  className="px-3 py-1.5 rounded-full text-xs font-medium bg-[#e8ede5] text-[#5c6b55] border border-[#d4d0c9]"
                >
                  {m}
                </span>
              ))}
            </div>
          </div>
        </div>
      </motion.section>

                  {/* ============================================================ */}
      {/* 3.5. MOODBOARD                                               */}
      {/* ============================================================ */}
      <section className="mb-10">
        <div className="max-w-[1000px] mx-auto px-4 md:px-8">
        <motion.div
          className="bg-white rounded-2xl border border-[#e0dbd4] shadow-sm p-5 pb-10 md:p-6 md:pb-12"
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.15 }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        >
          <h3 className="font-serif text-[18px] font-semibold text-text mb-1">
            Мудборд
          </h3>
          <p className="text-xs text-muted mb-5">Материалы проекта</p>

          {/* Grid moodboard — exact layout per user sketch */}
          <div
            className="grid gap-1.5"
            style={{
              gridTemplateColumns: '1fr 1fr 1fr',
              gridTemplateRows: '22% 28% 15% 35%',
              height: '720px',
            }}
          >
            {/* (1,1) — Terrazzo */}
            <div className="overflow-hidden min-h-0" style={{ gridRow: 1, gridColumn: 1 }}>
              <img src="/mb-real-terrazzo.jpg" alt="" className="w-full h-full object-cover" />
            </div>

            {/* (2,1-2) — RAL 7032 spanning rows 1-2 */}
            <div className="overflow-hidden min-h-0" style={{ gridRow: '1 / 3', gridColumn: 2 }}>
              <img src="/mb-real-ral7032.jpg" alt="" className="w-full h-full object-cover" />
            </div>

            {/* (3,1-2) — Terrazzo tile spanning rows 1-2 */}
            <div className="overflow-hidden min-h-0" style={{ gridRow: '1 / 3', gridColumn: 3 }}>
              <img src="/mb-real-terrazzo-tile.jpg" alt="" className="w-full h-full object-cover" />
            </div>

            {/* (1,2) — Plaster + Gold side by side in row 2 */}
            <div className="grid grid-cols-[3fr_1fr] gap-1.5 min-h-0" style={{ gridRow: 2, gridColumn: 1 }}>
              <div className="overflow-hidden min-h-0" style={{ backgroundColor: '#C8C2B8' }} />
              <div className="overflow-hidden min-h-0">
                <img src="/mb-gold.jpg" alt="" className="w-full h-full object-cover" />
              </div>
            </div>

            {/* (1-2,3) — Parquet spanning cols 1-2 in row 3 */}
            <div className="overflow-hidden min-h-0" style={{ gridRow: 3, gridColumn: '1 / 3' }}>
              <img src="/mb-real-parquet.jpg" alt="" className="w-full h-full object-cover" />
            </div>

            {/* (3,3) — Empty/background in row 3 col 3 (tile ends at row 2) */}
            <div className="overflow-hidden min-h-0 bg-[#f0ebe4]" style={{ gridRow: 3, gridColumn: 3 }} />

            {/* (1-3,4) — Marble spanning all cols in row 4 */}
            <div className="overflow-hidden min-h-0" style={{ gridRow: 4, gridColumn: '1 / 4' }}>
              <img src="/mb-marble-white.png" alt="" className="w-full h-full object-cover" />
            </div>
          </div>
        </motion.div>
        </div>
      </section>

{/* ============================================================ */}
      {/* 4. FLOOR PLAN                                                */}
      {/* ============================================================ */}
      <motion.section
        className="py-10 md:py-16"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        variants={sectionVariants}
        transition={transition}
      >
        <div className="max-w-[1000px] mx-auto px-4 md:px-8">
          <div className="flex items-center gap-2 mb-5">
            <LayoutGrid size={18} className="text-[#8b9d83]" />
            <h2 className="font-serif text-xl md:text-[22px] font-semibold text-[#1a1a1a]">
              Планировочное решение
            </h2>
          </div>

          {/* Floor plan image */}
          <div className="bg-white rounded-2xl border border-[#e0dbd4] shadow-sm p-4 md:p-6 mb-5 flex justify-center">
            <div className="max-w-[800px] w-full">
              <img
                src="/proj-floorplan-new.jpg"
                alt="Планировочное решение ЖК Уютный"
                className="w-full h-auto rounded-xl object-contain"
                loading="lazy"
              />
            </div>
          </div>

          {/* Specs grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {SPECS.map((spec, i) => (
              <motion.div
                key={spec.label}
                className="bg-white rounded-xl border border-[#e0dbd4] shadow-sm p-3.5"
                initial={{ opacity: 0, y: 12 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.35, delay: i * 0.04 }}
              >
                <p className="text-xs text-[#6b6b6b] mb-0.5">{spec.label}</p>
                <p className="text-sm font-semibold text-[#1a1a1a]">{spec.value}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.section>

      {/* ============================================================ */}
      {/* 5. WORK STAGES                                               */}
      {/* ============================================================ */}
      <motion.section
        className="py-10 md:py-16"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        variants={sectionVariants}
        transition={transition}
      >
        <div className="max-w-[1000px] mx-auto px-4 md:px-8">
          <div className="flex items-center gap-2 mb-6">
            <Hammer size={18} className="text-[#8b9d83]" />
            <h2 className="font-serif text-xl md:text-[22px] font-semibold text-[#1a1a1a]">
              Этапы ремонта
            </h2>
          </div>

          <div className="space-y-4">
            {STAGES.map((stage, i) => (
              <motion.div
                key={i}
                className="bg-[#faf9f7] rounded-xl border border-[#e8e4de] p-4 md:p-5"
                initial={{ opacity: 0, y: 12 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.06 }}
              >
                <div className="flex items-start gap-4">
                  {/* Number circle */}
                  <div className="flex-shrink-0 w-8 h-8 rounded-full bg-[#8b9d83] flex items-center justify-center text-white text-sm font-semibold">
                    {i + 1}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h4 className="font-semibold text-[#1a1a1a]">{stage.name}</h4>
                      <span className="text-[10px] bg-[#e8ede5] text-[#5c6b55] px-2 py-0.5 rounded-md uppercase tracking-wider">
                        {stage.duration}
                      </span>
                    </div>

                    <div className="space-y-3 mb-3">
                      <div>
                        <p className="text-[10px] uppercase tracking-wider text-[#6b6b6b] mb-1">
                          Работы
                        </p>
                        <p className="text-sm text-[#1a1a1a] leading-relaxed">
                          {stage.works}
                        </p>
                      </div>
                      {stage.materials && (
                        <div>
                          <p className="text-[10px] uppercase tracking-wider text-[#6b6b6b] mb-1">
                            Материалы
                          </p>
                          <p className="text-sm text-[#1a1a1a] leading-relaxed">
                            {stage.materials}
                          </p>
                        </div>
                      )}
                    </div>

                    <div className="flex justify-end border-t border-[#e8e4de] pt-2">
                      <span className="text-sm font-semibold text-[#1a1a1a]">
                        {stage.cost}
                      </span>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.section>

      {/* ============================================================ */}
      {/* 7. BUDGET SUMMARY                                            */}
      {/* ============================================================ */}
      <motion.section
        className="py-10 md:py-16"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        variants={sectionVariants}
        transition={transition}
      >
        <div className="max-w-[1000px] mx-auto px-4 md:px-8">
          <div className="flex items-center gap-2 mb-5">
            <Wallet size={18} className="text-[#8b9d83]" />
            <h2 className="font-serif text-xl md:text-[22px] font-semibold text-[#1a1a1a]">
              Бюджет проекта
            </h2>
          </div>

          {/* Budget cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-5">
            {BUDGET_CARDS.map((card, i) => (
              <motion.div
                key={card.label}
                className={`rounded-2xl p-5 border shadow-sm ${card.colorClass} ${
                  i === 0 ? 'border-[#6b7a64]' : 'border-[#b8a88a]'
                }`}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.08 }}
              >
                <p
                  className={`text-xs font-medium uppercase tracking-wider mb-1 ${
                    i === 0 ? 'text-white/80' : 'text-[#6b6b6b]'
                  }`}
                >
                  {card.label}
                </p>
                <p
                  className={`text-xl font-bold ${
                    i === 0 ? 'text-white' : 'text-[#1a1a1a]'
                  }`}
                >
                  {card.value}
                </p>
              </motion.div>
            ))}
          </div>

          {/* Proportion bar */}
          <div className="bg-white rounded-2xl border border-[#e0dbd4] shadow-sm p-5">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-semibold text-[#1a1a1a]">Всего:</span>
              <span className="text-lg font-bold text-[#1a1a1a]">{BUDGET_TOTAL}</span>
            </div>

            {/* Segmented bar */}
            <div className="h-4 rounded-full overflow-hidden flex w-full">
              <motion.div
                className="h-full bg-[#8b9d83]"
                initial={{ width: 0 }}
                whileInView={{ width: `${BUDGET_CARDS[0].pct}%` }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: 0.2, ease: transition.ease }}
              />
              <motion.div
                className="h-full bg-[#d4c5a9]"
                initial={{ width: 0 }}
                whileInView={{ width: `${BUDGET_CARDS[1].pct}%` }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: 0.35, ease: transition.ease }}
              />
            </div>

            {/* Legend */}
            <div className="flex flex-wrap gap-4 mt-3">
              {BUDGET_CARDS.map((card) => (
                <div key={card.label} className="flex items-center gap-1.5 text-xs">
                  <div
                    className={`w-2.5 h-2.5 rounded-full ${
                      card.label === 'Материалы'
                        ? 'bg-[#8b9d83]'
                        : 'bg-[#d4c5a9]'
                    }`}
                  />
                  <span className="text-[#6b6b6b]">
                    {card.label} — {card.pct}%
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </motion.section>

      {/* ============================================================ */}
      {/* 8. CTA SECTION                                               */}
      {/* ============================================================ */}
      <motion.section
        className="py-12 md:py-20"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        variants={sectionVariants}
        transition={transition}
      >
        <div className="max-w-[1000px] mx-auto px-4 md:px-8">
          <div className="bg-white rounded-2xl border border-[#e0dbd4] shadow-sm p-8 md:p-12 text-center">
            <motion.div
              className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-[#e8ede5] mb-4"
              initial={{ scale: 0 }}
              whileInView={{ scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: 0.1, type: 'spring', stiffness: 200 }}
            >
              <Sparkles size={22} className="text-[#8b9d83]" />
            </motion.div>

            <h2 className="font-serif text-xl md:text-2xl font-semibold text-[#1a1a1a] mb-2">
              Хотите такой же ремонт?
            </h2>
            <p className="text-sm text-[#6b6b6b] mb-6 max-w-[400px] mx-auto leading-relaxed">
              Создайте проект в PROSTRANSTVO и получите пошаговый план с
              бюджетом, сроками и чек-листами
            </p>

            <div className="flex flex-col sm:flex-row gap-3 justify-center items-center">
              <motion.button
                onClick={() => navigate('/register')}
                className="w-full sm:w-auto px-6 py-3 bg-[#8b9d83] text-white text-sm font-medium rounded-xl hover:bg-[#6b7a64] transition-colors active:scale-[0.97]"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.97 }}
              >
                Создать проект
              </motion.button>
              <motion.button
                onClick={() => navigate(-1)}
                className="w-full sm:w-auto px-6 py-3 border border-[#e0dbd4] text-[#1a1a1a] text-sm font-medium rounded-xl hover:bg-[#f0ebe0] transition-colors"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.97 }}
              >
                Посмотреть другие проекты
              </motion.button>
            </div>
          </div>
        </div>
      </motion.section>

      {/* Bottom spacing */}
      <div className="h-12" />

      {/* ============================================================ */}
      {/* LIGHTBOX (AnimatePresence)                                   */}
      {/* ============================================================ */}
      <AnimatePresence>
        {selectedImage && (
          <motion.div
            className="fixed inset-0 z-[500] flex items-center justify-center p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            onClick={closeLightbox}
          >
            {/* Backdrop */}
            <motion.div
              className="absolute inset-0 bg-[rgba(26,26,26,0.88)] backdrop-blur-sm"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            />

            {/* Image container */}
            <motion.div
              className="relative z-10 max-w-[90vw] max-h-[85vh] flex flex-col items-center"
              initial={{ scale: 0.88, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.88, opacity: 0 }}
              transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
              onClick={(e) => e.stopPropagation()}
            >
              <img
                src={selectedImage}
                alt="Просмотр"
                className="max-w-full max-h-[80vh] rounded-xl object-contain shadow-2xl"
              />
              <p className="text-white/60 text-xs mt-3">
                {PHOTOS.find((p) => p.src === selectedImage)?.label || ''}
              </p>
            </motion.div>

            {/* Close button */}
            <motion.button
              className="absolute top-4 right-4 z-20 w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors"
              onClick={closeLightbox}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              transition={{ duration: 0.2 }}
              aria-label="Закрыть"
            >
              <X size={20} />
            </motion.button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
