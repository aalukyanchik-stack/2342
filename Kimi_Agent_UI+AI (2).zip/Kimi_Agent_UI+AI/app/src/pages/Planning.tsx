import { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Plus } from 'lucide-react';
import type { Room, Project } from '@/lib/api';
import { projects } from '@/lib/api';
import FloorPlanCanvas from '@/components/planning/FloorPlanCanvas';
import RoomList from '@/components/planning/RoomList';
import AddRoomModal from '@/components/planning/AddRoomModal';
import EmptyState from '@/components/EmptyState';
import { useToast } from '@/components/Toast';

function uuid() {
  return `${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

function getStore<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function setStore<T>(key: string, value: T) {
  localStorage.setItem(key, JSON.stringify(value));
}

const DEMO_ROOMS: Room[] = [
  { id: 'r1', projectId: 'demo-lavada', name: 'Гостиная', roomType: 'living', area: 18, ceilingHeight: 2.7, windowsCount: 2, furnitureLayout: 'Диван у окна, TV-тумба напротив' },
  { id: 'r2', projectId: 'demo-lavada', name: 'Кухня', roomType: 'kitchen', area: 12, ceilingHeight: 2.7, windowsCount: 1, furnitureLayout: 'Г-образная столешница, обеденный стол' },
  { id: 'r3', projectId: 'demo-lavada', name: 'Спальня', roomType: 'bedroom', area: 14, ceilingHeight: 2.7, windowsCount: 1, furnitureLayout: 'Кровать у стены, шкаф у окна' },
  { id: 'r4', projectId: 'demo-lavada', name: 'Ванная', roomType: 'bathroom', area: 6, ceilingHeight: 2.5, windowsCount: 1, furnitureLayout: 'Ванна, раковина, стиральная машина' },
];

export default function Planning() {
  const [project, setProject] = useState<Project | null>(null);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [selectedRoomId, setSelectedRoomId] = useState<string | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const { showToast } = useToast();

  const loadProject = useCallback(async () => {
    setLoading(true);
    try {
      // Try to get current project from localStorage or use first available
      let projectId = localStorage.getItem('currentProjectId');
      if (!projectId) {
        const all = await projects.list();
        const active = all.find((p) => p.status === 'active') || all[0];
        if (active) {
          projectId = active.id;
          localStorage.setItem('currentProjectId', projectId);
        }
      }

      if (projectId) {
        const p = await projects.get(projectId);
        setProject(p);
        if (p) {
          setRooms(p.rooms.length > 0 ? p.rooms : DEMO_ROOMS.map((r) => ({ ...r, projectId: p.id })));
        } else {
          setRooms([]);
        }
      } else {
        setProject(null);
        setRooms([]);
      }
    } catch {
      // No project - empty state
      setProject(null);
      setRooms([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadProject();
  }, [loadProject]);

  const persistRooms = useCallback((updatedRooms: Room[], projId?: string) => {
    const pid = projId || project?.id || 'demo-lavada';
    const allProjects = getStore<Project[]>('projects', []);
    const idx = allProjects.findIndex((p) => p.id === pid);
    if (idx !== -1) {
      allProjects[idx] = { ...allProjects[idx], rooms: updatedRooms };
      setStore('projects', allProjects);
    }
  }, [project]);

  const handleUpdateRoom = useCallback((id: string, data: Partial<Room>) => {
    setRooms((prev) => {
      const updated = prev.map((r) => (r.id === id ? { ...r, ...data } : r));
      persistRooms(updated);
      return updated;
    });
  }, [persistRooms]);

  const handleDeleteRoom = useCallback((id: string) => {
    setRooms((prev) => {
      const updated = prev.filter((r) => r.id !== id);
      persistRooms(updated);
      return updated;
    });
    setSelectedRoomId((prev) => (prev === id ? null : prev));
    showToast('Комната удалена');
  }, [persistRooms, showToast]);

  const handleAddRoom = useCallback((data: {
    name: string;
    roomType: string;
    area: number;
    ceilingHeight: number;
    windowsCount: number;
  }) => {
    const newRoom: Room = {
      id: uuid(),
      projectId: project?.id || 'demo-lavada',
      name: data.name,
      roomType: data.roomType,
      area: data.area,
      ceilingHeight: data.ceilingHeight,
      windowsCount: data.windowsCount,
    };
    setRooms((prev) => {
      const updated = [...prev, newRoom];
      persistRooms(updated);
      return updated;
    });
    showToast('Комната добавлена');
  }, [project, persistRooms, showToast]);

  if (loading) {
    return (
      <div className="min-h-[100dvh] bg-background px-4 md:px-8 py-6 md:pt-10">
        <div className="max-w-[1200px] mx-auto">
          <div className="h-8 w-48 bg-olive-200 rounded animate-pulse mb-2" />
          <div className="h-4 w-72 bg-olive-200 rounded animate-pulse mb-8" />
          <div className="grid grid-cols-1 lg:grid-cols-[1fr_380px] gap-6">
            <div className="aspect-[4/3] bg-olive-200 rounded-2xl animate-pulse" />
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-20 bg-olive-200 rounded-xl animate-pulse" />
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!project && rooms.length === 0) {
    return (
      <div className="min-h-[100dvh] bg-background flex items-center justify-center px-4">
        <EmptyState
          title="Добавьте комнаты"
          description="Начните с гостиной или спальни — остальное добавим вместе"
          ctaLabel="Добавить первую комнату"
          ctaHref="/dashboard"
        />
      </div>
    );
  }

  return (
    <motion.div
      className="min-h-[100dvh] bg-background px-4 md:px-8 py-6 md:pt-10 pb-24 md:pb-10"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
    >
      <div className="max-w-[1200px] mx-auto">
        {/* Header */}
        <div className="flex items-start justify-between mb-6">
          <div>
            <h1 className="font-serif text-2xl md:text-[28px] font-semibold text-text mb-1">Планировка</h1>
            <p className="text-sm text-muted">Визуальный план вашей квартиры</p>
          </div>
          <button
            onClick={() => setModalOpen(true)}
            className="hidden md:flex items-center gap-2 bg-accent text-white text-sm font-medium px-4 py-2.5 rounded-xl hover:bg-olive-600 transition-colors active:scale-[0.97]"
          >
            <Plus size={18} />
            Добавить комнату
          </button>
        </div>

        {/* Content */}
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_400px] gap-6">
          {/* Floor Plan Canvas */}
          <div>
            <FloorPlanCanvas
              rooms={rooms}
              selectedRoomId={selectedRoomId}
              onSelectRoom={setSelectedRoomId}
            />
          </div>

          {/* Room List */}
          <div>
            <RoomList
              rooms={rooms}
              selectedRoomId={selectedRoomId}
              onSelectRoom={setSelectedRoomId}
              onUpdateRoom={handleUpdateRoom}
              onDeleteRoom={handleDeleteRoom}
              onAddRoom={() => setModalOpen(true)}
            />
          </div>
        </div>
      </div>

      {/* Mobile FAB */}
      <button
        onClick={() => setModalOpen(true)}
        className="md:hidden fixed bottom-20 right-4 z-[50] w-12 h-12 bg-accent text-white rounded-full shadow-lg flex items-center justify-center active:scale-[0.92] transition-transform"
      >
        <Plus size={20} />
      </button>

      {/* Add Room Modal */}
      <AddRoomModal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        onSave={handleAddRoom}
      />
    </motion.div>
  );
}
