import { useState, useEffect, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  LayoutDashboard,
  Users,
  Folder,
  CreditCard,
  Briefcase,
  Settings,
  Lock,
  ArrowLeft,
  Pencil,
  Ban,
  Trash2,
  ChevronDown,
  ChevronUp,
  ChevronsLeft,
  ChevronsRight,
  ChevronLeft,
  ChevronRight,
  TrendingUp,
  TrendingDown,
  DollarSign,
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Area,
  AreaChart,
  PieChart,
  Pie,
  Cell,
} from 'recharts';

// ── Types ──────────────────────────────────────────────
interface MockUser {
  id: string;
  name: string;
  email: string;
  tariff: 'free' | 'pro' | 'pro_plus';
  projects: number;
  registeredAt: string;
  status: 'active' | 'inactive' | 'banned';
}

interface KPIData {
  label: string;
  value: number;
  change: number;
  prefix?: string;
  suffix?: string;
  icon: React.ElementType;
}

// ── Mock Data ──────────────────────────────────────────
const MOCK_USERS: MockUser[] = Array.from({ length: 20 }).map((_, i) => ({
  id: `user-${1000 + i}`,
  name: [
    'Анна Смирнова', 'Иван Петров', 'Мария Кузнецова', 'Алексей Волков', 'Елена Лебедева',
    'Дмитрий Соколов', 'Ольга Попова', 'Сергей Новиков', 'Татьяна Морозова', 'Андрей Павлов',
    'Наталья Васильева', 'Михаил Семенов', 'Юлия Голубева', 'Павел Виноградов', 'Светлана Федорова',
    'Константин Жуков', 'Вероника Данилова', 'Григорий Козлов', 'Алина Макарова', 'Роман Борисов',
  ][i],
  email: `user${i + 1}@example.com`,
  tariff: ['free', 'free', 'pro', 'free', 'pro_plus', 'free', 'pro', 'free', 'free', 'pro',
    'free', 'pro', 'free', 'free', 'pro_plus', 'free', 'pro', 'free', 'free', 'pro'][i] as MockUser['tariff'],
  projects: Math.floor(Math.random() * 5) + 1,
  registeredAt: new Date(Date.now() - Math.random() * 180 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
  status: ['active', 'active', 'active', 'active', 'active', 'active', 'active', 'active', 'inactive', 'active',
    'active', 'active', 'active', 'banned', 'active', 'active', 'active', 'active', 'active', 'active'][i] as MockUser['status'],
}));

const REVENUE_DATA = [
  { month: 'Авг', revenue: 210 },
  { month: 'Сен', revenue: 280 },
  { month: 'Окт', revenue: 340 },
  { month: 'Ноя', revenue: 390 },
  { month: 'Дек', revenue: 360 },
  { month: 'Янв', revenue: 430 },
];

const PROJECT_STATUS_DATA = [
  { name: 'Планирование', count: 35, color: '#c5d1be' },
  { name: 'В работе', count: 42, color: '#8b9d83' },
  { name: 'Завершен', count: 18, color: '#a8b8a0' },
  { name: 'Архив', count: 10, color: '#d4d0c9' },
];

const TARIFF_DISTRIBUTION = [
  { name: 'FREE', value: 97, color: '#d4d0c9' },
  { name: 'PRO', value: 18, color: '#8b9d83' },
  { name: 'PRO+', value: 5, color: '#1a1a1a' },
];

const KPI_ITEMS: KPIData[] = [
  { label: 'Всего пользователей', value: 1247, change: 12, icon: Users, suffix: '' },
  { label: 'Активных проектов', value: 892, change: 8, icon: Folder, suffix: '' },
  { label: 'PRO подписчиков', value: 23, change: 15, icon: TrendingUp, suffix: '' },
  { label: 'Выручка (мес)', value: 3420, change: 24, icon: DollarSign, prefix: '$', suffix: '' },
];

const SIDEBAR_ITEMS = [
  { icon: LayoutDashboard, label: 'Обзор', key: 'overview' },
  { icon: Users, label: 'Пользователи', key: 'users' },
  { icon: Folder, label: 'Проекты', key: 'projects' },
  { icon: CreditCard, label: 'Транзакции', key: 'transactions' },
  { icon: Briefcase, label: 'Подрядчики', key: 'contractors' },
  { icon: Settings, label: 'Настройки', key: 'settings' },
];

// ── Helpers ────────────────────────────────────────────
const formatDate = (dateStr: string) => {
  const d = new Date(dateStr);
  return d.toLocaleDateString('ru-RU', { day: 'numeric', month: 'short', year: 'numeric' });
};

const getTariffLabel = (t: string) => {
  if (t === 'free') return 'FREE';
  if (t === 'pro') return 'PRO';
  return 'PRO+';
};

const getTariffChipStyle = (t: string) => {
  if (t === 'free') return 'bg-[#e8ede5] text-[#5c6b55]';
  if (t === 'pro') return 'bg-[#8b9d83] text-white';
  return 'bg-[#1a1a1a] text-white';
};

const getStatusDot = (status: string) => {
  if (status === 'active') return 'bg-[#7a9e7a]';
  if (status === 'inactive') return 'bg-[#9a9a9a]';
  return 'bg-[#c47d7d]';
};

const getStatusLabel = (status: string) => {
  if (status === 'active') return 'Активен';
  if (status === 'inactive') return 'Неактивен';
  return 'Заблокирован';
};

// ── CountUp Hook ───────────────────────────────────────
function useCountUp(target: number, duration = 1000, start = 0) {
  const [value, setValue] = useState(start);
  const rafRef = useRef<number | undefined>(undefined);
  const startTime = useRef<number | undefined>(undefined);

  useEffect(() => {
    const animate = (ts: number) => {
      if (!startTime.current) startTime.current = ts;
      const progress = Math.min((ts - startTime.current) / duration, 1);
      // ease-out cubic
      const eased = 1 - Math.pow(1 - progress, 3);
      setValue(Math.floor(start + (target - start) * eased));
      if (progress < 1) {
        rafRef.current = requestAnimationFrame(animate);
      }
    };
    rafRef.current = requestAnimationFrame(animate);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [target, duration, start]);

  return value;
}

// ── KPI Card ──────────────────────────────────────────
function KPICard({ item, index }: { item: KPIData; index: number }) {
  const displayValue = useCountUp(item.value, 1200);
  const Icon = item.icon;
  const isPositive = item.change >= 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.08, duration: 0.3, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
      className="bg-white border border-[#e0dbd4] rounded-xl p-5"
    >
      <div className="flex items-start justify-between mb-3">
        <div className="w-10 h-10 rounded-lg bg-[#e8ede5] flex items-center justify-center">
          <Icon size={20} className="text-[#8b9d83]" />
        </div>
        <div className={`flex items-center gap-1 text-xs font-medium ${isPositive ? 'text-[#7a9e7a]' : 'text-[#c47d7d]'}`}>
          {isPositive ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
          {isPositive ? '+' : ''}{item.change}%
        </div>
      </div>
      <div className="font-serif text-[28px] font-semibold text-[#1a1a1a] leading-tight">
        {item.prefix}{displayValue.toLocaleString('ru-RU')}{item.suffix}
      </div>
      <div className="text-xs text-[#6b6b6b] uppercase tracking-[0.04em] mt-1">
        {item.label}
      </div>
    </motion.div>
  );
}

// ── Users Table ───────────────────────────────────────
function UsersTable({ users }: { users: MockUser[] }) {
  const [sortField, setSortField] = useState<keyof MockUser>('registeredAt');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');
  const [filterTariff, setFilterTariff] = useState<string>('all');
  const [page, setPage] = useState(1);
  const perPage = 8;

  const handleSort = (field: keyof MockUser) => {
    if (sortField === field) {
      setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortDir('asc');
    }
  };

  const filtered = useMemo(() => {
    let list = [...users];
    if (filterTariff !== 'all') {
      list = list.filter((u) => u.tariff === filterTariff);
    }
    list.sort((a, b) => {
      const aVal = a[sortField];
      const bVal = b[sortField];
      if (typeof aVal === 'string' && typeof bVal === 'string') {
        return sortDir === 'asc' ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
      }
      if (typeof aVal === 'number' && typeof bVal === 'number') {
        return sortDir === 'asc' ? aVal - bVal : bVal - aVal;
      }
      return 0;
    });
    return list;
  }, [users, sortField, sortDir, filterTariff]);

  const totalPages = Math.ceil(filtered.length / perPage);
  const paginated = filtered.slice((page - 1) * perPage, page * perPage);

  const SortIcon = ({ field }: { field: keyof MockUser }) => {
    if (sortField !== field) return <ChevronDown size={14} className="text-[#c4bfb6]" />;
    return sortDir === 'asc' ? <ChevronUp size={14} className="text-[#8b9d83]" /> : <ChevronDown size={14} className="text-[#8b9d83]" />;
  };

  return (
    <div>
      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3 mb-4">
        <div className="flex items-center gap-2">
          <span className="text-xs text-[#6b6b6b]">Тариф:</span>
          {(['all', 'free', 'pro', 'pro_plus'] as const).map((t) => (
            <button
              key={t}
              onClick={() => { setFilterTariff(t); setPage(1); }}
              className={`text-xs font-medium px-2.5 py-1 rounded-lg transition-colors ${
                filterTariff === t
                  ? 'bg-[#8b9d83] text-white'
                  : 'bg-[#f7f5f2] text-[#6b6b6b] hover:bg-[#e8ede5]'
              }`}
            >
              {t === 'all' ? 'Все' : t === 'free' ? 'FREE' : t === 'pro' ? 'PRO' : 'PRO+'}
            </button>
          ))}
        </div>
        <span className="text-xs text-[#9a9a9a] ml-auto">
          Показано {(page - 1) * perPage + 1}–{Math.min(page * perPage, filtered.length)} из {filtered.length}
        </span>
      </div>

      {/* Table */}
      <div className="bg-white border border-[#e0dbd4] rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-[#efeae4]">
                {[
                  { key: 'id' as keyof MockUser, label: 'ID' },
                  { key: 'name' as keyof MockUser, label: 'Имя' },
                  { key: 'email' as keyof MockUser, label: 'Email' },
                  { key: 'tariff' as keyof MockUser, label: 'Тариф' },
                  { key: 'projects' as keyof MockUser, label: 'Проекты' },
                  { key: 'registeredAt' as keyof MockUser, label: 'Дата регистрации' },
                  { key: 'status' as keyof MockUser, label: 'Статус' },
                ].map((col) => (
                  <th
                    key={col.key}
                    onClick={() => handleSort(col.key)}
                    className="text-left px-4 py-3 text-xs font-medium uppercase tracking-[0.04em] text-[#6b6b6b] cursor-pointer select-none hover:text-[#1a1a1a] transition-colors"
                  >
                    <div className="flex items-center gap-1">
                      {col.label}
                      <SortIcon field={col.key} />
                    </div>
                  </th>
                ))}
                <th className="px-4 py-3 text-xs font-medium uppercase tracking-[0.04em] text-[#6b6b6b]">
                  Действия
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#e0dbd4]">
              <AnimatePresence>
                {paginated.map((user, i) => (
                  <motion.tr
                    key={user.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: i * 0.03, duration: 0.15 }}
                    className="hover:bg-[#f7f5f2] transition-colors"
                  >
                    <td className="px-4 py-3 text-sm text-[#9a9a9a] font-mono">{user.id}</td>
                    <td className="px-4 py-3 text-sm font-medium text-[#1a1a1a]">{user.name}</td>
                    <td className="px-4 py-3 text-sm text-[#6b6b6b]">{user.email}</td>
                    <td className="px-4 py-3">
                      <span className={`text-[11px] font-medium px-2.5 py-1 rounded-lg ${getTariffChipStyle(user.tariff)}`}>
                        {getTariffLabel(user.tariff)}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-sm text-[#1a1a1a]">{user.projects}</td>
                    <td className="px-4 py-3 text-sm text-[#6b6b6b]">{formatDate(user.registeredAt)}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1.5">
                        <span className={`w-2 h-2 rounded-full ${getStatusDot(user.status)}`} />
                        <span className="text-sm text-[#6b6b6b]">{getStatusLabel(user.status)}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1">
                        <button className="p-1.5 rounded-lg hover:bg-[#e8ede5] transition-colors" title="Редактировать">
                          <Pencil size={14} className="text-[#6b6b6b]" />
                        </button>
                        <button className="p-1.5 rounded-lg hover:bg-[rgba(196,125,125,0.08)] transition-colors" title="Заблокировать">
                          <Ban size={14} className="text-[#c47d7d]" />
                        </button>
                        <button className="p-1.5 rounded-lg hover:bg-[rgba(196,125,125,0.08)] transition-colors" title="Удалить">
                          <Trash2 size={14} className="text-[#c47d7d]" />
                        </button>
                      </div>
                    </td>
                  </motion.tr>
                ))}
              </AnimatePresence>
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-[#e0dbd4]">
            <button
              onClick={() => setPage(1)}
              disabled={page === 1}
              className="p-1.5 rounded-lg hover:bg-[#f7f5f2] disabled:opacity-30 transition-colors"
            >
              <ChevronsLeft size={16} className="text-[#6b6b6b]" />
            </button>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={page === 1}
                className="p-1.5 rounded-lg hover:bg-[#f7f5f2] disabled:opacity-30 transition-colors"
              >
                <ChevronLeft size={16} className="text-[#6b6b6b]" />
              </button>
              {Array.from({ length: totalPages }).map((_, i) => (
                <button
                  key={i}
                  onClick={() => setPage(i + 1)}
                  className={`w-8 h-8 rounded-lg text-xs font-medium transition-colors ${
                    page === i + 1
                      ? 'bg-[#8b9d83] text-white'
                      : 'text-[#6b6b6b] hover:bg-[#f7f5f2]'
                  }`}
                >
                  {i + 1}
                </button>
              ))}
              <button
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                disabled={page === totalPages}
                className="p-1.5 rounded-lg hover:bg-[#f7f5f2] disabled:opacity-30 transition-colors"
              >
                <ChevronRight size={16} className="text-[#6b6b6b]" />
              </button>
            </div>
            <button
              onClick={() => setPage(totalPages)}
              disabled={page === totalPages}
              className="p-1.5 rounded-lg hover:bg-[#f7f5f2] disabled:opacity-30 transition-colors"
            >
              <ChevronsRight size={16} className="text-[#6b6b6b]" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Custom Tooltip for Charts ──────────────────────────
function ChartTooltip({ active, payload, label }: any) {
  if (!active || !payload || !payload.length) return null;
  return (
    <div className="bg-white border border-[#e0dbd4] rounded-lg px-3 py-2 shadow-md">
      <p className="text-xs font-medium text-[#6b6b6b] mb-1">{label}</p>
      {payload.map((entry: any, i: number) => (
        <p key={i} className="text-sm font-medium text-[#1a1a1a]">
          {entry.value}
        </p>
      ))}
    </div>
  );
}

// ── Admin Sidebar ─────────────────────────────────────
function AdminSidebar({ activeTab, onTabChange }: { activeTab: string; onTabChange: (k: string) => void }) {
  return (
    <aside className="hidden md:flex flex-col w-[260px] bg-[#1a1a1a] fixed left-0 top-0 bottom-0 z-[100]">
      <div className="h-16 flex items-center px-6 border-b border-[rgba(255,255,255,0.08)]">
        <span className="font-serif text-[18px] font-semibold text-[#f7f5f2]">PROSTRANSTVO</span>
      </div>
      <nav className="flex-1 py-4 px-3">
        {SIDEBAR_ITEMS.map((item) => (
          <button
            key={item.key}
            onClick={() => onTabChange(item.key)}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
              activeTab === item.key
                ? 'bg-[rgba(139,157,131,0.2)] text-[#8b9d83] border-l-[3px] border-[#8b9d83]'
                : 'text-[#9a9a9a] hover:bg-[rgba(255,255,255,0.05)]'
            }`}
          >
            <item.icon size={18} />
            {item.label}
          </button>
        ))}
      </nav>
      <div className="px-4 py-4 border-t border-[rgba(255,255,255,0.08)]">
        <div className="flex items-center gap-3">
          <img src="/avatar-default.jpg" alt="Admin" className="w-8 h-8 rounded-full object-cover" />
          <div>
            <p className="text-sm text-[#f7f5f2]">Администратор</p>
            <span className="text-[10px] font-bold bg-[#8b9d83] text-[#1a1a1a] px-2 py-0.5 rounded">ADMIN</span>
          </div>
        </div>
      </div>
    </aside>
  );
}

// ── Access Denied ──────────────────────────────────────
function AccessDenied() {
  const navigate = useNavigate();
  return (
    <div className="min-h-[100dvh] bg-[#f7f5f2] flex items-center justify-center px-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
        className="text-center"
      >
        <div className="w-16 h-16 rounded-full bg-[#e8ede5] flex items-center justify-center mx-auto mb-4">
          <Lock size={28} className="text-[#8b9d83]" />
        </div>
        <h2 className="font-serif text-2xl font-semibold text-[#1a1a1a] mb-2">
          Доступ запрещен
        </h2>
        <p className="text-sm text-[#6b6b6b] mb-6">
          У вас нет прав администратора
        </p>
        <button
          onClick={() => navigate('/dashboard')}
          className="inline-flex items-center gap-2 bg-[#8b9d83] text-white text-sm font-medium px-5 py-2.5 rounded-xl hover:bg-[#6b7a64] transition-colors"
        >
          <ArrowLeft size={16} />
          Вернуться
        </button>
      </motion.div>
    </div>
  );
}

// ── Main Admin Page ───────────────────────────────────
export default function Admin() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('overview');
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  // Guard: non-admin access
  if (!user || user.role !== 'admin') {
    return <AccessDenied />;
  }

  const sectionVariants = {
    hidden: { opacity: 0, y: 16 },
    visible: (i: number) => ({
      opacity: 1,
      y: 0,
      transition: { delay: i * 0.06, duration: 0.35, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] },
    }),
  };

  return (
    <div className="min-h-[100dvh] bg-[#f7f5f2] flex">
      {/* Desktop Sidebar */}
      <AdminSidebar activeTab={activeTab} onTabChange={setActiveTab} />

      {/* Mobile Header */}
      <div className="md:hidden fixed top-0 left-0 right-0 h-14 bg-[#1a1a1a] z-[100] flex items-center justify-between px-4">
        <span className="font-serif text-base font-semibold text-[#f7f5f2]">PROSTRANSTVO</span>
        <button
          onClick={() => setMobileSidebarOpen((v) => !v)}
          className="text-[#f7f5f2] p-2"
        >
          <Settings size={20} />
        </button>
      </div>

      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {mobileSidebarOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[200] bg-[rgba(0,0,0,0.5)] md:hidden"
              onClick={() => setMobileSidebarOpen(false)}
            />
            <motion.div
              initial={{ x: -260 }}
              animate={{ x: 0 }}
              exit={{ x: -260 }}
              transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
              className="fixed left-0 top-0 bottom-0 w-[260px] bg-[#1a1a1a] z-[300] md:hidden flex flex-col"
            >
              <div className="h-14 flex items-center px-6 border-b border-[rgba(255,255,255,0.08)]">
                <span className="font-serif text-base font-semibold text-[#f7f5f2]">PROSTRANSTVO</span>
              </div>
              <nav className="flex-1 py-4 px-3">
                {SIDEBAR_ITEMS.map((item) => (
                  <button
                    key={item.key}
                    onClick={() => { setActiveTab(item.key); setMobileSidebarOpen(false); }}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                      activeTab === item.key
                        ? 'bg-[rgba(139,157,131,0.2)] text-[#8b9d83] border-l-[3px] border-[#8b9d83]'
                        : 'text-[#9a9a9a] hover:bg-[rgba(255,255,255,0.05)]'
                    }`}
                  >
                    <item.icon size={18} />
                    {item.label}
                  </button>
                ))}
              </nav>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className="flex-1 md:ml-[260px] pt-14 md:pt-0">
        <div className="max-w-[1400px] mx-auto px-4 md:px-8 py-4 md:py-8">
          {/* Tab Title */}
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
            className="mb-6"
          >
            <h1 className="font-serif text-2xl font-semibold text-[#1a1a1a] mb-1">
              {SIDEBAR_ITEMS.find((s) => s.key === activeTab)?.label ?? 'Обзор'}
            </h1>
            <p className="text-sm text-[#6b6b6b]">
              {activeTab === 'overview' && 'Общая статистика платформы'}
              {activeTab === 'users' && 'Управление пользователями'}
              {activeTab === 'projects' && 'Обзор всех проектов'}
              {activeTab === 'transactions' && 'Финансовые операции'}
              {activeTab === 'contractors' && 'База подрядчиков'}
              {activeTab === 'settings' && 'Настройки платформы'}
            </p>
          </motion.div>

          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* KPI Cards */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {KPI_ITEMS.map((item, i) => (
                  <KPICard key={item.label} item={item} index={i} />
                ))}
              </div>

              {/* Charts Row */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Revenue Chart */}
                <motion.div
                  custom={4}
                  initial="hidden"
                  animate="visible"
                  variants={sectionVariants}
                  className="bg-white border border-[#e0dbd4] rounded-xl p-5"
                >
                  <h3 className="font-serif text-base font-semibold text-[#1a1a1a] mb-4">
                    Выручка за 6 месяцев
                  </h3>
                  <div className="h-[280px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={REVENUE_DATA}>
                        <defs>
                          <linearGradient id="revenueGradient" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="#8b9d83" stopOpacity={0.15} />
                            <stop offset="100%" stopColor="#8b9d83" stopOpacity={0} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="#e0dbd4" />
                        <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#6b6b6b' }} />
                        <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#6b6b6b' }} />
                        <Tooltip content={<ChartTooltip />} />
                        <Area
                          type="monotone"
                          dataKey="revenue"
                          stroke="#8b9d83"
                          strokeWidth={2}
                          fill="url(#revenueGradient)"
                          animationDuration={1200}
                          animationEasing="ease-out"
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </motion.div>

                {/* Project Status Bar Chart */}
                <motion.div
                  custom={5}
                  initial="hidden"
                  animate="visible"
                  variants={sectionVariants}
                  className="bg-white border border-[#e0dbd4] rounded-xl p-5"
                >
                  <h3 className="font-serif text-base font-semibold text-[#1a1a1a] mb-4">
                    Проекты по статусам
                  </h3>
                  <div className="h-[280px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={PROJECT_STATUS_DATA}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#e0dbd4" vertical={false} />
                        <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#6b6b6b' }} />
                        <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#6b6b6b' }} />
                        <Tooltip content={<ChartTooltip />} />
                        <Bar dataKey="count" radius={[6, 6, 0, 0]} animationDuration={600} animationEasing="ease-out">
                          {PROJECT_STATUS_DATA.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </motion.div>
              </div>

              {/* Tariff Distribution + Recent Users */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Pie Chart */}
                <motion.div
                  custom={6}
                  initial="hidden"
                  animate="visible"
                  variants={sectionVariants}
                  className="bg-white border border-[#e0dbd4] rounded-xl p-5"
                >
                  <h3 className="font-serif text-base font-semibold text-[#1a1a1a] mb-4">
                    Распределение тарифов
                  </h3>
                  <div className="h-[240px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={TARIFF_DISTRIBUTION}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={90}
                          paddingAngle={3}
                          dataKey="value"
                          animationDuration={1000}
                          animationEasing="ease-out"
                        >
                          {TARIFF_DISTRIBUTION.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip content={<ChartTooltip />} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="flex items-center justify-center gap-4 mt-2">
                    {TARIFF_DISTRIBUTION.map((item) => (
                      <div key={item.name} className="flex items-center gap-1.5">
                        <span className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                        <span className="text-xs text-[#6b6b6b]">{item.name}</span>
                      </div>
                    ))}
                  </div>
                </motion.div>

                {/* Recent Users Table */}
                <motion.div
                  custom={7}
                  initial="hidden"
                  animate="visible"
                  variants={sectionVariants}
                  className="lg:col-span-2 bg-white border border-[#e0dbd4] rounded-xl p-5"
                >
                  <h3 className="font-serif text-base font-semibold text-[#1a1a1a] mb-4">
                    Последние пользователи
                  </h3>
                  <UsersTable users={MOCK_USERS.slice(0, 8)} />
                </motion.div>
              </div>
            </div>
          )}

          {activeTab === 'users' && (
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
            >
              <UsersTable users={MOCK_USERS} />
            </motion.div>
          )}

          {activeTab === 'projects' && (
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
              className="bg-white border border-[#e0dbd4] rounded-xl p-8 text-center"
            >
              <Folder size={48} className="text-[#c4bfb6] mx-auto mb-4" />
              <h3 className="font-serif text-lg font-semibold text-[#1a1a1a] mb-2">
                Страница проектов
              </h3>
              <p className="text-sm text-[#6b6b6b]">
                Полный список всех проектов будет доступен здесь.
              </p>
            </motion.div>
          )}

          {activeTab === 'transactions' && (
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
              className="bg-white border border-[#e0dbd4] rounded-xl p-8 text-center"
            >
              <CreditCard size={48} className="text-[#c4bfb6] mx-auto mb-4" />
              <h3 className="font-serif text-lg font-semibold text-[#1a1a1a] mb-2">
                Страница транзакций
              </h3>
              <p className="text-sm text-[#6b6b6b]">
                История платежей и финансовые операции.
              </p>
            </motion.div>
          )}

          {activeTab === 'contractors' && (
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
              className="bg-white border border-[#e0dbd4] rounded-xl p-8 text-center"
            >
              <Briefcase size={48} className="text-[#c4bfb6] mx-auto mb-4" />
              <h3 className="font-serif text-lg font-semibold text-[#1a1a1a] mb-2">
                Страница подрядчиков
              </h3>
              <p className="text-sm text-[#6b6b6b]">
                Управление базой подрядчиков и верификация.
              </p>
            </motion.div>
          )}

          {activeTab === 'settings' && (
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
              className="bg-white border border-[#e0dbd4] rounded-xl p-5"
            >
              <h3 className="font-serif text-base font-semibold text-[#1a1a1a] mb-4">
                Настройки платформы
              </h3>
              <div className="space-y-4 max-w-[500px]">
                {[
                  { label: 'Режим обслуживания', desc: 'Временно закрыть регистрацию новых пользователей', checked: false },
                  { label: 'Открытая регистрация', desc: 'Разрешить создание новых аккаунтов', checked: true },
                  { label: 'Email-уведомления', desc: 'Отправлять системные письма пользователям', checked: true },
                ].map((setting, i) => (
                  <div key={i} className="flex items-start justify-between py-2">
                    <div>
                      <p className="text-sm font-medium text-[#1a1a1a]">{setting.label}</p>
                      <p className="text-xs text-[#6b6b6b]">{setting.desc}</p>
                    </div>
                    <div className={`relative w-10 h-5 rounded-full flex-shrink-0 ${setting.checked ? 'bg-[#8b9d83]' : 'bg-[#e0dbd4]'}`}>
                      <div
                        className="absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full shadow-sm transition-transform"
                        style={{ transform: setting.checked ? 'translateX(20px)' : 'translateX(0)' }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </div>
      </main>
    </div>
  );
}
