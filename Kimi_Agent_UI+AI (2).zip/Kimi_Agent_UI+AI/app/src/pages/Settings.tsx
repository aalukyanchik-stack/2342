import { useState, useEffect, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowLeft,
  Lock,
  Check,
  Download,
  Trash2,
  AlertTriangle,
  ChevronDown,
  X,
  Save,
  Loader2,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { type Tariff } from '@/lib/api';

// ── Types ──────────────────────────────────────────────
interface NotificationSetting {
  id: string;
  label: string;
  description: string;
  enabled: boolean;
}

interface AppPreference {
  id: string;
  label: string;
  value: string;
  options: { value: string; label: string }[];
}

// ── Toggle Switch ─────────────────────────────────────
function ToggleSwitch({
  enabled,
  onChange,
  label,
  description,
}: {
  enabled: boolean;
  onChange: () => void;
  label: string;
  description: string;
}) {
  return (
    <div className="flex items-start justify-between py-3 gap-4">
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-[#1a1a1a]">{label}</p>
        <p className="text-xs text-[#6b6b6b] mt-0.5">{description}</p>
      </div>
      <button
        onClick={onChange}
        className={`relative w-12 h-6 rounded-full transition-colors duration-200 flex-shrink-0 ${
          enabled ? 'bg-[#8b9d83]' : 'bg-[#e0dbd4]'
        }`}
        aria-label={label}
      >
        <motion.div
          className="absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full shadow-sm"
          animate={{ x: enabled ? 24 : 0 }}
          transition={{ type: 'spring', stiffness: 500, damping: 30 }}
        />
      </button>
    </div>
  );
}

// ── Animated Save Button ──────────────────────────────
function SaveButton({
  saving,
  saved,
  disabled,
  onClick,
}: {
  saving: boolean;
  saved: boolean;
  disabled: boolean;
  onClick: () => void;
}) {
  return (
    <motion.button
      onClick={onClick}
      disabled={disabled || saving}
      className={`inline-flex items-center gap-2 text-sm font-medium px-5 py-2.5 rounded-xl transition-colors ${
        disabled
          ? 'bg-[#d4d0c9] text-[#9a9a9a] cursor-not-allowed'
          : saving
            ? 'bg-[#8b9d83] text-white'
            : saved
              ? 'bg-[#7a9e7a] text-white'
              : 'bg-[#8b9d83] text-white hover:bg-[#6b7a64]'
      }`}
    >
      <AnimatePresence mode="wait">
        {saving ? (
          <motion.div
            key="loading"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <Loader2 size={16} className="animate-spin" />
          </motion.div>
        ) : saved ? (
          <motion.div
            key="saved"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            exit={{ scale: 0 }}
          >
            <Check size={16} />
          </motion.div>
        ) : (
          <motion.div
            key="save"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <Save size={16} />
          </motion.div>
        )}
      </AnimatePresence>
      <AnimatePresence mode="wait">
        <motion.span
          key={saving ? 'saving' : saved ? 'saved' : 'save'}
          initial={{ opacity: 0, y: 4 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -4 }}
        >
          {saving ? 'Сохранение...' : saved ? 'Сохранено!' : 'Сохранить изменения'}
        </motion.span>
      </AnimatePresence>
    </motion.button>
  );
}

// ── Select Dropdown ───────────────────────────────────
function SelectDropdown({
  value,
  options,
  onChange,
}: {
  value: string;
  options: { value: string; label: string }[];
  onChange: (v: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  const selected = options.find((o) => o.value === value);

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex items-center gap-1 text-sm font-medium text-[#8b9d83] hover:text-[#6b7a64] transition-colors"
      >
        {selected?.label}
        <ChevronDown size={14} />
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -4, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -4, scale: 0.96 }}
            transition={{ duration: 0.15 }}
            className="absolute right-0 top-full mt-1 bg-white border border-[#e0dbd4] rounded-xl shadow-lg z-[200] py-1 min-w-[140px]"
          >
            {options.map((opt) => (
              <button
                key={opt.value}
                onClick={() => {
                  onChange(opt.value);
                  setOpen(false);
                }}
                className={`w-full text-left px-3 py-2 text-sm transition-colors ${
                  opt.value === value
                    ? 'text-[#8b9d83] bg-[rgba(139,157,131,0.08)]'
                    : 'text-[#1a1a1a] hover:bg-[#f7f5f2]'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ── Tariff Badge ──────────────────────────────────────
function TariffBadge({ tariff }: { tariff: Tariff }) {
  const styles =
    tariff === 'free'
      ? 'bg-[#e8ede5] text-[#5c6b55]'
      : tariff === 'pro'
        ? 'bg-[#8b9d83] text-white'
        : 'bg-[#1a1a1a] text-white';

  return (
    <span className={`text-[11px] font-bold uppercase tracking-[0.06em] px-3 py-1.5 rounded-lg ${styles}`}>
      {tariff === 'free' ? 'FREE' : tariff === 'pro' ? 'PRO' : 'PRO+'}
    </span>
  );
}

// ── Feature Row ───────────────────────────────────────
function FeatureRow({ label, value, included }: { label: string; value: string; included: boolean }) {
  return (
    <div className="flex items-center justify-between py-2">
      <span className="text-sm text-[#6b6b6b]">{label}</span>
      <div className="flex items-center gap-1.5">
        {included ? (
          <Check size={14} className="text-[#7a9e7a]" />
        ) : (
          <X size={14} className="text-[#c47d7d]" />
        )}
        <span className={`text-sm font-medium ${included ? 'text-[#1a1a1a]' : 'text-[#9a9a9a]'}`}>
          {value}
        </span>
      </div>
    </div>
  );
}

// ── Delete Account Modal ──────────────────────────────
function DeleteAccountModal({
  open,
  onClose,
  onConfirm,
}: {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
}) {
  const [confirmText, setConfirmText] = useState('');

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[300] bg-[rgba(26,26,26,0.4)] backdrop-blur-sm"
            onClick={onClose}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
            className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-[400] bg-white rounded-2xl p-6 w-[90%] max-w-[400px]"
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-[rgba(196,125,125,0.12)] flex items-center justify-center">
                <AlertTriangle size={20} className="text-[#c47d7d]" />
              </div>
              <h3 className="font-serif text-lg font-semibold text-[#1a1a1a]">
                Удалить аккаунт?
              </h3>
            </div>
            <p className="text-sm text-[#6b6b6b] mb-4">
              Все проекты и данные будут безвозвратно удалены. Это действие нельзя отменить.
            </p>
            <div className="mb-4">
              <label className="block text-xs font-medium text-[#6b6b6b] mb-1.5">
                Введите DELETE для подтверждения
              </label>
              <input
                type="text"
                value={confirmText}
                onChange={(e) => setConfirmText(e.target.value)}
                className="w-full bg-white border border-[#e0dbd4] rounded-xl px-4 py-3 text-sm text-[#1a1a1a] focus:outline-none focus:border-[#8b9d83] focus:ring-[3px] focus:ring-[rgba(139,157,131,0.15)]"
                placeholder="DELETE"
              />
            </div>
            <div className="flex gap-3">
              <button
                onClick={onClose}
                className="flex-1 text-sm font-medium text-[#8b9d83] px-4 py-2.5 rounded-xl hover:bg-[rgba(139,157,131,0.08)] transition-colors"
              >
                Отмена
              </button>
              <motion.button
                onClick={onConfirm}
                disabled={confirmText !== 'DELETE'}
                whileTap={confirmText === 'DELETE' ? { scale: 0.97 } : {}}
                className={`flex-1 text-sm font-medium text-white px-4 py-2.5 rounded-xl transition-colors ${
                  confirmText === 'DELETE'
                    ? 'bg-[#c47d7d] hover:bg-[#b06b6b]'
                    : 'bg-[#d4d0c9] cursor-not-allowed'
                }`}
              >
                Удалить
              </motion.button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

// ── Tariff Switcher Modal ─────────────────────────────
function TariffModal({
  open,
  onClose,
  currentTariff,
  onSelect,
}: {
  open: boolean;
  onClose: () => void;
  currentTariff: Tariff;
  onSelect: (t: Tariff) => void;
}) {
  const plans = [
    {
      tariff: 'free' as Tariff,
      name: 'FREE',
      price: 'Бесплатно',
      features: ['1 проект', '3 стиля', 'Базовый бюджет'],
    },
    {
      tariff: 'pro' as Tariff,
      name: 'PRO',
      price: '$9.99/мес',
      features: ['Безлимит проектов', '7 стилей', 'AI Import', 'Telegram-бот'],
    },
    {
      tariff: 'pro_plus' as Tariff,
      name: 'PRO+',
      price: '$19.99/мес',
      features: ['Всё из PRO', 'Публикация подрядчиков', 'Приоритетная поддержка'],
    },
  ];

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[300] bg-[rgba(26,26,26,0.4)] backdrop-blur-sm"
            onClick={onClose}
          />
          <motion.div
            initial={{ opacity: 0, y: '100%' }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: '100%' }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
            className="fixed bottom-0 left-0 right-0 z-[400] bg-white rounded-t-[24px] p-6 pb-10 md:max-w-[600px] md:mx-auto md:rounded-t-2xl"
          >
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-serif text-lg font-semibold">Выберите тариф</h3>
              <button onClick={onClose} className="p-1">
                <X size={20} />
              </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {plans.map((plan) => (
                <div
                  key={plan.tariff}
                  className={`border rounded-xl p-4 ${
                    plan.tariff === currentTariff
                      ? 'border-[#8b9d83] bg-[rgba(139,157,131,0.04)]'
                      : 'border-[#e0dbd4]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-serif text-base font-medium">{plan.name}</span>
                    {plan.tariff === currentTariff && (
                      <span className="text-[10px] font-medium bg-[#8b9d83] text-white px-2 py-0.5 rounded">
                        Текущий
                      </span>
                    )}
                  </div>
                  <p className="text-sm font-semibold text-[#1a1a1a] mb-3">{plan.price}</p>
                  <ul className="space-y-1.5 mb-4">
                    {plan.features.map((f, i) => (
                      <li key={i} className="flex items-center gap-1.5 text-xs text-[#6b6b6b]">
                        <Check size={12} className="text-[#7a9e7a]" />
                        {f}
                      </li>
                    ))}
                  </ul>
                  <button
                    onClick={() => onSelect(plan.tariff)}
                    disabled={plan.tariff === currentTariff}
                    className={`w-full text-sm font-medium py-2 rounded-lg transition-colors ${
                      plan.tariff === currentTariff
                        ? 'bg-[#d4d0c9] text-[#9a9a9a] cursor-not-allowed'
                        : 'bg-[#8b9d83] text-white hover:bg-[#6b7a64]'
                    }`}
                  >
                    {plan.tariff === currentTariff ? 'Текущий план' : 'Выбрать'}
                  </button>
                </div>
              ))}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

// ── Main Settings Page ────────────────────────────────
export default function Settings() {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [loading, setLoading] = useState(false);
  const [saved, setSaved] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);

  const [profile, setProfile] = useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: '',
    bio: '',
  });

  const [notifications, setNotifications] = useState<NotificationSetting[]>([
    { id: 'daily', label: 'Ежедневные задачи', description: 'Напоминания о том, что делать сегодня', enabled: true },
    { id: 'stages', label: 'Этапы ремонта', description: 'Уведомления о переходе между этапами', enabled: true },
    { id: 'budget', label: 'Бюджет', description: 'Оповещения при превышении бюджета', enabled: false },
    { id: 'contractors', label: 'Подрядчики', description: 'Ответы и сообщения от подрядчиков', enabled: true },
    { id: 'ai', label: 'AI анализ', description: 'Результаты анализа изображений', enabled: true },
    { id: 'news', label: 'Новости и акции', description: 'Обновления продукта и спецпредложения', enabled: false },
  ]);

  const [preferences, setPreferences] = useState<AppPreference[]>([
    { id: 'lang', label: 'Язык', value: 'ru', options: [{ value: 'ru', label: 'Русский' }, { value: 'en', label: 'English' }] },
    { id: 'currency', label: 'Валюта', value: '$', options: [{ value: '$', label: '$' }, { value: '€', label: '€' }, { value: '₽', label: '₽' }] },
    { id: 'units', label: 'Единицы измерения', value: 'm2', options: [{ value: 'm2', label: 'м²' }, { value: 'ft2', label: 'ft²' }] },
    { id: 'theme', label: 'Тема', value: 'light', options: [{ value: 'light', label: 'Светлая' }, { value: 'auto', label: 'Авто' }, { value: 'dark', label: 'Тёмная' }] },
  ]);

  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [tariffModalOpen, setTariffModalOpen] = useState(false);

  const tariff: Tariff = user?.tariff || 'free';

  const handleProfileChange = useCallback(
    (field: string, value: string) => {
      setProfile((p) => ({ ...p, [field]: value }));
      setHasChanges(true);
      setSaved(false);
    },
    []
  );

  const handleSave = useCallback(async () => {
    setLoading(true);
    setSaved(false);
    // Simulate API call
    await new Promise((r) => setTimeout(r, 800));
    setLoading(false);
    setSaved(true);
    setHasChanges(false);
    setTimeout(() => setSaved(false), 3000);
  }, []);

  const handleToggle = useCallback((id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, enabled: !n.enabled } : n))
    );
  }, []);

  const handlePrefChange = useCallback((id: string, value: string) => {
    setPreferences((prev) => prev.map((p) => (p.id === id ? { ...p, value } : p)));
  }, []);

  const handleExport = useCallback(() => {
    const data = { profile, notifications, preferences, exportedAt: new Date().toISOString() };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'prostranstvo-data.json';
    a.click();
    URL.revokeObjectURL(url);
  }, [profile, notifications, preferences]);

  const handleDeleteAccount = useCallback(() => {
    logout();
    setDeleteModalOpen(false);
  }, [logout]);

  const handleTariffSelect = useCallback((_t: Tariff) => {
    // In real app, this would call API to upgrade
    setTariffModalOpen(false);
  }, []);

  const sectionVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: (i: number) => ({
      opacity: 1,
      y: 0,
      transition: { delay: i * 0.08, duration: 0.4, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] },
    }),
  };

  return (
    <div className="min-h-[100dvh] bg-[#f7f5f2] px-4 md:px-8 py-4 pb-24 md:pb-8">
      <div className="max-w-[800px] mx-auto">
        {/* ── Header ── */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
          className="flex items-center gap-3 mb-6"
        >
          <button
            onClick={() => navigate('/dashboard')}
            className="p-2 rounded-xl hover:bg-[rgba(139,157,131,0.08)] transition-colors"
          >
            <ArrowLeft size={20} className="text-[#1a1a1a]" />
          </button>
          <div>
            <h1 className="font-serif text-2xl font-semibold text-[#1a1a1a]">Настройки</h1>
            <p className="text-sm text-[#6b6b6b]">
              Управление профилем, уведомлениями и тарифом
            </p>
          </div>
        </motion.div>

        {/* ── Profile Card ── */}
        <motion.div
          custom={0}
          initial="hidden"
          animate="visible"
          variants={sectionVariants}
          className="bg-white border border-[#e0dbd4] rounded-xl p-5 mb-5"
        >
          <h2 className="font-serif text-base font-semibold text-[#1a1a1a] mb-4">Профиль</h2>
          <div className="flex items-center gap-4 mb-5">
            <div className="relative">
              <img
                src="/avatar-default.jpg"
                alt="Avatar"
                className="w-[72px] h-[72px] rounded-full object-cover border-2 border-[#e0dbd4]"
              />
            </div>
            <button className="text-sm font-medium text-[#8b9d83] hover:text-[#6b7a64] transition-colors">
              Изменить фото
            </button>
          </div>
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-[#6b6b6b] mb-1.5">Имя</label>
              <input
                type="text"
                value={profile.name}
                onChange={(e) => handleProfileChange('name', e.target.value)}
                className="w-full bg-white border border-[#e0dbd4] rounded-xl px-4 py-3 text-sm text-[#1a1a1a] focus:outline-none focus:border-[#8b9d83] focus:ring-[3px] focus:ring-[rgba(139,157,131,0.15)]"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-[#6b6b6b] mb-1.5">Email</label>
              <div className="relative">
                <input
                  type="email"
                  value={profile.email}
                  disabled
                  className="w-full bg-[#f7f5f2] border border-[#e0dbd4] rounded-xl px-4 py-3 text-sm text-[#9a9a9a] pr-10 cursor-not-allowed"
                />
                <Lock size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-[#9a9a9a]" />
              </div>
            </div>
            <div>
              <label className="block text-xs font-medium text-[#6b6b6b] mb-1.5">Телефон</label>
              <input
                type="tel"
                value={profile.phone}
                onChange={(e) => handleProfileChange('phone', e.target.value)}
                placeholder="+7 ..."
                className="w-full bg-white border border-[#e0dbd4] rounded-xl px-4 py-3 text-sm text-[#1a1a1a] focus:outline-none focus:border-[#8b9d83] focus:ring-[3px] focus:ring-[rgba(139,157,131,0.15)]"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-[#6b6b6b] mb-1.5">О себе</label>
              <textarea
                value={profile.bio}
                onChange={(e) => handleProfileChange('bio', e.target.value)}
                placeholder="Расскажите о себе..."
                rows={3}
                className="w-full bg-white border border-[#e0dbd4] rounded-xl px-4 py-3 text-sm text-[#1a1a1a] focus:outline-none focus:border-[#8b9d83] focus:ring-[3px] focus:ring-[rgba(139,157,131,0.15)] resize-none"
              />
            </div>
          </div>
          <div className="flex justify-end mt-5">
            <SaveButton saving={loading} saved={saved} disabled={!hasChanges} onClick={handleSave} />
          </div>
        </motion.div>

        {/* ── Tariff Card ── */}
        <motion.div
          custom={1}
          initial="hidden"
          animate="visible"
          variants={sectionVariants}
          className="bg-white border border-[#e0dbd4] rounded-xl p-5 mb-5"
        >
          <div className="flex items-center justify-between mb-4">
            <span className="text-[11px] font-medium uppercase tracking-[0.08em] text-[#9a9a9a]">
              ТЕКУЩИЙ ТАРИФ
            </span>
            <TariffBadge tariff={tariff} />
          </div>
          <div className="mb-4">
            <h3 className="font-serif text-xl font-medium text-[#1a1a1a] mb-1">
              {tariff === 'free' ? 'FREE' : tariff === 'pro' ? 'PRO' : 'PRO+'}
            </h3>
            <p className="text-base font-semibold text-[#1a1a1a]">
              {tariff === 'free' ? 'Бесплатно' : tariff === 'pro' ? '$9.99/мес' : '$19.99/мес'}
            </p>
            <p className="text-xs text-[#9a9a9a] mt-1">Обновляется 15 февраля</p>
          </div>
          <div className="border-t border-[#e0dbd4] pt-3 mb-4 space-y-1">
            <FeatureRow label="Проекты" value={tariff === 'free' ? '1' : 'Безлимит'} included />
            <FeatureRow label="Стили" value={tariff === 'free' ? '3' : '7'} included />
            <FeatureRow label="AI Import" value={tariff === 'free' ? '—' : 'Да'} included={tariff !== 'free'} />
            <FeatureRow label="Telegram-бот" value={tariff === 'free' ? '—' : 'Да'} included={tariff !== 'free'} />
            <FeatureRow
              label="База подрядчиков"
              value={tariff === 'free' ? 'Ограничено' : tariff === 'pro' ? 'Полная' : 'Полная + публикация'}
              included
            />
          </div>
          <div className="flex gap-3">
            {tariff === 'free' && (
              <>
                <button
                  onClick={() => setTariffModalOpen(true)}
                  className="bg-[#8b9d83] text-white text-sm font-medium px-5 py-2.5 rounded-xl hover:bg-[#6b7a64] transition-colors"
                >
                  Обновить до PRO
                </button>
                <button
                  onClick={() => setTariffModalOpen(true)}
                  className="text-sm font-medium text-[#8b9d83] px-4 py-2.5 rounded-xl hover:bg-[rgba(139,157,131,0.08)] transition-colors"
                >
                  Узнать о PRO+
                </button>
              </>
            )}
            {tariff === 'pro' && (
              <>
                <button
                  onClick={() => setTariffModalOpen(true)}
                  className="bg-[#8b9d83] text-white text-sm font-medium px-5 py-2.5 rounded-xl hover:bg-[#6b7a64] transition-colors"
                >
                  Перейти на PRO+
                </button>
                <button
                  onClick={() => setTariffModalOpen(true)}
                  className="text-sm font-medium text-[#8b9d83] px-4 py-2.5 rounded-xl hover:bg-[rgba(139,157,131,0.08)] transition-colors"
                >
                  Управление подпиской
                </button>
              </>
            )}
            {tariff === 'pro_plus' && (
              <button
                onClick={() => setTariffModalOpen(true)}
                className="text-sm font-medium text-[#8b9d83] px-4 py-2.5 rounded-xl hover:bg-[rgba(139,157,131,0.08)] transition-colors"
              >
                Управление подпиской
              </button>
            )}
          </div>
        </motion.div>

        {/* ── Notifications ── */}
        <motion.div
          custom={2}
          initial="hidden"
          animate="visible"
          variants={sectionVariants}
          className="bg-white border border-[#e0dbd4] rounded-xl p-5 mb-5"
        >
          <h2 className="font-serif text-base font-semibold text-[#1a1a1a] mb-2">
            Уведомления
          </h2>
          <div className="divide-y divide-[#e0dbd4]">
            {notifications.map((n) => (
              <ToggleSwitch
                key={n.id}
                label={n.label}
                description={n.description}
                enabled={n.enabled}
                onChange={() => handleToggle(n.id)}
              />
            ))}
          </div>
        </motion.div>

        {/* ── App Preferences ── */}
        <motion.div
          custom={3}
          initial="hidden"
          animate="visible"
          variants={sectionVariants}
          className="bg-white border border-[#e0dbd4] rounded-xl p-5 mb-5"
        >
          <h2 className="font-serif text-base font-semibold text-[#1a1a1a] mb-3">
            Приложение
          </h2>
          <div className="divide-y divide-[#e0dbd4]">
            {preferences.map((pref) => (
              <div key={pref.id} className="flex items-center justify-between py-3">
                <span className="text-sm text-[#1a1a1a]">{pref.label}</span>
                <SelectDropdown
                  value={pref.value}
                  options={pref.options}
                  onChange={(v) => handlePrefChange(pref.id, v)}
                />
              </div>
            ))}
          </div>
        </motion.div>

        {/* ── Data & Privacy ── */}
        <motion.div
          custom={4}
          initial="hidden"
          animate="visible"
          variants={sectionVariants}
          className="bg-white border border-[#e0dbd4] rounded-xl p-5 mb-5"
        >
          <h2 className="font-serif text-base font-semibold text-[#1a1a1a] mb-3">
            Данные и приватность
          </h2>
          <div className="divide-y divide-[#e0dbd4]">
            <button
              onClick={handleExport}
              className="flex items-center gap-3 w-full py-3 text-left hover:opacity-70 transition-opacity"
            >
              <Download size={18} className="text-[#8b9d83]" />
              <span className="text-sm font-medium text-[#1a1a1a]">Экспортировать данные проекта</span>
            </button>
            <button
              onClick={() => setDeleteModalOpen(true)}
              className="flex items-center gap-3 w-full py-3 text-left hover:opacity-70 transition-opacity"
            >
              <Trash2 size={18} className="text-[#c47d7d]" />
              <span className="text-sm font-medium text-[#c47d7d]">Удалить аккаунт</span>
            </button>
          </div>
        </motion.div>

        {/* ── About ── */}
        <motion.div
          custom={5}
          initial="hidden"
          animate="visible"
          variants={sectionVariants}
          className="text-center py-6"
        >
          <div className="flex items-center justify-center gap-2 mb-2">
            <span className="font-serif text-base font-semibold text-[#1a1a1a]">PROSTRANSTVO</span>
            <span className="inline-block w-2 h-2 bg-[#8b9d83] rounded-sm" />
          </div>
          <p className="text-xs text-[#9a9a9a] mb-3">Версия 1.0.0</p>
          <div className="flex items-center justify-center gap-4">
            <button className="text-xs font-medium text-[#8b9d83] hover:text-[#6b7a64] transition-colors">
              Политика конфиденциальности
            </button>
            <button className="text-xs font-medium text-[#8b9d83] hover:text-[#6b7a64] transition-colors">
              Условия использования
            </button>
          </div>
        </motion.div>
      </div>

      {/* ── Modals ── */}
      <DeleteAccountModal
        open={deleteModalOpen}
        onClose={() => setDeleteModalOpen(false)}
        onConfirm={handleDeleteAccount}
      />
      <TariffModal
        open={tariffModalOpen}
        onClose={() => setTariffModalOpen(false)}
        currentTariff={tariff}
        onSelect={handleTariffSelect}
      />
    </div>
  );
}
