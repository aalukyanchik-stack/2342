import { Routes, Route, Outlet } from 'react-router-dom';
import { AuthProvider } from '@/context/AuthContext';
import { ProjectProvider } from '@/context/ProjectContext';
import { ToastProvider } from '@/components/Toast';
import Layout from '@/components/Layout';
import Home from '@/pages/Home';
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import Dashboard from '@/pages/Dashboard';
import Design from '@/pages/Design';
import Planning from '@/pages/Planning';
import Stages from '@/pages/Stages';
import Budget from '@/pages/Budget';
import Contractors from '@/pages/Contractors';
import Settings from '@/pages/Settings';
import Admin from '@/pages/Admin';
import AIAnalysis from '@/pages/AIAnalysis';
import DemoProject from '@/pages/DemoProject';
import MoodboardEditor from '@/pages/MoodboardEditor';

function AppLayout() {
  return (
    <ProjectProvider>
      <Layout>
        <Outlet />
      </Layout>
    </ProjectProvider>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <ToastProvider>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route element={<AppLayout />}>
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/design" element={<Design />} />
            <Route path="/planning" element={<Planning />} />
            <Route path="/stages" element={<Stages />} />
            <Route path="/budget" element={<Budget />} />
            <Route path="/contractors" element={<Contractors />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="/ai-analysis" element={<AIAnalysis />} />
            <Route path="/moodboard/:id" element={<MoodboardEditor />} />
          </Route>
          <Route path="/demo-project" element={<DemoProject />} />
          <Route path="/admin" element={<Admin />} />
        </Routes>
      </ToastProvider>
    </AuthProvider>
  );
}
