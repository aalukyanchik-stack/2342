import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { auth, type User, type Tariff } from '@/lib/api';

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  loginAsTest: () => Promise<void>;
  loginAsDemo: () => Promise<void>;
  register: (data: { name: string; email: string; password: string }) => Promise<void>;
  logout: () => void;
  isAuthenticated: boolean;
  hasFeature: (feature: string) => boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    auth.me().then((u) => {
      setUser(u);
      setIsLoading(false);
    });
  }, []);

  const login = useCallback(async (email: string, password: string) => {
    const u = await auth.login(email, password);
    setUser(u);
    navigate('/dashboard');
  }, [navigate]);

  const loginAsTest = useCallback(async () => {
    // Clear old project data for clean start
    localStorage.removeItem('ps_projects');
    localStorage.removeItem('ps_current_project_id');
    localStorage.removeItem('ps_projectStages');
    localStorage.removeItem('ps_budgetItems');
    localStorage.removeItem('ps_moodboards');
    localStorage.removeItem('__seeded__');

    const u = await auth.login('test@prostranstvo.app', 'test123');
    setUser(u);

    // No auto-create project — user starts with empty dashboard
    navigate('/dashboard');
  }, [navigate]);

  const register = useCallback(async (data: { name: string; email: string; password: string }) => {
    const u = await auth.register(data);
    setUser(u);
    navigate('/dashboard');
  }, [navigate]);

  const logout = useCallback(() => {
    auth.logout().then(() => {
      setUser(null);
      navigate('/');
    });
  }, [navigate]);

  const hasFeature = useCallback((feature: string) => {
    const tariff = user?.tariff ?? 'free';
    const featureMap: Record<string, Tariff[]> = {
      allStyles: ['pro', 'pro_plus'],
      aiImport: ['pro', 'pro_plus'],
      telegramBot: ['pro', 'pro_plus'],
      unlimitedProjects: ['pro', 'pro_plus'],
      contractorsPublish: ['pro_plus'],
    };
    const required = featureMap[feature] ?? [];
    return required.length === 0 || required.includes(tariff);
  }, [user?.tariff]);

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        login,
        loginAsTest,
        loginAsDemo: loginAsTest,
        register,
        logout,
        isAuthenticated: !!user,
        hasFeature,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}
