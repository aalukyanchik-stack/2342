import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from 'react';
import { useLocation } from 'react-router-dom';
import { projects as apiProjects } from '@/lib/api';
import type { Project } from '@/lib/api';

interface ProjectContextType {
  projects: Project[];
  currentProject: Project | null;
  setCurrentProjectId: (id: string | null) => void;
  refreshProjects: () => Promise<void>;
  createProject: (data: {
    name: string;
    budget: number;
    styleId: string;
    area: number;
    familySize: string | number;
    hasPets: boolean;
  }) => Promise<Project>;
  isLoading: boolean;
}

const ProjectContext = createContext<ProjectContextType | null>(null);

export function ProjectProvider({ children }: { children: ReactNode }) {
  const [projects, setProjects] = useState<Project[]>([]);
  const [currentProject, setCurrentProject] = useState<Project | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const location = useLocation();

  const refreshProjects = useCallback(async () => {
    try {
      const list = await apiProjects.list();
      setProjects(list);
      const currentId = localStorage.getItem('ps_current_project_id');
      if (currentId) {
        const found = list.find((p: Project) => p.id === currentId);
        if (found) {
          setCurrentProject(found);
          return;
        }
      }
      if (list.length > 0) {
        setCurrentProject(list[0]);
        localStorage.setItem('ps_current_project_id', list[0].id);
      } else {
        setCurrentProject(null);
      }
    } catch {
      setProjects([]);
      setCurrentProject(null);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshProjects();
  }, [refreshProjects, location.pathname]);

  const setCurrentProjectId = useCallback((id: string | null) => {
    if (id) {
      localStorage.setItem('ps_current_project_id', id);
      const found = projects.find((p) => p.id === id);
      if (found) setCurrentProject(found);
    } else {
      localStorage.removeItem('ps_current_project_id');
      setCurrentProject(null);
    }
  }, [projects]);

  const createProject = useCallback(async (data: {
    name: string;
    budget: number;
    styleId: string;
    area: number;
    familySize: string | number;
    hasPets: boolean;
  }) => {
    const project = await apiProjects.create(data);
    await refreshProjects();
    localStorage.setItem('ps_current_project_id', project.id);
    setCurrentProject(project);
    return project;
  }, [refreshProjects]);

  return (
    <ProjectContext.Provider
      value={{
        projects,
        currentProject,
        setCurrentProjectId,
        refreshProjects,
        createProject,
        isLoading,
      }}
    >
      {children}
    </ProjectContext.Provider>
  );
}

export function useProject() {
  const ctx = useContext(ProjectContext);
  if (!ctx) throw new Error('useProject must be used inside ProjectProvider');
  return ctx;
}
