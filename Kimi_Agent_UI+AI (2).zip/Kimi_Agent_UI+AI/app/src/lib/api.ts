// Mock API Layer for PROSTRANSTVO
// Simulates tRPC structure with localStorage persistence

// --- Types ---

export type Tariff = 'free' | 'pro' | 'pro_plus';

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'user' | 'admin';
  tariff: Tariff;
  avatar: string;
}

export interface Room {
  id: string;
  projectId: string;
  name: string;
  roomType: string;
  area: number;
  ceilingHeight: number;
  windowsCount: number;
  furnitureLayout?: string;
}

export interface Project {
  id: string;
  userId: string;
  name: string;
  budget: number;
  styleId: string;
  styleName: string;
  status: 'draft' | 'active' | 'completed' | 'archived';
  area: number;
  familySize: number;
  hasPets: boolean;
  rooms: Room[];
  progress: number;
  currentStageId: string;
}

export interface Style {
  id: string;
  slug: string;
  name: string;
  description: string;
  imageUrl: string;
  materials: string[];
  colors: string[];
  complexity: 'Легкая' | 'Средняя' | 'Сложная';
  budgetLevel: '$' | '$$' | '$$$' | '$$$$';
}

export interface ChecklistItem {
  id: string;
  stageId: string;
  text: string;
  description?: string;
  isRequired: boolean;
  tip?: string;
  estimatedCost?: number;
}

export interface Stage {
  id: string;
  order: number;
  name: string;
  slug: string;
  description: string;
  estimatedDays: number;
  icon: string;
  tips: string[];
  checklistItems: ChecklistItem[];
}

export interface ProjectStage {
  id: string;
  projectId: string;
  stageId: string;
  status: 'pending' | 'in_progress' | 'completed' | 'skipped';
  startedAt?: string;
  completedAt?: string;
  notes?: string;
  actualCost?: number;
}

export interface Contractor {
  id: string;
  name: string;
  specialization: string;
  rating: number;
  reviews: number;
  region: string;
  phone?: string;
  email?: string;
  priceRange: string;
  avatar?: string;
}

export interface MoodboardItem {
  id: string;
  moodboardId: string;
  imageUrl: string;
  positionX: number;
  positionY: number;
  width: number;
  height: number;
  zIndex: number;
}

export interface Moodboard {
  id: string;
  userId: string;
  projectId: string;
  name: string;
  items: MoodboardItem[];
}

export interface BudgetItem {
  id: string;
  projectId: string;
  category: string;
  name: string;
  plannedCost: number;
  actualCost: number;
  type: 'work' | 'material';
}

export interface AIAnalysisResult {
  style: string;
  colorPalette: string[];
  materials: string[];
  furniture: string[];
  textures: string[];
  roomType: string;
  moodDescription: string;
  confidence: number;
}

interface StoredUser extends User {
  password: string;
}

// --- Helpers ---

const delay = (ms: number) => new Promise((res) => setTimeout(res, ms));
const randDelay = () => delay(300 + Math.random() * 500);

function getStore<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function setStore<T>(key: string, value: T) {
  localStorage.setItem(key, JSON.stringify(value));
}

function uuid() {
  return `${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

// --- localStorage helpers for related data ---

function getProjects(): Project[] {
  return getStore<Project[]>('projects', []);
}

function saveProjects(projects: Project[]) {
  setStore('projects', projects);
}

function getRooms(): Room[] {
  return getStore<Room[]>('rooms', []);
}

function saveRooms(rooms: Room[]) {
  setStore('rooms', rooms);
}

function getProjectStages(): ProjectStage[] {
  return getStore<ProjectStage[]>('projectStages', []);
}

function saveProjectStages(stages: ProjectStage[]) {
  setStore('projectStages', stages);
}

function getBudgetItems(): BudgetItem[] {
  return getStore<BudgetItem[]>('budgetItems', []);
}

function saveBudgetItems(items: BudgetItem[]) {
  setStore('budgetItems', items);
}

function getAllStages(): Stage[] {
  return getStore<Stage[]>('stages', []);
}

// --- Seed Data ---

const STYLES: Style[] = [
  { id: '1', slug: 'scandinavian', name: 'Скандинавский', description: 'Светлый, уютный, минимализм, дерево', imageUrl: '/style-scandi.jpg', materials: ['Светлый дуб', 'Лен', 'Белая краска'], colors: ['#f5f5f0', '#d4cbb8', '#8b9d83', '#ffffff', '#c4bfb6'], complexity: 'Легкая', budgetLevel: '$' },
  { id: '2', slug: 'loft', name: 'Лофт', description: 'Кирпич, бетон, металл, открытые коммуникации', imageUrl: '/style-loft.jpg', materials: ['Кирпич', 'Бетон', 'Сталь', 'Стекло'], colors: ['#8b4513', '#696969', '#a8a8a8', '#2f2f2f', '#cd853f'], complexity: 'Средняя', budgetLevel: '$$' },
  { id: '3', slug: 'minimalism', name: 'Минимализм', description: 'Чистота линий, отсутствие декора, функциональность', imageUrl: '/style-minimal.jpg', materials: ['Бетон', 'Стекло', 'Белый мрамор'], colors: ['#ffffff', '#f0f0f0', '#d0d0d0', '#a0a0a0', '#333333'], complexity: 'Средняя', budgetLevel: '$$$' },
  { id: '4', slug: 'neoclassic', name: 'Неоклассика', description: 'Современная интерпретация классики', imageUrl: '/style-neoclassic.jpg', materials: ['Молдинги', 'Лепнина', 'Паркет елочкой'], colors: ['#f8f4ed', '#e8ddd0', '#c4a882', '#8b7355', '#ffffff'], complexity: 'Сложная', budgetLevel: '$$$' },
  { id: '5', slug: 'modern-classic', name: 'Современная классика', description: 'Баланс традиций и современности', imageUrl: '/style-modern-classic.jpg', materials: ['Паркет', 'Текстиль', 'Латунь'], colors: ['#faf8f5', '#e0d5c8', '#b8a99a', '#6b5b4f', '#d4af37'], complexity: 'Средняя', budgetLevel: '$$' },
  { id: '6', slug: 'japanese', name: 'Японский', description: 'Wabi-sabi, натуральность, асимметрия', imageUrl: '/style-japanese.jpg', materials: ['Бамбук', 'Рисовая бумага', 'Камень'], colors: ['#e8e0d4', '#c4b8a8', '#8b7d6b', '#d4c4a8', '#f0ebe3'], complexity: 'Средняя', budgetLevel: '$$' },
  { id: '7', slug: 'artdeco', name: 'Ар-деко', description: 'Геометрия, роскошь, контрасты', imageUrl: '/style-artdeco.jpg', materials: ['Мрамор', 'Золото', 'Бархат', 'Зеркала'], colors: ['#1a1a2e', '#c9a96e', '#0f3460', '#e94560', '#f5f5f5'], complexity: 'Сложная', budgetLevel: '$$$$' },
];

const STAGE_NAMES = [
  { name: 'Подготовка и дизайн', slug: 'design', icon: 'Palette', desc: 'Выбор стиля, замеры, планировка, мудборд' },
  { name: 'Демонтаж', slug: 'demolition', icon: 'Hammer', desc: 'Снос стен, уборка, вывоз мусора' },
  { name: 'Черновая отделка', slug: 'rough', icon: 'Wrench', desc: 'Электрика, сантехника, стяжка, штукатурка' },
  { name: 'Чистовая отделка', slug: 'finish', icon: 'Paintbrush', desc: 'Покраска, обои, плитка, ламинат' },
  { name: 'Кухня и санузлы', slug: 'kitchen', icon: 'ChefHat', desc: 'Установка кухни, сантехники, плитки' },
  { name: 'Электрика и свет', slug: 'electrical', icon: 'Lightbulb', desc: 'Розетки, выключатели, светильники' },
  { name: 'Мебель и текстиль', slug: 'furniture', icon: 'Sofa', desc: 'Мебель, шторы, ковры, декор' },
  { name: 'Умный дом', slug: 'smart', icon: 'Cpu', desc: 'Системы автоматизации, сенсоры' },
  { name: 'Уборка и финал', slug: 'cleanup', icon: 'Sparkles', desc: 'Генеральная уборка, проверка, приёмка' },
  { name: 'Заселение', slug: 'movein', icon: 'Home', desc: 'Переезд, расстановка, финальные штрихи' },
];

function buildStages(): Stage[] {
  return STAGE_NAMES.map((s, i) => ({
    id: `stage-${i + 1}`,
    order: i + 1,
    name: s.name,
    slug: s.slug,
    description: s.desc,
    estimatedDays: 3 + Math.floor(Math.random() * 10),
    icon: s.icon,
    tips: [`Совет ${i + 1}.1: Не торопитесь`, `Совет ${i + 1}.2: Делайте фото до/после`],
    checklistItems: Array.from({ length: 5 + Math.floor(Math.random() * 4) }).map((_, ci) => ({
      id: `ci-${i}-${ci}`,
      stageId: `stage-${i + 1}`,
      text: `Пункт ${ci + 1} этапа «${s.name}»`,
      description: `Описание работы пункта ${ci + 1}`,
      isRequired: ci < 3,
      tip: ci === 0 ? 'Обязательно проверьте размеры' : undefined,
      estimatedCost: ci % 2 === 0 ? 1000 + ci * 500 : undefined,
    })),
  }));
}

function buildContractors(): Contractor[] {
  const specs = ['Электрик', 'Сантехник', 'Плиточник', 'Маляр', 'Штукатур', 'Плотник', 'Дизайнер', 'Умный дом'];
  const regions = ['Москва', 'СПб', 'Казань', 'Екатеринбург', 'Новосибирск'];
  return Array.from({ length: 50 }).map((_, i) => ({
    id: `contractor-${i}`,
    name: `Подрядчик ${i + 1}`,
    specialization: specs[i % specs.length],
    rating: 3.5 + Math.random() * 1.5,
    reviews: Math.floor(Math.random() * 120),
    region: regions[i % regions.length],
    phone: `+7 900 ${100 + i}-${10 + (i % 90)}-${10 + (i % 90)}`,
    email: `contractor${i}@example.com`,
    priceRange: ['$', '$$', '$$$'][i % 3],
    avatar: '/avatar-default.jpg',
  }));
}

// --- Seeding ---

function seedIfNeeded() {
  if (!localStorage.getItem('__seeded__')) {
    const stages = buildStages();
    setStore('styles', STYLES);
    setStore('stages', stages);
    setStore('contractors', buildContractors());

    // Seed test user
    const testUser: StoredUser = {
      id: 'user-test',
      name: 'Анна Тестова',
      email: 'test@prostranstvo.app',
      password: 'test123',
      role: 'user',
      tariff: 'free',
      avatar: '/avatar-default.jpg',
    };
    setStore('users', [testUser]);

    // No seed projects — user starts with empty dashboard
    setStore('projects', []);
    setStore('projectStages', []);
    setStore('budgetItems', []);
    setStore('moodboards', []);
    localStorage.setItem('__seeded__', 'true');
  }
}

seedIfNeeded();

// --- Auth ---

function getUsers(): StoredUser[] {
  return getStore<StoredUser[]>('users', []);
}

function saveUsers(users: StoredUser[]) {
  setStore('users', users);
}

function stripPassword(u: StoredUser): User {
  const { password: _password, ...rest } = u;
  return rest;
}

export const auth = {
  async login(email: string, password: string) {
    await randDelay();
    const users = getUsers();

    // Ensure test user exists on first login attempt
    if (email === 'test@prostranstvo.app' && password === 'test123') {
      let testUser = users.find((u) => u.email === 'test@prostranstvo.app');
      if (!testUser) {
        testUser = {
          id: 'user-test',
          name: 'Анна Тестова',
          email: 'test@prostranstvo.app',
          password: 'test123',
          role: 'user',
          tariff: 'free',
          avatar: '/avatar-default.jpg',
        };
        users.push(testUser);
        saveUsers(users);
      }
      const user = stripPassword(testUser);
      setStore('user', user);
      return user;
    }

    // Demo login for landing page "Open demo project" flow
    if (email === 'demo@prostranstvo.app' && password === 'demo') {
      let demoUser = users.find((u) => u.email === 'demo@prostranstvo.app');
      if (!demoUser) {
        demoUser = {
          id: 'demo',
          name: 'Демо пользователь',
          email: 'demo@prostranstvo.app',
          password: 'demo',
          role: 'user',
          tariff: 'free',
          avatar: '/avatar-default.jpg',
        };
        users.push(demoUser);
        saveUsers(users);
      }
      const user = stripPassword(demoUser);
      setStore('user', user);
      return user;
    }

    // Normal login
    const found = users.find((u) => u.email === email && u.password === password);
    if (!found) {
      throw new Error('Invalid email or password');
    }
    const user = stripPassword(found);
    setStore('user', user);
    return user;
  },

  async register(data: { name: string; email: string; password: string }) {
    await randDelay();
    const users = getUsers();
    if (users.find((u) => u.email === data.email)) {
      throw new Error('User already exists');
    }
    const newUser: StoredUser = {
      id: uuid(),
      name: data.name,
      email: data.email,
      password: data.password,
      role: 'user',
      tariff: 'free',
      avatar: '/avatar-default.jpg',
    };
    users.push(newUser);
    saveUsers(users);
    const user = stripPassword(newUser);
    setStore('user', user);
    return user;
  },

  async me() {
    await randDelay();
    const current = getStore<User | null>('user', null);
    if (!current) return null;
    // Verify user still exists in users store and return fresh data
    const users = getUsers();
    const found = users.find((u) => u.id === current.id);
    if (!found) {
      localStorage.removeItem('user');
      return null;
    }
    const user = stripPassword(found);
    setStore('user', user);
    return user;
  },

  async logout() {
    await delay(200);
    localStorage.removeItem('user');
  },
};

// --- Projects ---

export const projects = {
  async create(data: { name?: string; budget?: number; styleId?: string; familySize?: string | number; hasPets?: boolean; area?: number }) {
    await randDelay();
    const user = await auth.me();
    if (!user) throw new Error('Unauthorized');

    const now = Date.now();
    const familySizeNum = typeof data.familySize === 'string'
      ? { single: 1, couple: 2, family: 3, large_family: 5 }[data.familySize] ?? 2
      : (data.familySize ?? 2);

    // Find style name
    const styleSlug = data.styleId || 'scandinavian';
    const foundStyle = STYLES.find((s) => s.slug === styleSlug);
    const styleName = foundStyle?.name || 'Скандинавский';

    const project: Project = {
      id: `project-${now}`,
      userId: user.id,
      name: data.name || 'Новый проект',
      area: data.area || 50,
      styleId: styleSlug,
      styleName,
      budget: data.budget || 0,
      familySize: familySizeNum,
      hasPets: data.hasPets ?? false,
      status: 'draft',
      progress: 0,
      currentStageId: '',
      rooms: [],
    };

    // Seed rooms
    const rooms: Room[] = [
      { id: `room-${now}-1`, projectId: project.id, name: 'Гостиная', roomType: 'living', area: 22, ceilingHeight: 2.7, windowsCount: 2, furnitureLayout: 'Диван, ТВ-тумба, Кофейный столик' },
      { id: `room-${now}-2`, projectId: project.id, name: 'Кухня', roomType: 'kitchen', area: 12, ceilingHeight: 2.7, windowsCount: 1, furnitureLayout: 'Кухонный гарнитур, Обеденный стол' },
      { id: `room-${now}-3`, projectId: project.id, name: 'Спальня', roomType: 'bedroom', area: 16, ceilingHeight: 2.7, windowsCount: 1, furnitureLayout: 'Кровать, Шкаф, Тумбочки' },
      { id: `room-${now}-4`, projectId: project.id, name: 'Ванная', roomType: 'bathroom', area: 6, ceilingHeight: 2.5, windowsCount: 1, furnitureLayout: 'Ванна, Раковина, Стиральная машина' },
    ];

    // Seed project stages
    const allStages = getAllStages();
    const projectStages: ProjectStage[] = allStages.map((s, i) => ({
      id: `ps-${now}-${i}`,
      projectId: project.id,
      stageId: s.id,
      status: (i < 2 ? 'completed' : i === 2 ? 'in_progress' : 'pending') as ProjectStage['status'],
      startedAt: i < 2 ? new Date().toISOString() : undefined,
      completedAt: i < 2 ? new Date().toISOString() : undefined,
      notes: '',
      actualCost: 0,
    }));

    // Seed budget items
    const budgetItems: BudgetItem[] = [
      { id: `bi-${now}-1`, projectId: project.id, category: 'Демонтаж', name: 'Демонтаж стен и перегородок', plannedCost: 30000, actualCost: 32000, type: 'work' },
      { id: `bi-${now}-2`, projectId: project.id, category: 'Электрика', name: 'Проводка и электромонтаж', plannedCost: 80000, actualCost: 75000, type: 'work' },
      { id: `bi-${now}-3`, projectId: project.id, category: 'Электрика', name: 'Щиток и автоматы', plannedCost: 25000, actualCost: 28000, type: 'material' },
      { id: `bi-${now}-4`, projectId: project.id, category: 'Сантехника', name: 'Сантехнические работы', plannedCost: 60000, actualCost: 65000, type: 'work' },
      { id: `bi-${now}-5`, projectId: project.id, category: 'Сантехника', name: 'Смесители и сантехника', plannedCost: 40000, actualCost: 42000, type: 'material' },
      { id: `bi-${now}-6`, projectId: project.id, category: 'Черновая отделка', name: 'Штукатурка стен', plannedCost: 55000, actualCost: 50000, type: 'work' },
      { id: `bi-${now}-7`, projectId: project.id, category: 'Черновая отделка', name: 'Стяжка пола', plannedCost: 35000, actualCost: 38000, type: 'work' },
      { id: `bi-${now}-8`, projectId: project.id, category: 'Чистовая отделка', name: 'Покраска стен', plannedCost: 45000, actualCost: 40000, type: 'work' },
      { id: `bi-${now}-9`, projectId: project.id, category: 'Чистовая отделка', name: 'Обои', plannedCost: 25000, actualCost: 30000, type: 'material' },
      { id: `bi-${now}-10`, projectId: project.id, category: 'Полы', name: 'Укладка паркета', plannedCost: 120000, actualCost: 125000, type: 'work' },
      { id: `bi-${now}-11`, projectId: project.id, category: 'Полы', name: 'Паркетная доска (30м²)', plannedCost: 180000, actualCost: 175000, type: 'material' },
      { id: `bi-${now}-12`, projectId: project.id, category: 'Полы', name: 'Плитка (ванная)', plannedCost: 50000, actualCost: 48000, type: 'material' },
      { id: `bi-${now}-13`, projectId: project.id, category: 'Двери/окна', name: 'Установка дверей', plannedCost: 40000, actualCost: 42000, type: 'work' },
      { id: `bi-${now}-14`, projectId: project.id, category: 'Двери/окна', name: 'Межкомнатные двери', plannedCost: 60000, actualCost: 65000, type: 'material' },
      { id: `bi-${now}-15`, projectId: project.id, category: 'Мебель', name: 'Кухонный гарнитур', plannedCost: 200000, actualCost: 0, type: 'material' },
      { id: `bi-${now}-16`, projectId: project.id, category: 'Мебель', name: 'Установка мебели', plannedCost: 30000, actualCost: 0, type: 'work' },
    ];

    // Save everything
    const allProjects = getProjects();
    allProjects.push(project);
    saveProjects(allProjects);

    const allRooms = getRooms();
    rooms.forEach((r) => allRooms.push(r));
    saveRooms(allRooms);

    const allProjectStages = getProjectStages();
    projectStages.forEach((ps) => allProjectStages.push(ps));
    saveProjectStages(allProjectStages);

    const allBudgetItems = getBudgetItems();
    budgetItems.forEach((b) => allBudgetItems.push(b));
    saveBudgetItems(allBudgetItems);

    // Set as current project
    localStorage.setItem('ps_current_project_id', project.id);

    return project;
  },

  async list() {
    await randDelay();
    const user = await auth.me();
    if (!user) return [];
    const allProjects = getProjects();
    return allProjects.filter((p) => p.userId === user.id);
  },

  async get(id: string) {
    await randDelay();
    const allProjects = getProjects();
    const project = allProjects.find((p) => p.id === id);
    if (!project) return null;
    const allRooms = getRooms();
    const allProjectStages = getProjectStages();
    const allBudgetItems = getBudgetItems();
    return {
      ...project,
      rooms: allRooms.filter((r) => r.projectId === id),
      stages: allProjectStages.filter((ps) => ps.projectId === id),
      budgetItems: allBudgetItems.filter((b) => b.projectId === id),
    };
  },

  async getCurrentProject() {
    const currentId = localStorage.getItem('ps_current_project_id');
    if (!currentId) return null;
    const allProjects = getProjects();
    return allProjects.find((p) => p.id === currentId) || null;
  },

  async update(id: string, data: Partial<Project>) {
    await randDelay();
    const all = getProjects();
    const idx = all.findIndex((p) => p.id === id);
    if (idx === -1) throw new Error('Project not found');
    all[idx] = { ...all[idx], ...data };
    saveProjects(all);
    return all[idx];
  },

  async delete(id: string) {
    await randDelay();
    let all = getProjects();
    all = all.filter((p) => p.id !== id);
    saveProjects(all);
    // Clean up related data
    let ps = getProjectStages();
    ps = ps.filter((p) => p.projectId !== id);
    saveProjectStages(ps);
    let rooms = getRooms();
    rooms = rooms.filter((r) => r.projectId !== id);
    saveRooms(rooms);
    let budget = getBudgetItems();
    budget = budget.filter((b) => b.projectId !== id);
    saveBudgetItems(budget);
  },
};

// --- Stages ---

export const stages = {
  async list() {
    await randDelay();
    return getStore<Stage[]>('stages', []);
  },

  async getProgress(projectId: string) {
    await randDelay();
    const ps = getStore<ProjectStage[]>('projectStages', []);
    return ps.filter((p) => p.projectId === projectId);
  },

  async updateStatus(projectStageId: string, status: ProjectStage['status']) {
    await randDelay();
    const ps = getStore<ProjectStage[]>('projectStages', []);
    const idx = ps.findIndex((p) => p.id === projectStageId);
    if (idx === -1) throw new Error('Project stage not found');
    ps[idx] = { ...ps[idx], status, completedAt: status === 'completed' ? new Date().toISOString() : ps[idx].completedAt };
    setStore('projectStages', ps);
    return ps[idx];
  },
};

// --- Styles ---

export const styles = {
  async list() {
    await randDelay();
    return getStore<Style[]>('styles', STYLES);
  },

  async get(slug: string) {
    await randDelay();
    const all = getStore<Style[]>('styles', STYLES);
    const style = all.find((s) => s.slug === slug);
    if (!style) throw new Error('Style not found');
    return style;
  },
};

// --- Contractors ---

export const contractors = {
  async list(filters?: { specialization?: string; region?: string; priceRange?: string }) {
    await randDelay();
    let all = getStore<Contractor[]>('contractors', buildContractors());
    if (filters?.specialization) {
      all = all.filter((c) => c.specialization === filters.specialization);
    }
    if (filters?.region) {
      all = all.filter((c) => c.region === filters.region);
    }
    if (filters?.priceRange) {
      all = all.filter((c) => c.priceRange === filters.priceRange);
    }
    return all;
  },

  async get(id: string) {
    await randDelay();
    const all = getStore<Contractor[]>('contractors', buildContractors());
    const c = all.find((x) => x.id === id);
    if (!c) throw new Error('Contractor not found');
    return c;
  },
};

// --- Budget ---

export const budget = {
  async list(projectId: string) {
    await randDelay();
    const all = getStore<BudgetItem[]>('budgetItems', []);
    return all.filter((b) => b.projectId === projectId);
  },

  async create(data: Omit<BudgetItem, 'id'>) {
    await randDelay();
    const item: BudgetItem = { id: uuid(), ...data };
    const all = getStore<BudgetItem[]>('budgetItems', []);
    all.push(item);
    setStore('budgetItems', all);
    return item;
  },

  async update(id: string, data: Partial<BudgetItem>) {
    await randDelay();
    const all = getStore<BudgetItem[]>('budgetItems', []);
    const idx = all.findIndex((b) => b.id === id);
    if (idx === -1) throw new Error('Budget item not found');
    all[idx] = { ...all[idx], ...data };
    setStore('budgetItems', all);
    return all[idx];
  },
};

// --- AI ---

export const ai = {
  async analyzeImage(_imageUrl: string) {
    await delay(2000 + Math.random() * 1000);
    const result: AIAnalysisResult = {
      style: 'Скандинавский',
      colorPalette: ['#f5f5f0', '#d4cbb8', '#8b9d83', '#ffffff'],
      materials: ['Светлый дуб', 'Лен', 'Белая краска'],
      furniture: ['Диван IKEA', 'Журнальный столик', 'Кресло'],
      textures: ['Дерево', 'Ткань', 'Керамика'],
      roomType: 'Гостиная',
      moodDescription: 'Уютная светлая гостиная в скандинавском стиле',
      confidence: 0.87,
    };
    return result;
  },
};

// --- Moodboards ---

export const moodboards = {
  async list(projectId: string) {
    await randDelay();
    const all = getStore<Moodboard[]>('moodboards', []);
    return all.filter((m) => m.projectId === projectId);
  },

  async create(data: { userId: string; projectId: string; name: string }) {
    await randDelay();
    const board: Moodboard = { id: uuid(), ...data, items: [] };
    const all = getStore<Moodboard[]>('moodboards', []);
    all.push(board);
    setStore('moodboards', all);
    return board;
  },

  async get(id: string) {
    await randDelay();
    const all = getStore<Moodboard[]>('moodboards', []);
    const m = all.find((x) => x.id === id);
    if (!m) throw new Error('Moodboard not found');
    return m;
  },

  async updateItem(id: string, data: Partial<MoodboardItem>) {
    await randDelay();
    const all = getStore<Moodboard[]>('moodboards', []);
    for (const board of all) {
      const idx = board.items.findIndex((it) => it.id === id);
      if (idx !== -1) {
        board.items[idx] = { ...board.items[idx], ...data };
        setStore('moodboards', all);
        return board.items[idx];
      }
    }
    throw new Error('Item not found');
  },
};

// --- Demo project helper (kept for compatibility, no longer auto-created) ---

export function ensureDemoProject() {
  const allProjects = getStore<Project[]>('projects', []);
  if (!allProjects.find((p) => p.id === 'demo-lavada')) {
    const demo: Project = {
      id: 'demo-lavada',
      userId: 'demo',
      name: 'ЖК Уютный',
      budget: 1500000,
      styleId: '1',
      styleName: 'Скандинавский',
      status: 'active',
      area: 65,
      familySize: 2,
      hasPets: false,
      rooms: [
        { id: 'r1', projectId: 'demo-lavada', name: 'Гостиная', roomType: 'living', area: 22, ceilingHeight: 2.7, windowsCount: 2 },
        { id: 'r2', projectId: 'demo-lavada', name: 'Кухня', roomType: 'kitchen', area: 12, ceilingHeight: 2.7, windowsCount: 1 },
        { id: 'r3', projectId: 'demo-lavada', name: 'Спальня', roomType: 'bedroom', area: 16, ceilingHeight: 2.7, windowsCount: 1 },
        { id: 'r4', projectId: 'demo-lavada', name: 'Ванная', roomType: 'bathroom', area: 6, ceilingHeight: 2.6, windowsCount: 1 },
      ],
      progress: 35,
      currentStageId: 'stage-3',
    };
    allProjects.push(demo);
    setStore('projects', allProjects);

    const stagesList = getStore<Stage[]>('stages', []);
    let ps = getStore<ProjectStage[]>('projectStages', []);
    stagesList.forEach((s, i) => {
      ps.push({
        id: `ps-demo-${s.id}`,
        projectId: 'demo-lavada',
        stageId: s.id,
        status: i < 2 ? 'completed' : i === 2 ? 'in_progress' : 'pending',
        startedAt: i <= 2 ? new Date().toISOString() : undefined,
        completedAt: i < 2 ? new Date().toISOString() : undefined,
      });
    });
    setStore('projectStages', ps);
  }
}
